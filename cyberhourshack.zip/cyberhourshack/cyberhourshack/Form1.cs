﻿using System;
using System.Drawing;
using Microsoft.Win32;
using System.Windows.Forms;
using System.Management;
using System.Net;
using System.Net.Sockets;
using System.IO;
using System.Net.NetworkInformation;
using System.Threading;
using System.Diagnostics;
using System.Net.Mail;
using Microsoft.VisualBasic.CompilerServices;
using System.Media;


namespace cyberhourshack
{
    public partial class Form1 : Form
    {
        string ProgramAdi = "CyberHoursHackerTools";

        public Form1()
        {

            InitializeComponent();
            this.hazır.Items.AddRange(new object[]
            {
                "(\"Comment on Hello world!\")", "(\"Hello world!\")", "(\"author/admin\")",
                "(\"uncategorized/hello-world\")", "(\"category/sin-categoria\")", "(\"uncategorized\")",
                "(\"non-class\x00e9\")", "inurl:gov.\x00dcLKEDOMAİNUZANTISI -mofcom ", "/wp-content/themes/AskIt/",
                "/wp-content/themes/Nova/", "/wp-content/themes/eNews/", "/wp-content/themes/eVid/",
                "/wp-content/themes/TheCorporation/", "/wp-content/themes/Minimal/", "/wp-content/themes/Polished/",
                "/wp-content/themes/MyResume/",
                "/wp-content/themes/TheSource/", "/wp-content/themes/StudioBlue/", "/wp-content/themes/Wooden/",
                "/wp-content/themes/WhosWho/", "/wp-content/themes/Quadro/", "/wp-content/themes/Glow/",
                "/wp-content/themes/Modest/", "/wp-content/themes/Aggregate/", "/wp-content/themes/autofashion/",
                "/wp-content/themes/automotive-blog-theme/Quick%20Cash%20Auto/", "/wp-content/themes/bikes/",
                "/wp-content/themes/automotive-blog-theme/", "/wp-content/themes/black_eve/",
                "/wp-content/themes/blex/scripts/", "/wp-content/themes/bloggnorge-a1/scripts/",
                "/wp-content/themes/r755/",
                "/wp-content/themes/regal/", "/wp-content/themes/shaan/", "/wp-content/themes/shadow-block/",
                "/wp-content/themes/shadow/", "/wp-content/themes/simple-but-great/",
                "/wp-content/themes/simplenews_premium/scripts/", "/wp-content/themes/simple-red-theme/",
                "/wp-content/themes/simple-tabloid/", "/wp-content/themes/simplewhite/",
                "/wp-content/themes/slidette/timThumb/", "/wp-content/themes/snowblind_colbert/",
                "/wp-content/themes/snowblind/", "/wp-content/themes/spotlight/", "/wp-content/themes/squeezepage/",
                "/wp-content/themes/standout/", "/wp-content/themes/suffusion/",
                "/wp-content/themes/swift/includes/", "/wp-content/themes/swift/includes/", "/wp-content/themes/swift/",
                "/wp-content/themes/techozoic-fluid/options/", "/wp-content/themes/the_dark_os/tools/",
                "/wp-content/themes/themetiger-fashion/", "/wp-content/themes/theory/", "/wp-content/themes/blogified/",
                "/wp-content/themes/blue-corporate-hyve-theme/", "/wp-content/themes/bluemag/library/",
                "/wp-content/themes/blue-news/scripts/", "/wp-content/themes/bombax/includes/",
                "/wp-content/themes/fordreporter/scripts/", "/wp-content/themes/freeside/",
                "/wp-content/themes/fresh-blu/scripts/", "/wp-content/themes/go-green/modules/",
                "/wp-content/themes/granite-lite/scripts/", "/wp-content/themes/greydove/",
                "/wp-content/themes/greyzed/functions/efrog/lib/", "/wp-content/themes/gunungkidul/",
                "/wp-content/themes/heartspotting-beta/", "/wp-content/themes/heli-1-wordpress-theme/images/",
                "/wp-content/themes/ideatheme/", "/wp-content/themes/impressio/timthumb/",
                "/wp-content/themes/introvert/", "/wp-content/themes/inuit-types/", "/wp-content/themes/isotherm-news/",
                "/wp-content/themes/iwana-v10/", "/wp-content/themes/jambo/", "/wp-content/themes/jcblackone/",
                "/wp-content/themes/kratalistic/", "/wp-content/themes/life-style-free/",
                "/wp-content/themes/likehacker/", "/wp-content/themes/litepress/scripts/",
                "/wp-content/themes/loganpress-premium-theme-1/", "/wp-content/themes/magazine-basic/",
                "/wp-content/themes/magup/", "/wp-content/themes/ArtSee/", "/wp-content/themes/versatile/",
                "/wp-content/themes/a", "/wp-content/themes/b", "/wp-content/themes/c", "/wp-content/themes/news",
                "/wp-content/themes/new", "/wp-content/themes/page", "/wp-content/themes/word",
                "/wp-content/themes/info", "/wp-content/themes/report",
                "/wp-content/themes/message", "/wp-content/themes/item", "/wp-content/themes/shot",
                "/wp-content/themes/photo", "/wp-content/themes/read", "/wp-content/themes/down",
                "/wp-content/themes/write", "/wp-content/themes/note", "/wp-content/themes/record",
                "/wp-content/themes/tem", "/wp-content/themes/ask", "/wp-content/themes/play",
                "/wp-content/themes/index", "/wp-content/themes/il", "/wp-content/themes/israel",
                "/wp-content/themes/sport",
                "/wp-content/themes/fun", "/wp-content/themes/party", "/wp-content/themes/view",
                "/wp-content/themes/gallery", "/wp-content/themes/magazinum/scripts/",
                "/wp-content/themes/pbv_multi/scripts/", "/wp-content/themes/comet/scripts/",
                "/wp-content/themes/conceditor-wp-strict/scripts/", "/wp-content/themes/constructor/layouts/",
                "/wp-content/themes/constructor/libs/", "/wp-content/themes/constructor/",
                "/wp-content/themes/brightsky/scripts/", "/wp-content/themes/brochure-melbourne/includes/",
                "/wp-content/themes/business-turnkey/assets/js/", "/wp-content/themes/calotropis/includes/",
                "/wp-content/themes/coffee-lite/",
                "/wp-content/themes/comet/scripts/", "/wp-content/themes/conceditor-wp-strict/scripts/",
                "/wp-content/themes/constructor/layouts/", "/wp-content/themes/constructor/libs/",
                "/wp-content/themes/constructor/", "/wp-content/themes/coverht-wp/scripts/",
                "/wp-content/themes/cover-wp/scripts/", "/wp-content/themes/dark-dream-media/",
                "/wp-content/themes/deep-blue/", "/wp-content/themes/delicate/", "/wp-content/themes/diamond-ray/",
                "/wp-content/themes/dieselclothings/", "/wp-content/themes/digitalblue/",
                "/wp-content/themes/dimenzion/", "/wp-content/themes/epione/script/",
                "/wp-content/themes/evr-green/scripts/",
                "/wp-content/themes/famous/megaframe/megapanel/", "/wp-content/themes/famous/",
                "/wp-content/themes/fashion-style/", "/wp-content/themes/featuring/", "/wp-content/themes/fliphoto/",
                "/wp-content/themes/manifesto/scripts/", "/wp-content/themes/arthem-mod/scripts/",
                "/wp-content/themes/echoes/", "/wp-content/themes/Bold4/", "/wp-content/themes/primely-theme/scripts/",
                "/wp-content/themes/zenkoreviewRD/scripts/", "/wp-content/themes/ElegantEstate/",
                "/wp-content/themes/PersonalPress2/", "/wp-content/themes/mypage/scripts/",
                "/wp-content/themes/magazinum/scripts/", "/wp-content/themes/pbv_multi/scripts/",
                "/wp-content/themes/photofeature/scripts/", "/wp-content/themes/ColdStone/",
                "/wp-content/themes/HMDeepFocus/", "/wp-content/themes/EarthlyTouch/", "/wp-content/themes/Boutique/",
                "/wp-content/themes/ePhoto/", "/wp-content/themes/PureType/", "/wp-content/themes/13Floor/",
                "/wp-content/themes/BusinessCard/", "/wp-content/themes/CherryTruffle/", "/wp-content/themes/Cion/",
                "/wp-content/themes/DailyNotes/", "/wp-content/themes/eGallery/", "/wp-content/themes/eGamer/",
                "/wp-content/themes/GrungeMag/", "/wp-content/themes/Influx/",
                "/wp-content/themes/LightBright/", "/wp-content/themes/LightSource/", "/wp-content/themes/Magnificent/",
                "/wp-content/themes/Memoir/", "/wp-content/themes/AskIt_v1.6/AskIt/", "/wp-content/themes/TidalForce/",
                "/wp-content/themes/Atlantis/", "/wp-content/themes/DelicateNewsYellow/",
                "/wp-content/themes/themorningafter/", "/wp-content/themes/arthemia-premium/scripts/",
                "/wp-content/themes/arthemia/scripts/", "/wp-content/themes/arthemia-premium-park/scripts/",
                "/wp-content/themes/linepress/", "/wp-content/themes/wedding/", "/wp-content/themes/graduate/",
                "/wp-content/themeswp-newspaper/",
                "/wp-content/themes/advanced-newspaper/", "/wp-content/themes/journey/", "/wp-content/themes/newspro/",
                "/wp-content/themes/transcript/", "/wp-content/themes/showfolio/", "/wp-content/themes/quickstart/",
                "/wp-content/themes/Restorante/", "/wp-content/themes/snapwire/",
                "/wp-content/themes/aqua-blue/includes/", "/wp-content/themes/swatch/functions/",
                "/wp-content/themes/announcement/functions/", "/wp-content/themes/empire/functions/",
                "/wp-content/themes/supportpress/functions/", "/wp-content/themes/editorial/functions/",
                "/wp-content/themes/statua/functions/", "/wp-content/themes/bookclub/functions/",
                "/wp-content/themes/boldnews/functions/", "/wp-content/themes/placeholder/functions/",
                "/wp-content/themes/biznizz/functions/", "/wp-content/themes/auld/functions/",
                "/wp-content/themes/listings/functions/", "/wp-content/themes/elefolio/functions/",
                "/wp-content/themes/chapters/functions/", "/wp-content/themes/continuum/functions/",
                "/wp-content/themes/diner/functions/", "/wp-content/themes/skeptical/functions/",
                "/wp-content/themes/caffeinated/functions/", "/wp-content/themes/crisp/functions/",
                "/wp-content/themes/sealight/functions/", "/wp-content/themes/unite/functions/",
                "/wp-content/themes/estate/functions/", "/wp-content/themes/tma/functions/",
                "/wp-content/themes/coda/functions/", "/wp-content/themes/inspire/functions/",
                "/wp-content/themes/apz/functions/", "/wp-content/themes/spectrum/functions/",
                "/wp-content/themes/diarise/functions/", "/wp-content/themes/boast/functions/",
                "/wp-content/themes/retreat/functions/", "/wp-content/themes/cityguide/functions/",
                "/wp-content/themes/cinch/functions/", "/wp-content/themes/slanted/functions/",
                "/wp-content/themes/canvas/functions/", "/wp-content/themes/postcard/functions/",
                "/wp-content/themes/delegate/functions/", "/wp-content/themes/mystream/functions/",
                "/wp-content/themes/optimize/functions/", "/wp-content/themes/backstage/functions/",
                "/wp-content/themes/sophisticatedfolio/functions/", "/wp-content/themes/bueno/functions/",
                "/wp-content/themes/digitalfarm/functions/", "/wp-content/themes/headlines/functions/",
                "//wp-content/themes/f0101/functions/", "/wp-content/themes/royalle/functions/",
                "/wp-content/themes/exposure/functions/", "/wp-content/themes/rockstar/functions/",
                "/wp-content/themes/dailyedition/functions/"

            });
            panel26.Visible = false;
            recuperareIIButton17.Visible = false;
            panel21.Visible = false;
            ambiance_Button_25.Visible = false;
            panel16.Visible = false;
            recuperareIIButton16.Visible = false;
            panel2.Visible = false;
            recuperareIIButton1.Visible = false;
            recuperareIIButton22.Visible = false;
            recuperareIIButton24.Visible = false;
            recuperareIIButton38.Visible = false;
            recuperareIIButton23.Visible = false;
            panel31.Visible = false;
            panel10.Visible = false;
            System.Diagnostics.Process myProcess = System.Diagnostics.Process.GetCurrentProcess();
            myProcess.PriorityClass = System.Diagnostics.ProcessPriorityClass.High;
            panel56.Visible = false;
            panel41.Visible = false;
            iTalk_Panel1.Visible = false;
            recuperareIIButton25.Visible = false;
            panel9.Visible = false;
            recuperareIIButton12.Visible = false;
            panel2.Size = new System.Drawing.Size(width: 956, height: 578);
            panel9.Size = new System.Drawing.Size(width: 635, height: 484);
            panel16.Size = new System.Drawing.Size(width: 763, height: 489);
            panel21.Size = new System.Drawing.Size(width: 939, height: 590);
            panel26.Size = new System.Drawing.Size(width: 854, height: 524);
            panel31.Size = new System.Drawing.Size(width: 706, height: 487);
            panel36.Size = new System.Drawing.Size(width: 975, height: 598);
            panel41.Size = new System.Drawing.Size(width: 843, height: 541);
            panel46.Size = new System.Drawing.Size(width: 457, height: 556);
            panel51.Size = new System.Drawing.Size(width: 865, height: 552);
            panel56.Size = new System.Drawing.Size(width: 421, height: 527);






















        }


        Thread islem;

        void Tarama()
        {
            int kactane = listBox1.Items.Count;
            for (int i = 0; i < kactane; i++)
            {
                try
                {

                    HttpWebRequest istek =
                        (HttpWebRequest) HttpWebRequest.Create(textBox1.Text + listBox1.Items[i].ToString());
                    HttpWebResponse cevap = (HttpWebResponse) istek.GetResponse();
                    string durum = cevap.StatusCode.ToString();
                    if (durum == "OK")
                    {
                        search.Items.Add(listBox1.Items[i].ToString() + " |BAŞARILI");
                        this.listBox3.Items.Add(this.listBox1.Items[i].ToString());



                    }
                    else
                    {

                        search.Items.Add(listBox1.Items[i].ToString() + " |BAŞARISIZ");
                    }

                }
                catch
                {
                    search.Items.Add(listBox1.Items[i].ToString() + " |BAŞARISIZ");
                }

            }
        }

        private void ListBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void Button1_Click(object sender, EventArgs e)
        {
            panel2.Visible = false;
            recuperareIIButton1.Visible = false;
        }

        private void PictureBox2_Click(object sender, EventArgs e)
        {
            panel2.Visible = true;
            recuperareIIButton1.Visible = true;
            label69.Visible = true;
            label69.ForeColor = Color.Red;
        }

        private void RecuperareIIButton2_Click(object sender, EventArgs e)
        {
            panel10.Visible = true;
            Saat.Start();
        }

        bool suruklenmedurumu = false;
        Point ilkkonum;

        private void Form1_Load(object sender, EventArgs e)
        {
            string kullanıcı = Dns.GetHostName();
            label82.Text = " " + kullanıcı;
            up.Visible = false;
            panel36.Visible = false;
            button13.Visible = false;
            button14.Visible = false;
            webBrowser1.Visible = false;
            webBrowser2.Visible = false;
            recuperareIIButton18.Visible = false;
            recuperareIIButton19.Visible = false;
            recuperareIIButton20.Visible = false;
            recuperareIIButton21.Visible = false;
            button22.Visible = false;
            recuperareIIButton37.Visible = false;
            panel51.Visible = false;
            panel46.Visible = false;
            recuperareIIButton36.Visible = false;
            pictureBox16.Visible = false;
            CheckForIllegalCrossThreadCalls = false;
            this.webBrowser1.Navigate("http://watchout4snakes.com/wo4snakes/Random/RandomWord");
            this.webBrowser2.Navigate("http://watchout4snakes.com/wo4snakes/Random/RandomWord");

            StreamReader oku = new StreamReader(Application.StartupPath + @"/panel.txt");
            string metin = oku.ReadLine();
            while (metin != null)
            {
                listBox1.Items.Add(metin);
                metin = oku.ReadLine();

            }
        }

        private void RecuperareIIButton1_Click(object sender, EventArgs e)
        {

        }

        private void Saat_Tick(object sender, EventArgs e)
        {

            label81.Text = DateTime.Now.ToLongDateString();


            string saat = DateTime.Now.ToLongTimeString();

            label80.Text = saat;
            recuperareIIButton2.Text = saat;
        }

        private void RecuperareIIButton3_Click(object sender, EventArgs e)
        {
            panel10.Visible = false;
        }

        private void Panel3_MouseDown(object sender, MouseEventArgs e)
        {
            suruklenmedurumu = true;
            panel2.Cursor = Cursors.SizeAll;
            ilkkonum = e.Location;
        }

        private void Panel3_MouseMove(object sender, MouseEventArgs e)
        {
            if (suruklenmedurumu)
            {
                panel2.Left = e.X + panel2.Left - (ilkkonum.X);
                panel2.Top = e.Y + panel2.Top - (ilkkonum.Y);
            }
        }

        private void Panel3_MouseUp(object sender, MouseEventArgs e)
        {
            suruklenmedurumu = false;
            panel2.Cursor = Cursors.Default;
        }

        private void Ambiance_Button_21_Click(object sender, EventArgs e)
        {
            if (this.textBox1.Text == "")
            {
                MessageBox.Show("Lütfen Site Adresi Girin!", "Bilgi");
            }
            else
            {
                islem = new Thread(new ThreadStart(Tarama));
                islem.Start();
                textBox1.Enabled = false;

            }
        }

        private void Ambiance_Button_22_Click(object sender, EventArgs e)
        {
            islem.Abort();
            textBox1.Enabled = true;

        }

        private void RecuperareIIButton4_Click(object sender, EventArgs e)
        {
            search.Items.Clear();
        }

        private void RecuperareIIButton5_Click(object sender, EventArgs e)
        {
            listBox3.Items.Clear();
        }

        private void RecuperareIIButton6_Click(object sender, EventArgs e)
        {
            SaveFileDialog save = new SaveFileDialog();

            save.FileName = "Bulunanlar";

            save.Filter = "Text File | *.txt";

            if (save.ShowDialog() == DialogResult.OK)

            {

                StreamWriter writer = new StreamWriter(save.OpenFile());

                for (int i = 0; i < listBox3.Items.Count; i++)

                {

                    writer.WriteLine(listBox3.Items[i].ToString());

                }

                writer.Dispose();

                writer.Close();
            }
        }

        private void EffectualButtonBlue3_Click(object sender, EventArgs e)
        {
            string metin = ambiance_TextBox1.Text;
            listBox1.Items.Add(metin);
            ambiance_TextBox1.Text = "";
            MessageBox.Show("Uzantı Eklendi", "Bilgi Ekranı", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void TextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void PictureBox1_Click(object sender, EventArgs e)
        {
            iTalk_Panel1.Visible = true;
            pictureBox1.Visible = false;
            pictureBox10.Visible = true;
        }

        private void PictureBox10_Click(object sender, EventArgs e)
        {
            iTalk_Panel1.Visible = false;
            pictureBox1.Visible = true;
            pictureBox10.Visible = false;
        }

        private void Panel9_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Button2_Click(object sender, EventArgs e)
        {
            panel9.Visible = false;
            recuperareIIButton12.Visible = false;
        }

        private void PictureBox8_Click(object sender, EventArgs e)
        {
            panel9.Visible = true;
            recuperareIIButton12.Visible = true;
            label75.Visible = true;
            label75.ForeColor = Color.Red;
        }

        private void Button5_Click(object sender, EventArgs e)
        {
            listBox5.Items.Clear();
        }

        private void Button4_Click(object sender, EventArgs e)
        {
            listBox4.Items.Clear();
        }

        private void Dorkt_Tick(object sender, EventArgs e)
        {
            this.label15.Text = this.listBox4.Items.Count.ToString();
            string str = this.webBrowser1.Document.GetElementById("result").InnerText;
            this.listBox4.Items.Add(this.özel.Text + str);
            HtmlElementCollection all = this.webBrowser1.Document.All;
            foreach (HtmlElement element in all)
            {
                if (element.GetAttribute("value") == "Refresh")
                {
                    element.InvokeMember("click");

                }
            }
        }

        private void İTalk_Button_23_Click(object sender, EventArgs e)
        {
            iTalk_Button_24.ForeColor = Color.Black;
            this.dorkt.Enabled = true;
            MessageBox.Show("İşlem Başlatıldı", "Bilgi Ekranı", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
        }

        private void İTalk_Button_24_Click(object sender, EventArgs e)
        {
            this.dorkt.Enabled = false;
            MessageBox.Show("Durduruldu", "Blgi Ekranı", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            iTalk_Button_24.ForeColor = Color.Red;
        }

        private void İTalk_Button_25_Click(object sender, EventArgs e)
        {
            SaveFileDialog dialog = new SaveFileDialog
            {
                Filter = "Text (*.txt)|*.txt"
            };
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                using (StreamWriter writer = new StreamWriter(dialog.FileName, false))
                {
                    foreach (object obj2 in this.listBox4.Items)
                    {
                        writer.Write(obj2.ToString() + Environment.NewLine);
                    }
                }

                MessageBox.Show("Veriler Başarı İle Kaydedildi", "BİLGİ", MessageBoxButtons.OK,
                    MessageBoxIcon.Exclamation);
                this.hazır.Items.Clear();
            }
        }

        private void İTalk_Button_26_Click(object sender, EventArgs e)
        {
            this.özel.Text = this.hazır.SelectedItem.ToString();
        }

        private void İTalk_Button_210_Click(object sender, EventArgs e)
        {
            iTalk_Button_29.ForeColor = Color.Black;
            this.joomla.Enabled = true;
            MessageBox.Show("İşlem Başlatıldı", "Bilgi Ekranı", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
        }

        private void Joomla_Tick(object sender, EventArgs e)
        {
            this.label19.Text = this.listBox5.Items.Count.ToString();
            string str = this.webBrowser2.Document.GetElementById("result").InnerText;
            this.listBox5.Items.Add(this.özeldork.Text + str);
            HtmlElementCollection all = this.webBrowser2.Document.All;
            foreach (HtmlElement element in all)
            {
                if (element.GetAttribute("value") == "Refresh")
                {
                    element.InvokeMember("click");
                }
            }
        }

        private void İTalk_Button_29_Click(object sender, EventArgs e)
        {
            iTalk_Button_29.ForeColor = Color.Red;
            this.joomla.Enabled = false;
            MessageBox.Show("Durduruldu", "Bilgi Ekranı", MessageBoxButtons.OK,
                MessageBoxIcon.Exclamation);
        }

        private void İTalk_Button_28_Click(object sender, EventArgs e)
        {
            SaveFileDialog dialog = new SaveFileDialog
            {
                Filter = "Text (*.txt)|*.txt"
            };
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                using (StreamWriter writer = new StreamWriter(dialog.FileName, false))
                {
                    foreach (object obj2 in this.listBox5.Items)
                    {
                        writer.Write(obj2.ToString() + Environment.NewLine);
                    }
                }

                MessageBox.Show("Veri Başarı İle Kaydedildi", "BİLGİ", MessageBoxButtons.OK,
                    MessageBoxIcon.Exclamation);
                this.hazırdork.Items.Clear();
            }
        }

        private void İTalk_Button_27_Click(object sender, EventArgs e)
        {
            this.özeldork.Text = this.hazırdork.SelectedItem.ToString();

        }

        private void Panel11_MouseDown(object sender, MouseEventArgs e)
        {
            suruklenmedurumu = true;
            panel9.Cursor = Cursors.SizeAll;
            ilkkonum = e.Location;
        }

        private void Panel11_MouseMove(object sender, MouseEventArgs e)
        {
            if (suruklenmedurumu)
            {
                panel9.Left = e.X + panel9.Left - (ilkkonum.X);
                panel9.Top = e.Y + panel9.Top - (ilkkonum.Y);
            }
        }

        private void Panel11_MouseUp(object sender, MouseEventArgs e)
        {
            suruklenmedurumu = false;
            panel9.Cursor = Cursors.Default;
        }

        private void Ipbul_Click(object sender, EventArgs e)
        {
            IPHostEntry hostname = Dns.GetHostByName(url.Text);
            IPAddress[] ip = hostname.AddressList;
            ıp.Text = (string) (ip[0].ToString());
        }

        private void Sorgula_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Bu İşlem Programı Kastırabilir Lütfen Tarama Bitene Kadar Bekleyiniz");
            string ip = string.Empty;
            int port = 0;

            try
            {
                ip = txtıp.Text;
                port = int.Parse(txtport.Text);

                TcpClient tcp = new TcpClient();
                tcp.Connect(ip, port);
                label36.Text = port + " No  Lu Port Açık";
            }
            catch (FormatException)
            {
                label36.Text = "Port Bilgisi Doğru Olmalıdır";

            }
            catch (Exception)
            {
                label36.Text = port + " No  Lu Port Kapalı";
            }
        }

        private void İTalk_Button_213_Click(object sender, EventArgs e)
        {
            string bilgisayarAdi = Dns.GetHostName();
            label45.Text = bilgisayarAdi;
            string ipAdresi = Dns.GetHostByName(bilgisayarAdi).AddressList[0].ToString();
            label46.Text = ipAdresi;
        }

        private void Timer9_Tick(object sender, EventArgs e)
        {
            Ping p = new Ping();
            PingReply cevap = p.Send(iTalk_TextBox_Small3.Text);
            if (cevap.Status == IPStatus.Success)
            {

                listBox2.Items.Add(cevap.Address.ToString() + "<br/>");


                listBox2.Items.Add(cevap.RoundtripTime.ToString() + "<br/>");


                listBox2.Items.Add(cevap.Options.Ttl.ToString() + "<br/>");
            }
            else if (cevap.Status == IPStatus.TimedOut)
            {
                listBox2.Items.Add("Zaman Aşımına Uğradı.");
            }
        }

        private void Timer10_Tick(object sender, EventArgs e)
        {

            if (iTalk_TextBox_Small3.Text == "" || iTalk_TextBox_Small3.Text == "")
                timer10.Enabled = false;
            else
                listBox2.Items.Add("Saldırı Başlatıldı Kurban Ip & Site >:" + iTalk_TextBox_Small3.Text);
            listBox2.Items.Add("Saldırı Hızı  " + saldır.Text);

            if (iTalk_TextBox_Small3.Text == "" || iTalk_TextBox_Small3.Text == "")
                timer10.Enabled = false;
            else
                listBox2.Items.Add("Atak Devam  Ediyor  Kurban Ip & Site>:" + iTalk_TextBox_Small3.Text);
        }

        private void MonoFlat_Button1_Click(object sender, EventArgs e)
        {
            if (iTalk_TextBox_Small3.Text == "")
            {
                MessageBox.Show("Lütfen Site Adresi Veya İp Adresi Giriniz !!");
                timer9.Stop();
            }
            else
            {

                if (saldır.Text == "")
                {
                    MessageBox.Show("Lütfen Saldırı Hzını Ayarlayınız !");
                }
                else
                {
                    iTalk_TextBox_Small3.Enabled = false;
                    saldır.Enabled = false;
                    timer9.Enabled = true;

                    timer10.Enabled = true;

                    timer10.Interval = (500);
                }
            }
        }

        private void MonoFlat_Button2_Click(object sender, EventArgs e)
        {
            timer9.Enabled = false;
            timer10.Enabled = false;
            listBox2.Items.Clear();
            listBox2.Items.Add("Kullanıcı Tarafından Durduruldu");
            iTalk_TextBox_Small3.Enabled = true;
            saldır.Enabled = true;
        }

        private void Button12_Click(object sender, EventArgs e)
        {
            saldır.Text = ("1");
            button12.Visible = false;
            button13.Visible = true;


        }

        private void Saldır_TextChanged(object sender, EventArgs e)
        {

        }

        private void Button13_Click(object sender, EventArgs e)
        {
            saldır.Text = ("2");
            button13.Visible = false;
            button14.Visible = true;
        }

        private void Button14_Click(object sender, EventArgs e)
        {
            saldır.Text = ("3");
            button14.Visible = false;
            button13.Visible = false;
            button12.Visible = true;

        }

        private void Button11_Click(object sender, EventArgs e)
        {
            saldır.Text = ("0");
            button14.Visible = false;
            button13.Visible = false;
            button12.Visible = true;
        }

        private void RecuperareIIButton14_Click(object sender, EventArgs e)
        {
            url.Text = ("");
            ıp.Text = ("");
        }

        private void RecuperareIIButton13_Click(object sender, EventArgs e)
        {
            label45.Text = ("Pc İsmi :");
            label46.Text = ("Pc Ip :");
        }

        private void Button3_Click(object sender, EventArgs e)
        {
            panel16.Visible = false;
            recuperareIIButton16.Visible = false;
        }

        private void PictureBox6_Click(object sender, EventArgs e)
        {
            panel16.Visible = true;
            recuperareIIButton16.Visible = true;
            label76.Visible = true;
            label76.ForeColor = Color.Red;
        }

        private void Panel17_MouseDown(object sender, MouseEventArgs e)
        {

            suruklenmedurumu = true;
            panel16.Cursor = Cursors.SizeAll;
            ilkkonum = e.Location;
        }

        private void Panel17_MouseMove(object sender, MouseEventArgs e)
        {
            if (suruklenmedurumu)
            {
                panel16.Left = e.X + panel16.Left - (ilkkonum.X);
                panel16.Top = e.Y + panel16.Top - (ilkkonum.Y);

            }
        }

        private void Panel17_MouseUp(object sender, MouseEventArgs e)
        {
            suruklenmedurumu = false;
            panel16.Cursor = Cursors.Default;

        }

        private void RecuperareIIButton15_Click(object sender, EventArgs e)
        {
            txtport.Text = ("");
            txtıp.Text = ("");
        }

        private void MonoFlat_Button3_Click(object sender, EventArgs e)
        {
            iTalk_TextBox_Small3.Text = ("");
            listBox2.Items.Clear();
        }

        private void PictureBox12_Click(object sender, EventArgs e)
        {
            webBrowser3.GoBack();
        }

        private void PictureBox13_Click(object sender, EventArgs e)
        {
            webBrowser3.GoForward();
        }

        private void PictureBox14_Click(object sender, EventArgs e)
        {
            webBrowser3.GoHome();
            webBrowser3.Navigate("www.google.com");
        }

        private void Ambiance_Button_23_Click(object sender, EventArgs e)
        {
            panel21.Size = new System.Drawing.Size(width: 1384, height: 775);
            label26.Location = new Point(666, 9);
            ambiance_Button_23.Visible = false;
            ambiance_Button_25.Visible = true;

        }

        private void Ambiance_Button_25_Click(object sender, EventArgs e)
        {
            panel21.Size = new System.Drawing.Size(width: 939, height: 590);
            label26.Location = new Point(425, 10);

            ambiance_Button_25.Visible = false;
            ambiance_Button_23.Visible = true;


        }

        private void Ambiance_Button_24_Click(object sender, EventArgs e)
        {
            recuperareIIButton17.Visible = false;
            panel21.Visible = false;
        }

        private void PictureBox4_Click(object sender, EventArgs e)
        {
            panel21.Visible = true;
            recuperareIIButton17.Visible = true;
            label70.Visible = true;
            label70.ForeColor = Color.Red;
        }

        private void Panel22_MouseDown(object sender, MouseEventArgs e)
        {
            suruklenmedurumu = true;
            panel21.Cursor = Cursors.SizeAll;
            ilkkonum = e.Location;
        }

        private void Panel22_MouseMove(object sender, MouseEventArgs e)
        {
            if (suruklenmedurumu)
            {
                panel21.Left = e.X + panel21.Left - (ilkkonum.X);
                panel21.Top = e.Y + panel21.Top - (ilkkonum.Y);
            }

        }

        private void Panel22_MouseUp(object sender, MouseEventArgs e)
        {
            suruklenmedurumu = false;
            panel21.Cursor = Cursors.Default;
        }

        private void PictureBox15_Click(object sender, EventArgs e)
        {
            pictureBox16.Visible = true;
            pictureBox15.Visible = false;
            recuperareIIButton18.Visible = true;
            recuperareIIButton19.Visible = true;
            recuperareIIButton20.Visible = true;
            recuperareIIButton21.Visible = true;
        }

        private void PictureBox16_Click(object sender, EventArgs e)
        {
            pictureBox16.Visible = false;
            pictureBox15.Visible = true;
            recuperareIIButton18.Visible = false;
            recuperareIIButton19.Visible = false;
            recuperareIIButton20.Visible = false;
            recuperareIIButton21.Visible = false;


        }

        private void RecuperareIIButton18_Click(object sender, EventArgs e)
        {
            listBox6.ForeColor = Color.Yellow;
        }

        private void RecuperareIIButton20_Click(object sender, EventArgs e)
        {
            listBox6.ForeColor = Color.White;
        }

        private void RecuperareIIButton21_Click(object sender, EventArgs e)
        {
            listBox6.ForeColor = Color.Blue;
        }

        private void RecuperareIIButton19_Click(object sender, EventArgs e)
        {
            listBox6.ForeColor = Color.Lime;
        }

        private void MonoFlat_Button6_Click(object sender, EventArgs e)
        {
            atak.Text = "";
            listBox6.Items.Clear();
        }

        private void Timer4_Tick(object sender, EventArgs e)
        {
            if (atak.Text == "" || atak.Text == "")
                timer4.Enabled = false;
            else
                listBox6.Items.Add("Saldırı Başlatıldı Kurban Ip & Site >:" + atak.Text);
            listBox6.Items.Add("Saldırı Hızı  " + hours.Text);

            if (atak.Text == "" || atak.Text == "")
                timer4.Enabled = false;
            else
                listBox6.Items.Add("Atak Devam  Ediyor  Kurban Ip & Site>:" + atak.Text);


        }

        private void Timer5_Tick(object sender, EventArgs e)
        {

            Ping p = new Ping();
            PingReply cevap = p.Send(atak.Text);
            if (cevap.Status == IPStatus.Success)
            {

                listBox6.Items.Add(cevap.Address.ToString() + "<br/>");


                listBox6.Items.Add(cevap.RoundtripTime.ToString() + "<br/>");


                listBox6.Items.Add(cevap.Options.Ttl.ToString() + "<br/>");
            }
            else if (cevap.Status == IPStatus.TimedOut)
            {
                listBox6.Items.Add("Zaman Aşımına Uğradı.");
            }
        }

        private void MonoFlat_Button4_Click(object sender, EventArgs e)
        {
            if (atak.Text == "")
            {
                MessageBox.Show("Lütfen Site Adresi Veya İp Adresi Giriniz !!");
                timer5.Stop();
            }
            else
            {

                if (hours.Text == "")
                {
                    MessageBox.Show("Lütfen Saldırı Hzını Ayarlayınız !");
                }
                else
                {
                    atak.Enabled = false;
                    hours.Enabled = false;
                    timer5.Enabled = true;

                    timer4.Enabled = true;

                    timer4.Interval = (500);


                }
            }
        }

        private void MonoFlat_Button5_Click(object sender, EventArgs e)
        {

            atak.Enabled = true;
            hours.Enabled = true;
            timer5.Enabled = false;
            timer4.Enabled = false;
            listBox6.Items.Clear();
            listBox6.Items.Add("Kullanıcı Tarafından Durduruldu");
        }

        private void Button6_Click(object sender, EventArgs e)
        {
            panel26.Visible = false;
            recuperareIIButton22.Visible = false;
        }

        private void PictureBox9_Click(object sender, EventArgs e)
        {
            panel26.Visible = true;
            recuperareIIButton22.Visible = true;
            label78.ForeColor = Color.Red;
            label78.Visible = true;
        }

        private void Panel27_MouseDown(object sender, MouseEventArgs e)
        {
            suruklenmedurumu = true;
            panel26.Cursor = Cursors.SizeAll;
            ilkkonum = e.Location;
        }

        private void Panel27_MouseMove(object sender, MouseEventArgs e)
        {
            if (suruklenmedurumu)
            {
                panel26.Left = e.X + panel26.Left - (ilkkonum.X);
                panel26.Top = e.Y + panel26.Top - (ilkkonum.Y);
            }
        }

        private void Panel27_MouseUp(object sender, MouseEventArgs e)
        {
            suruklenmedurumu = false;
            panel26.Cursor = Cursors.Default;
        }

        private void Ambiance_TextBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void TextBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void Button7_Click(object sender, EventArgs e)
        {
            panel31.Visible = false;
            recuperareIIButton23.Visible = false;
        }

        private void Panel31_Paint(object sender, PaintEventArgs e)
        {

        }

        private void PictureBox5_Click(object sender, EventArgs e)
        {
            panel31.Visible = true;
            recuperareIIButton23.Visible = true;
            label77.Visible = true;
            label77.ForeColor = Color.Red;
        }

        private void Panel32_MouseDown(object sender, MouseEventArgs e)
        {
            suruklenmedurumu = true;
            panel31.Cursor = Cursors.SizeAll;
            ilkkonum = e.Location;
        }

        private void Panel32_MouseMove(object sender, MouseEventArgs e)
        {
            if (suruklenmedurumu)
            {
                panel31.Left = e.X + panel31.Left - (ilkkonum.X);
                panel31.Top = e.Y + panel31.Top - (ilkkonum.Y);
            }

        }

        private void Panel32_MouseUp(object sender, MouseEventArgs e)
        {
            suruklenmedurumu = false;
            panel31.Cursor = Cursors.Default;
        }

        private void Timer8_Tick(object sender, EventArgs e)
        {
            MailMessage message = new MailMessage();
            try
            {
                message.From = new MailAddress(this.TXT3.Text);
                message.To.Add(this.KURBAN.Text);
                message.Subject = this.textBox2.Text;
                message.Body = this.textBox3.Text;
                new SmtpClient(this.com2.Text)
                {
                    Port = Conversions.ToInteger(this.com1.Text), EnableSsl = Conversions.ToBoolean(this.com3.Text),
                    Credentials = new NetworkCredential(this.TXT3.Text, this.TXT4.Text)
                }.Send(message);
            }
            catch (Exception exception1)
            {
                ProjectData.SetProjectError(exception1);
                Exception exception = exception1;
                ProjectData.ClearProjectError();

            }
        }


        private void Saldırıd_Click(object sender, EventArgs e)
        {
            this.TXT3.Enabled = true;
            this.TXT4.Enabled = true;
            this.KURBAN.Enabled = true;
            this.up.Enabled = true;
            this.textBox3.Enabled = true;
            this.textBox2.Enabled = true;
            this.com1.Enabled = true;
            this.com2.Enabled = true;
            this.com3.Enabled = true;
            this.saldırı.Enabled = true;
            this.timer8.Stop();
            MessageBox.Show("SALDIRI DURDURULDU", "BİLGİ", MessageBoxButtons.OK, MessageBoxIcon.Information);

        }

        private void Ambiance_TextBox2_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void Saldırı_Click(object sender, EventArgs e)
        {
            if ((KURBAN.Text == "cyberhours@hotmail.com"))
                Application.Exit();
            else
                MessageBox.Show("SALDIRI BAŞLATILDI", "BİLGİ", MessageBoxButtons.OK, MessageBoxIcon.Information);
            this.textBox3.Enabled = false;
            this.TXT4.Enabled = false;
            this.KURBAN.Enabled = false;
            this.up.Enabled = false;
            this.textBox2.Enabled = false;
            this.textBox3.Enabled = false;
            this.com1.Enabled = false;
            this.com2.Enabled = false;
            this.com3.Enabled = false;
            this.timer8.Start();

        }

        private void MonoFlat_Button7_Click(object sender, EventArgs e)
        {
            SaveFileDialog dialog = new SaveFileDialog
            {
                Filter = "BAT (*.bat)|*.bat"
            };
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                using (StreamWriter writer = new StreamWriter(dialog.FileName, false))
                {
                    foreach (object obj2 in this.textBox4.Text)
                    {
                        writer.Write(obj2.ToString() + Environment.NewLine);
                    }
                }

                MessageBox.Show(
                    "VİRÜS BAŞARI İLE OLUŞTURULDU KESİNLİKLE KENDİNİZ AÇMAYIN CODER BUNDAN SORUMLU TUTULAMAZ !!!!",
                    "BİLGİ", MessageBoxButtons.OK,
                    MessageBoxIcon.Exclamation);

            }
        }

        private void İTalk_RadioButton1_CheckedChanged(object sender)
        {
            textBox4.ForeColor = Color.Yellow;
        }

        private void İTalk_RadioButton2_CheckedChanged(object sender)
        {
            textBox4.ForeColor = Color.White;
        }

        private void İTalk_RadioButton3_CheckedChanged(object sender)
        {
            textBox4.ForeColor = Color.Blue;
        }

        private void İTalk_RadioButton4_CheckedChanged(object sender)
        {
            textBox4.ForeColor = Color.Lime;
        }

        private void MonoFlat_Button8_Click(object sender, EventArgs e)
        {
            textBox4.Text = ("");
        }

        private void MonoFlat_Button9_Click(object sender, EventArgs e)
        {
            MessageBox.Show(
                "PROGRAMIN KULLANIMINDAN DOĞABİLECEK HER TÜRLÜ ZARAR KULLANICIYA AİTTİR CODER BUNDAN KESİNLİKLE SORUMLU DEĞİLDİR !!",
                "BİLGİ", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        private void EffectualButtonBlue1_Click(object sender, EventArgs e)
        {
            textBox4.Text = (textBox5.Text);





        }

        private void EffectualButtonBlue9_Click(object sender, EventArgs e)
        {
            textBox4.Text = (textBox6.Text);
        }

        private void EffectualButtonBlue8_Click(object sender, EventArgs e)
        {
            textBox4.Text = (textBox7.Text);
        }

        private void EffectualButtonBlue7_Click(object sender, EventArgs e)
        {
            textBox4.Text = (textBox8.Text);
        }

        private void EffectualButtonBlue2_Click(object sender, EventArgs e)
        {
            textBox4.Text = (textBox9.Text);
        }

        private void EffectualButtonBlue4_Click(object sender, EventArgs e)
        {
            textBox4.Text = textBox10.Text;
        }

        private void EffectualButtonBlue5_Click(object sender, EventArgs e)
        {
            textBox4.Text = textBox11.Text;
        }

        private void EffectualButtonBlue6_Click(object sender, EventArgs e)
        {
            textBox4.Text = textBox12.Text;
        }

        private void EffectualButtonBlue12_Click(object sender, EventArgs e)
        {
            textBox4.Text = textBox16.Text;
        }

        private void EffectualButtonBlue11_Click(object sender, EventArgs e)
        {
            textBox4.Text = textBox15.Text;
        }

        private void EffectualButtonBlue10_Click(object sender, EventArgs e)
        {
            textBox4.Text = textBox13.Text;
        }

        private void Button8_Click(object sender, EventArgs e)
        {
            panel36.Visible = false;
            recuperareIIButton24.Visible = false;
        }

        private void Panel37_MouseDown(object sender, MouseEventArgs e)
        {
            suruklenmedurumu = true;
            panel36.Cursor = Cursors.SizeAll;
            ilkkonum = e.Location;
        }

        private void Panel37_MouseMove(object sender, MouseEventArgs e)
        {
            if (suruklenmedurumu)
            {
                panel36.Left = e.X + panel36.Left - (ilkkonum.X);
                panel36.Top = e.Y + panel36.Top - (ilkkonum.Y);
            }
        }

        private void Panel37_MouseUp(object sender, MouseEventArgs e)
        {
            suruklenmedurumu = false;
            panel36.Cursor = Cursors.Default;

        }

        private void PictureBox7_Click(object sender, EventArgs e)
        {
            panel36.Visible = true;
            recuperareIIButton24.Visible = true;
            label74.ForeColor = Color.Red;
            label74.Visible = true;

        }

        private void MonoFlat_Button13_Click(object sender, EventArgs e)
        {
            panel1.BackColor = Color.DarkSlateGray;
        }

        private void MonoFlat_Button10_Click(object sender, EventArgs e)
        {
            panel1.BackColor = Color.SteelBlue;

        }

        private void MonoFlat_Button11_Click(object sender, EventArgs e)
        {
            panel1.BackColor = Color.DodgerBlue;

        }

        private void MonoFlat_Button12_Click(object sender, EventArgs e)
        {
            ColorDialog Renk = new ColorDialog();
            Renk.ShowDialog();
            panel1.BackColor = Renk.Color;
        }

        private void MonoFlat_Button14_Click(object sender, EventArgs e)
        {
            panel1.BackColor = Color.DeepSkyBlue;
        }

        private void İTalk_GroupBox15_Click(object sender, EventArgs e)
        {

        }

        private void MonoFlat_Button19_Click(object sender, EventArgs e)
        {
            this.BackColor = System.Drawing.Color.White;
        }

        private void MonoFlat_Button18_Click(object sender, EventArgs e)
        {
            this.BackColor = System.Drawing.Color.DeepSkyBlue;
        }

        private void MonoFlat_Button17_Click(object sender, EventArgs e)
        {
            ColorDialog Renk = new ColorDialog();
            Renk.ShowDialog();
            this.BackColor = Renk.Color;
        }

        private void MonoFlat_Button16_Click(object sender, EventArgs e)
        {
            this.BackColor = System.Drawing.Color.DarkSlateGray;
        }

        private void MonoFlat_Button15_Click(object sender, EventArgs e)
        {
            this.BackColor = System.Drawing.Color.LightBlue;
        }


        private void MonoFlat_Button20_Click(object sender, EventArgs e)
        {

            {
                try
                {
                    MessageBox.Show("Arkaplana Resim Koyulduğu Zaman Program Kasabilir", "Bilgilendirme",
                        MessageBoxButtons.YesNo, MessageBoxIcon.Information);
                    OpenFileDialog openFileDialog1 = new OpenFileDialog();
                    openFileDialog1.Filter = " Resim Dosyaları|*.jpg| Bütün Dosyalar|*.*";
                    openFileDialog1.Title = "RESİM SEÇ";
                    openFileDialog1.ShowDialog();
                    textBox1.Text = openFileDialog1.FileName.ToString();
                    string FileName = openFileDialog1.FileName;
                    this.BackgroundImage = Image.FromFile(FileName);
                    pictureBox17.Image = Image.FromFile(FileName);
                }
                catch
                {
                    MessageBox.Show("Resim Seçilmedi", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

            }
        }

        private void MonoFlat_Button21_Click(object sender, EventArgs e)
        {
            this.BackgroundImage = null;


        }

        private void Button9_Click(object sender, EventArgs e)
        {
            panel41.Visible = false;
            recuperareIIButton25.Visible = false;
        }

        private void PictureBox19_Click(object sender, EventArgs e)
        {
            ColorDialog Renk = new ColorDialog();
            Renk.ShowDialog();
            panel2.BackColor = Renk.Color;
        }

        private void PictureBox21_Click(object sender, EventArgs e)
        {
            ColorDialog Renk = new ColorDialog();
            Renk.ShowDialog();
            panel9.BackColor = Renk.Color;
        }

        private void PictureBox23_Click(object sender, EventArgs e)
        {
            ColorDialog Renk = new ColorDialog();
            Renk.ShowDialog();
            panel26.BackColor = Renk.Color;
        }

        private void PictureBox26_Click(object sender, EventArgs e)
        {
            ColorDialog Renk = new ColorDialog();
            Renk.ShowDialog();
            panel31.BackColor = Renk.Color;
        }

        private void PictureBox20_Click(object sender, EventArgs e)
        {
            ColorDialog Renk = new ColorDialog();
            Renk.ShowDialog();
            panel16.BackColor = Renk.Color;
        }

        private void PictureBox24_Click(object sender, EventArgs e)
        {
            ColorDialog Renk = new ColorDialog();
            Renk.ShowDialog();
            panel36.BackColor = Renk.Color;
        }

        private void PictureBox25_Click(object sender, EventArgs e)
        {
            ColorDialog Renk = new ColorDialog();
            Renk.ShowDialog();
            panel41.BackColor = Renk.Color;
        }

        private void MonoFlat_Button22_Click(object sender, EventArgs e)
        {
            RegistryKey key = Registry.CurrentUser.OpenSubKey(@"Software\Microsoft\Windows\CurrentVersion\Run", true);
            key.SetValue(ProgramAdi, "\"" + Application.ExecutablePath + "\"");
            MessageBox.Show("BAŞLANGICA EKLENDİ", "BİLGİ", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void MonoFlat_Button23_Click(object sender, EventArgs e)
        {

            RegistryKey key = Registry.CurrentUser.OpenSubKey(@"Software\Microsoft\Windows\CurrentVersion\Run", true);
            key.DeleteValue(ProgramAdi);
            MessageBox.Show("BAŞLANGICTAN KALDIRILDI", "BİLGİ", MessageBoxButtons.OK, MessageBoxIcon.Information);

        }

        private void Panel42_MouseDown(object sender, MouseEventArgs e)
        {

            suruklenmedurumu = true;
            panel41.Cursor = Cursors.SizeAll;
            ilkkonum = e.Location;
        }

        private void Panel42_MouseMove(object sender, MouseEventArgs e)
        {
            if (suruklenmedurumu)
            {
                panel41.Left = e.X + panel41.Left - (ilkkonum.X);
                panel41.Top = e.Y + panel41.Top - (ilkkonum.Y);
            }

        }

        private void Panel42_MouseUp(object sender, MouseEventArgs e)
        {
            suruklenmedurumu = false;
            panel41.Cursor = Cursors.Default;
        }

        private void PictureBox3_Click(object sender, EventArgs e)
        {
            panel41.Visible = true;
            recuperareIIButton25.Visible = true;
            label73.Visible = true;
            label73.ForeColor = Color.Red;

        }

        private void Button10_Click(object sender, EventArgs e)
        {
            panel46.Visible = false;
            recuperareIIButton36.Visible = false;
        }

        private void Panel47_MouseDown(object sender, MouseEventArgs e)
        {
            suruklenmedurumu = true;
            panel46.Cursor = Cursors.SizeAll;
            ilkkonum = e.Location;
        }

        private void Panel47_MouseMove(object sender, MouseEventArgs e)
        {
            if (suruklenmedurumu)
            {
                panel46.Left = e.X + panel46.Left - (ilkkonum.X);
                panel46.Top = e.Y + panel46.Top - (ilkkonum.Y);
            }
        }

        private void Panel47_MouseUp(object sender, MouseEventArgs e)
        {
            suruklenmedurumu = false;
            panel46.Cursor = Cursors.Default;

        }

        private void RecuperareIIButton26_Click(object sender, EventArgs e)
        {
            panel41.Visible = true;
            label73.Visible = true;
            label73.ForeColor = Color.Red;


        }

        private void RecuperareIIButton27_Click(object sender, EventArgs e)
        {
            panel2.Visible = true;
            label69.Visible = true;
            label69.ForeColor = Color.Red;



        }

        private void RecuperareIIButton28_Click(object sender, EventArgs e)
        {
            panel31.Visible = true;
            label77.Visible = true;
            label77.ForeColor = Color.Red;
        }

        private void RecuperareIIButton29_Click(object sender, EventArgs e)
        {
            panel36.Visible = true;
            label74.Visible = true;
            label74.ForeColor = Color.Red;
        }

        private void RecuperareIIButton30_Click(object sender, EventArgs e)
        {
            panel9.Visible = true;
            label75.Visible = true;
            label75.ForeColor = Color.Red;
        }

        private void RecuperareIIButton31_Click(object sender, EventArgs e)
        {
            panel21.Visible = true;
            label70.Visible = true;
            label70.ForeColor = Color.Red;
        }

        private void RecuperareIIButton32_Click(object sender, EventArgs e)
        {
            panel26.Visible = true;
            label76.Visible = true;
            label76.ForeColor = Color.Red;
        }

        private void RecuperareIIButton33_Click(object sender, EventArgs e)
        {
            panel16.Visible = true;
            label78.Visible = true;
            label78.ForeColor = Color.Red;
        }

        private void RecuperareIIButton7_Click(object sender, EventArgs e)
        {
            panel46.Visible = true;
            recuperareIIButton36.Visible = true;
            label72.Visible = true;
            label72.ForeColor = Color.Red;
            iTalk_Panel1.Visible = false;
        }

        private void Panel11_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Panel46_Paint(object sender, PaintEventArgs e)
        {

        }

        private void RecuperareIIButton34_Click(object sender, EventArgs e)
        {
            panel51.Visible = true;
            label71.Visible = true;
            label71.ForeColor = Color.Red;
        }

        private void RecuperareIIButton35_Click(object sender, EventArgs e)
        {
            panel56.Visible = true;
        }

        private void MonoFlat_Button24_Click(object sender, EventArgs e)
        {
            HttpWebRequest istek = (HttpWebRequest) WebRequest.Create(ambiance_TextBox2.Text);
            HttpWebResponse yanit = (HttpWebResponse) (istek.GetResponse());
            StreamReader yaz = new StreamReader(yanit.GetResponseStream());
            richTextBox1.Text = yaz.ReadToEnd();

        }



        public object HttpWebResponse { get; set; }

        private void MonoFlat_Button25_Click(object sender, EventArgs e)
        {
            richTextBox1.Text = "";
            ambiance_TextBox2.Text = "";
        }

        private void İTalk_GroupBox20_Click(object sender, EventArgs e)
        {

        }

        private void EffectualRadioButton1_CheckedChanged(object sender)
        {
            richTextBox1.ForeColor = Color.White;
        }

        private void EffectualRadioButton2_CheckedChanged(object sender)
        {
            richTextBox1.ForeColor = Color.Yellow;
        }

        private void EffectualRadioButton3_CheckedChanged(object sender)
        {
            richTextBox1.ForeColor = Color.Lime;
        }

        private void EffectualRadioButton4_CheckedChanged(object sender)
        {
            richTextBox1.ForeColor = Color.Red;
        }

        private void EffectualRadioButton5_CheckedChanged(object sender)
        {
            richTextBox1.ForeColor = Color.Blue;
        }

        private void EffectualRadioButton6_CheckedChanged(object sender)
        {
            richTextBox1.ForeColor = Color.DeepSkyBlue;
        }

        private void MonoFlat_Button26_Click(object sender, EventArgs e)
        {
            SaveFileDialog dialog = new SaveFileDialog
            {
                Filter = "Html (*.html)|*.html"
            };
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                using (StreamWriter writer = new StreamWriter(dialog.FileName, false))
                {
                    foreach (object obj2 in this.richTextBox1.Text)
                    {
                        writer.Write(obj2.ToString() + Environment.NewLine);
                    }
                }

                MessageBox.Show("Veri Başarı İle Kaydedildi", "BİLGİ", MessageBoxButtons.OK,
                    MessageBoxIcon.Exclamation);
                richTextBox1.Text = "";
            }
        }

        private void Button15_Click(object sender, EventArgs e)
        {
            panel51.Visible = false;
            recuperareIIButton37.Visible = false;
        }

        private void PictureBox27_Click(object sender, EventArgs e)
        {
            panel51.Visible = true;
            recuperareIIButton37.Visible = true;
            label71.Visible = true;
            label71.ForeColor = Color.Red;
        }

        private void Panel52_MouseDown(object sender, MouseEventArgs e)
        {
            suruklenmedurumu = true;
            panel51.Cursor = Cursors.SizeAll;
            ilkkonum = e.Location;
        }

        private void Panel52_MouseMove(object sender, MouseEventArgs e)
        {
            if (suruklenmedurumu)
            {
                panel51.Left = e.X + panel51.Left - (ilkkonum.X);
                panel51.Top = e.Y + panel51.Top - (ilkkonum.Y);
            }
        }

        private void Panel52_MouseUp(object sender, MouseEventArgs e)
        {
            suruklenmedurumu = false;
            panel51.Cursor = Cursors.Default;
        }

        private void RecuperareIIButton10_Click(object sender, EventArgs e)
        {
            panel41.Visible = true;
            iTalk_Panel1.Visible = false;
            label73.ForeColor = Color.Red;
            label73.Visible = true;
            recuperareIIButton25.Visible = true;
        }

        private void RecuperareIIButton9_Click(object sender, EventArgs e)
        {
            panel41.Visible = true;
            recuperareIIButton25.Visible = true;
            iTalk_Panel1.Visible = false;
        }

        private void Label73_Click(object sender, EventArgs e)
        {

        }

        private void EffectualButtonBlue13_Click(object sender, EventArgs e)
        {
            panel2.Visible = false;
            label69.ForeColor = Color.Black;
            label69.Visible = false;
            recuperareIIButton1.Visible = false;
        }

        private void EffectualButtonBlue14_Click(object sender, EventArgs e)
        {
            panel9.Visible = false;
            label75.ForeColor = Color.Black;
            label75.Visible = false;
            recuperareIIButton12.Visible = false;
        }

        private void EffectualButtonBlue15_Click(object sender, EventArgs e)
        {
            panel26.Visible = false;
            label78.Visible = false;
            label78.ForeColor = Color.Black;
            recuperareIIButton22.Visible = false;
        }

        private void EffectualButtonBlue16_Click(object sender, EventArgs e)
        {
            panel16.Visible = false;
            label76.Visible = false;
            label76.ForeColor = Color.Black;
            recuperareIIButton16.Visible = false;

        }

        private void EffectualButtonBlue17_Click(object sender, EventArgs e)
        {
            panel31.Visible = false;
            label77.ForeColor = Color.Black;
            label77.Visible = false;
            recuperareIIButton23.Visible = false;
        }

        private void EffectualButtonBlue18_Click(object sender, EventArgs e)
        {
            panel21.Visible = false;
            label70.ForeColor = Color.Black;
            recuperareIIButton17.Visible = false;
            label70.Visible = false;
        }

        private void EffectualButtonBlue19_Click(object sender, EventArgs e)
        {
            panel51.Visible = false;
            label71.ForeColor = Color.Black;
            label71.Visible = false;
            recuperareIIButton37.Visible = false;

        }

        private void EffectualButtonBlue20_Click(object sender, EventArgs e)
        {
            panel46.Visible = false;
            label72.ForeColor = Color.Black;
            label72.Visible = false;
            recuperareIIButton36.Visible = false;
        }

        private void EffectualButtonBlue21_Click(object sender, EventArgs e)
        {
            panel41.Visible = false;
            label73.Visible = false;
            label3.ForeColor = Color.Black;
            recuperareIIButton25.Visible = false;
        }

        private void EffectualButtonBlue22_Click(object sender, EventArgs e)
        {
            panel36.Visible = false;
            label74.Visible = false;
            label74.ForeColor = Color.Black;
            recuperareIIButton24.Visible = false;
        }

        private void RecuperareIIButton8_Click(object sender, EventArgs e)
        {
            panel56.Visible = true;
            recuperareIIButton38.Visible = true;
            iTalk_Panel1.Visible = false;
        }

        private void Ambiance_Button_26_Click(object sender, EventArgs e)
        {
            panel56.Visible = false;
            recuperareIIButton38.Visible = false;
        }

        private void Panel57_MouseDown(object sender, MouseEventArgs e)
        {
            suruklenmedurumu = true;
            panel56.Cursor = Cursors.SizeAll;
            ilkkonum = e.Location;
        }

        private void Panel57_MouseMove(object sender, MouseEventArgs e)
        {
            if (suruklenmedurumu)
            {
                panel56.Left = e.X + panel56.Left - (ilkkonum.X);
                panel56.Top = e.Y + panel56.Top - (ilkkonum.Y);
            }
        }

        private void Panel57_MouseUp(object sender, MouseEventArgs e)
        {
            suruklenmedurumu = false;
            panel56.Cursor = Cursors.Default;
        }

        private void RecuperareIIButton11_Click(object sender, EventArgs e)
        {
            iTalk_Panel1.Visible = false;
            MessageBox.Show("BU PROGRAM CYBERHOURS TARAFINDAN 25.10.2019 TARİHİNDE KODLANMIŞTIR PROGRAMIN KULLANIMINDAN DOĞABİLECEK ZARARLARDAN CODER SORUMLU TUTULAMAZ" +
                "  ", "HAKKINDA", MessageBoxButtons.OK);


        }

        private void Button19_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Button22_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Normal;
            button22.Visible = false;
            button21.Visible = true;
            this.Size = new System.Drawing.Size(1431, 813);


        }

        private void Button21_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Maximized;
            button21.Visible = false;
            button22.Visible = true;

        }

        private void Button20_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }
        int Move;
        int Mouse_X;
        int Mouse_Y;
        private void Panel62_MouseDown(object sender, MouseEventArgs e)
        {
            Move = 1;
            Mouse_X = e.X;
            Mouse_Y = e.Y;
        }

        private void Panel62_MouseMove(object sender, MouseEventArgs e)
        {
            if (Move == 1)
            {
                this.SetDesktopLocation(MousePosition.X - Mouse_X, MousePosition.Y - Mouse_Y);
            }
        }

        private void Panel62_MouseUp(object sender, MouseEventArgs e)
        {
            Move = 0;

        }

        private void MonoFlat_Button27_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void recuperareIIButton24_Click(object sender, EventArgs e)
        {

        }
    }
}

