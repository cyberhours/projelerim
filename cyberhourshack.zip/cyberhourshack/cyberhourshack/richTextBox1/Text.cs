﻿namespace richTextBox1
{
    internal class Text
    {
    }
}